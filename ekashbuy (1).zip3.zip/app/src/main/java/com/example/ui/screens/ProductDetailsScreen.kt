package com.example.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PauseCircleOutline
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.formatInr
import com.example.model.ProductListing
import com.example.ui.components.BusinessRulesBanner
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.ProductVisualArtwork
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange
import com.example.ui.theme.VibrantOrangeContainer
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProductDetailsScreen(
    listing: ProductListing?,
    isLoading: Boolean,
    isOwnListing: Boolean,
    isDeleting: Boolean,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onNavigateBack: () -> Unit,
    onOpenMessagesPreview: () -> Unit,
    onEditListing: (ProductListing) -> Unit,
    onDeleteListing: (String) -> Unit,
    isAuthenticated: Boolean = true,
    actionError: String? = null,
    actionSuccess: String? = null,
    onClearMessages: () -> Unit = {},
    onUpdateStatus: ((String, FirestoreListingStatus) -> Unit)? = null,
    isUpdatingStatus: Boolean = false,
    onStartConversation: ((ProductListing, String) -> Unit)? = null,
    isStartingConversation: Boolean = false,
    messageActionError: String? = null,
    onClearMessageErrors: () -> Unit = {},
    onOpenLogin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    var showChatDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showMarkSoldConfirmDialog by remember { mutableStateOf(false) }
    var wasStartingConversation by remember { mutableStateOf(false) }

    LaunchedEffect(isStartingConversation, messageActionError) {
        if (isStartingConversation) {
            wasStartingConversation = true
        } else if (wasStartingConversation) {
            wasStartingConversation = false
            if (messageActionError == null) {
                showChatDialog = false
            }
        }
    }

    val defaultInquiryText = if (listing != null) {
        "Hi, is \"${listing.title}\" still available?"
    } else {
        ""
    }
    var inquiryMessage by rememberSaveable(listing?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(
            TextFieldValue(
                text = defaultInquiryText,
                selection = TextRange(defaultInquiryText.length)
            )
        )
    }

    LaunchedEffect(actionError, actionSuccess) {
        val message = actionError ?: actionSuccess
        if (!message.isNullOrBlank()) {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
            onClearMessages()
        }
    }

    val showIntentUnavailableMessage: (String) -> Unit = { message ->
        coroutineScope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
        }
    }

    if (showChatDialog && listing != null) {
        AlertDialog(
            onDismissRequest = {
                if (!isStartingConversation) {
                    showChatDialog = false
                    onClearMessageErrors()
                }
            },
            title = { Text("Direct Seller Contact") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isAuthenticated) {
                            "Send an instant Firestore message to ${listing.sellerName} or call directly at ${listing.sellerPhone}."
                        } else {
                            "Sign in to message ${listing.sellerName} directly, or call ${listing.sellerPhone}."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isAuthenticated) {
                        EkashbuyOutlinedTextField(
                            value = inquiryMessage,
                            onValueChange = { incoming ->
                                inquiryMessage = if (incoming.text.length <= 1000) incoming else inquiryMessage
                                onClearMessageErrors()
                            },
                            label = "Message to Seller",
                            placeholder = "Ask about condition, pickup, or final price…",
                            singleLine = false,
                            minLines = 2,
                            maxLines = 4,
                            enabled = !isStartingConversation,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                autoCorrectEnabled = false
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("details_message_input")
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(
                                "Is this still available?",
                                "What is your best price?"
                            ).forEach { quickText ->
                                FilterChip(
                                    selected = inquiryMessage.text == quickText,
                                    enabled = !isStartingConversation,
                                    onClick = {
                                        inquiryMessage = TextFieldValue(quickText, TextRange(quickText.length))
                                    },
                                    label = { Text(quickText, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                        messageActionError?.let { err ->
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.testTag("details_message_error")
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            showChatDialog = false
                            safeLaunchDialIntent(
                                context = context,
                                rawPhone = listing.sellerPhone,
                                onUnavailable = showIntentUnavailableMessage
                            )
                        }
                    ) {
                        Text("Call Seller")
                    }
                    if (isAuthenticated) {
                        Button(
                            onClick = {
                                if (onStartConversation != null) {
                                    onStartConversation(listing, inquiryMessage.text)
                                } else {
                                    showChatDialog = false
                                    onOpenMessagesPreview()
                                }
                            },
                            enabled = !isStartingConversation && inquiryMessage.text.trim().isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                            modifier = Modifier.testTag("details_send_message_button")
                        ) {
                            if (isStartingConversation) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Text("Send Message")
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                showChatDialog = false
                                onOpenLogin()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                        ) {
                            Text("Sign in with Google")
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showChatDialog = false
                        onClearMessageErrors()
                    },
                    enabled = !isStartingConversation
                ) {
                    Text("Close")
                }
            }
        )
    }

    if (showDeleteConfirmDialog && listing != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Advertisement") },
            text = {
                Text("Are you sure you want to permanently delete \"${listing.title}\"? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteListing(listing.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("details_confirm_delete_button")
                ) {
                    Text("Delete Ad")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showMarkSoldConfirmDialog && listing != null && onUpdateStatus != null) {
        AlertDialog(
            onDismissRequest = { showMarkSoldConfirmDialog = false },
            title = { Text("Mark Advertisement as Sold") },
            text = {
                Text("Mark \"${listing.title}\" as sold? It will be removed from active public listings.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMarkSoldConfirmDialog = false
                        onUpdateStatus(listing.id, FirestoreListingStatus.SOLD)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VibrantOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("details_confirm_sold_button")
                ) {
                    Text("Mark Sold")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMarkSoldConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Ad Details", style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("details_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (listing != null) {
                        IconButton(
                            onClick = {
                                val shareText = "${listing.title} — ${formatInr(listing.priceInr, listing.isMonthlyRent)} in ${listing.locality}, ${listing.district.displayName} on eKashbuy"
                                safeLaunchShareIntent(
                                    context = context,
                                    shareText = shareText,
                                    onUnavailable = showIntentUnavailableMessage
                                )
                            },
                            modifier = Modifier.testTag("details_share_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Share,
                                contentDescription = "Share ad"
                            )
                        }
                        IconButton(
                            onClick = onToggleFavorite,
                            modifier = Modifier.testTag("details_favorite_button")
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = if (isFavorite) "Remove favorite" else "Save favorite",
                                tint = if (isFavorite) VibrantOrange else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (listing != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (isOwnListing) {
                            OutlinedButton(
                                onClick = { onEditListing(listing) },
                                enabled = !isDeleting,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("details_edit_button"),
                                border = BorderStroke(1.5.dp, RoyalBlue),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = RoyalBlue)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Edit,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Edit Ad")
                            }
                            Button(
                                onClick = { showDeleteConfirmDialog = true },
                                enabled = !isDeleting,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("details_delete_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = Color.White
                                )
                            ) {
                                if (isDeleting) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Delete Ad")
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = { showChatDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("details_message_seller_button"),
                                border = BorderStroke(1.5.dp, RoyalBlue),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = RoyalBlue)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ChatBubbleOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Message")
                            }
                            Button(
                                onClick = {
                                    safeLaunchDialIntent(
                                        context = context,
                                        rawPhone = listing.sellerPhone,
                                        onUnavailable = showIntentUnavailableMessage
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("details_call_seller_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VibrantOrange,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Call,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Call Seller")
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        when {
            listing == null && isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingStateView(message = "Loading advertisement details…")
                }
            }

            listing == null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = "Listing not found",
                        subtitle = "This advertisement may have been removed or sold.",
                        actionLabel = "Go Back",
                        onActionClick = onNavigateBack
                    )
                }
            }

            else -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .verticalScroll(rememberScrollState())
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                    ) {
                        ProductVisualArtwork(
                            listing = listing,
                            modifier = Modifier.fillMaxSize()
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = RoyalBlue
                            ) {
                                Text(
                                    text = listing.adTier.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                            if (listing.status != "ACTIVE") {
                                val displayStatus = when (listing.status) {
                                    FirestoreListingStatus.PAUSED.name -> "Paused"
                                    FirestoreListingStatus.SOLD.name -> "Sold"
                                    FirestoreListingStatus.ARCHIVED.name -> "Archived"
                                    else -> listing.status
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = VibrantOrange
                                ) {
                                    Text(
                                        text = displayStatus,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatInr(listing.priceInr, listing.isMonthlyRent),
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = RoyalBlue
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (listing.negotiable) VibrantOrangeContainer else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = if (listing.negotiable) "Negotiable" else "Fixed Price",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (listing.negotiable) VibrantOrange else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = listing.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = "Location",
                                    tint = VibrantOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${listing.locality}, ${listing.district.displayName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Schedule,
                                    contentDescription = "Posted",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = listing.postedAgo,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        BusinessRulesBanner(compact = false)

                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Specifications",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                DetailRow("Category", listing.category.title)
                                DetailRow("Condition", listing.condition.label)
                                DetailRow("District", listing.district.displayName)
                                DetailRow("Locality", listing.locality)
                                listing.specs.entries.forEach { (key, value) ->
                                    DetailRow(key, value)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Description",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = listing.description,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Seller Information",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // Note: Per business rules, NO fake seller verification badges or ratings are shown.
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("details_seller_info_card"),
                            shape = MaterialTheme.shapes.medium,
                            color = if (isOwnListing) EmeraldContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (isOwnListing) EmeraldBadge.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = RoyalBlueContainer
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Person,
                                        contentDescription = "Seller avatar",
                                        tint = RoyalBlue,
                                        modifier = Modifier
                                            .padding(12.dp)
                                            .size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isOwnListing) "${listing.sellerName} (You)" else listing.sellerName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${listing.locality}, ${listing.district.displayName} • Direct local seller",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = listing.sellerPhone,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = RoyalBlue
                                    )
                                }
                            }
                        }

                        if (isOwnListing && onUpdateStatus != null) {
                            val isActive = listing.status == FirestoreListingStatus.ACTIVE.name
                            val nextToggleStatus = if (isActive) {
                                FirestoreListingStatus.PAUSED
                            } else {
                                FirestoreListingStatus.ACTIVE
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Manage Ad Status",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onUpdateStatus(listing.id, nextToggleStatus) },
                                    enabled = !isDeleting && !isUpdatingStatus,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("details_status_toggle_button")
                                ) {
                                    if (isUpdatingStatus) {
                                        CircularProgressIndicator(
                                            color = RoyalBlue,
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (isActive) {
                                                Icons.Outlined.PauseCircleOutline
                                            } else {
                                                Icons.Outlined.PlayCircleOutline
                                            },
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isActive) "Pause Ad" else "Reactivate Ad")
                                    }
                                }
                                if (listing.status != FirestoreListingStatus.SOLD.name) {
                                    Button(
                                        onClick = { showMarkSoldConfirmDialog = true },
                                        enabled = !isDeleting && !isUpdatingStatus,
                                        colors = ButtonDefaults.buttonColors(containerColor = VibrantOrange),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("details_mark_sold_button")
                                    ) {
                                        Text("Mark Sold")
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SafetyTipChip("Meet in public daylight spots")
                            SafetyTipChip("Inspect item before paying")
                            SafetyTipChip("No advance online payments")
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    }
}

@Composable
private fun SafetyTipChip(text: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

private fun safeLaunchDialIntent(
    context: Context,
    rawPhone: String,
    onUnavailable: (String) -> Unit
) {
    val cleanedPhone = rawPhone.replace(" ", "").trim()
    if (cleanedPhone.isEmpty()) {
        onUnavailable("Seller phone number is unavailable.")
        return
    }
    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanedPhone")).apply {
        if (context !is Activity) {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    try {
        context.startActivity(dialIntent)
    } catch (_: ActivityNotFoundException) {
        onUnavailable("Phone app is unavailable on this device. Call $rawPhone directly.")
    } catch (_: SecurityException) {
        onUnavailable("Unable to open phone dialer on this device.")
    }
}

private fun safeLaunchShareIntent(
    context: Context,
    shareText: String,
    onUnavailable: (String) -> Unit
) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText)
    }
    val chooserIntent = Intent.createChooser(shareIntent, "Share listing").apply {
        if (context !is Activity) {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    try {
        context.startActivity(chooserIntent)
    } catch (_: ActivityNotFoundException) {
        onUnavailable("No sharing or messaging app is available on this device.")
    } catch (_: SecurityException) {
        onUnavailable("Unable to share listing on this device.")
    }
}
