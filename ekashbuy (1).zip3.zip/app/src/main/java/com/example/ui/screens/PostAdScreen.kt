package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LockClock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.data.media.AdPhotoValidator
import com.example.data.media.MAX_AD_PHOTOS
import com.example.data.media.PhotoCandidate
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.example.model.PostAdDraft
import com.example.ui.components.AuthRequiredCard
import com.example.ui.components.BusinessRulesBanner
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.PostAdPhotoSection
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange
import kotlinx.coroutines.flow.drop

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PostAdScreen(
    uiState: MarketplaceUiState,
    onUpdateDraft: ((PostAdDraft) -> PostAdDraft) -> Unit,
    onResetDraft: () -> Unit,
    onSubmitListing: (
        title: String,
        priceText: String,
        isMonthlyRent: Boolean,
        negotiable: Boolean,
        category: AdCategory,
        district: KashmirDistrict,
        locality: String,
        condition: AdCondition,
        description: String,
        sellerName: String,
        sellerPhone: String
    ) -> Unit,
    onAddPhotoCandidates: (List<PhotoCandidate>) -> Unit,
    onRemovePhoto: (Int) -> Unit,
    onMovePhoto: (fromIndex: Int, toIndex: Int) -> Unit,
    onSetMainPhoto: (Int) -> Unit,
    onPhotoError: (String?) -> Unit,
    onClearMessages: () -> Unit,
    onOpenMyAds: () -> Unit,
    onOpenLogin: () -> Unit,
    onOpenRegister: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val draft = uiState.postAdDraft
    val isEditing = draft.editingListingId != null
    var showFeaturedDialog by remember { mutableStateOf(false) }

    var titleValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.title, TextRange(draft.title.length)))
    }
    var priceValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.priceText, TextRange(draft.priceText.length)))
    }
    var localityValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.locality, TextRange(draft.locality.length)))
    }
    var descriptionValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.description, TextRange(draft.description.length)))
    }
    var sellerNameValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.sellerName, TextRange(draft.sellerName.length)))
    }
    var sellerPhoneValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(draft.sellerPhone, TextRange(draft.sellerPhone.length)))
    }

    LaunchedEffect(draft.draftVersion, draft.editingListingId) {
        titleValue = TextFieldValue(draft.title, TextRange(draft.title.length))
        priceValue = TextFieldValue(draft.priceText, TextRange(draft.priceText.length))
        localityValue = TextFieldValue(draft.locality, TextRange(draft.locality.length))
        descriptionValue = TextFieldValue(draft.description, TextRange(draft.description.length))
        val resolvedName = draft.sellerName.ifBlank { uiState.currentUserName }
        sellerNameValue = TextFieldValue(resolvedName, TextRange(resolvedName.length))
        val resolvedPhone = draft.sellerPhone.ifBlank { uiState.currentUserPhone }
        sellerPhoneValue = TextFieldValue(resolvedPhone, TextRange(resolvedPhone.length))
    }

    LaunchedEffect(uiState.currentUserName, uiState.currentUserPhone) {
        if (!isEditing) {
            if (sellerNameValue.text.isBlank() && uiState.currentUserName.isNotBlank()) {
                sellerNameValue = TextFieldValue(
                    uiState.currentUserName,
                    TextRange(uiState.currentUserName.length)
                )
            }
            if (sellerPhoneValue.text.isBlank() && uiState.currentUserPhone.isNotBlank()) {
                sellerPhoneValue = TextFieldValue(
                    uiState.currentUserPhone,
                    TextRange(uiState.currentUserPhone.length)
                )
            }
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow {
            listOf(
                titleValue.text,
                priceValue.text,
                localityValue.text,
                descriptionValue.text,
                sellerNameValue.text,
                sellerPhoneValue.text
            )
        }
            .drop(1)
            .collect { values ->
                onUpdateDraft { current ->
                    current.copy(
                        title = values[0],
                        priceText = values[1],
                        locality = values[2],
                        description = values[3],
                        sellerName = values[4],
                        sellerPhone = values[5]
                    )
                }
                onClearMessages()
            }
    }

    val multiPhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = MAX_AD_PHOTOS)
    ) { uris ->
        if (uris.isNotEmpty()) {
            val candidates = AdPhotoValidator.inspectPickedUris(context, uris)
            onAddPhotoCandidates(candidates)
        }
    }

    val singlePhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val candidates = AdPhotoValidator.inspectPickedUris(context, listOf(uri))
            onAddPhotoCandidates(candidates)
        }
    }

    val launchPhotoPicker: () -> Unit = {
        val remaining = MAX_AD_PHOTOS - draft.selectedPhotos.size
        if (remaining <= 0) {
            onPhotoError("Maximum $MAX_AD_PHOTOS photos reached. Remove a photo to add another.")
        } else {
            onPhotoError(null)
            try {
                val request = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                if (remaining == 1) {
                    singlePhotoPickerLauncher.launch(request)
                } else {
                    multiPhotoPickerLauncher.launch(request)
                }
            } catch (_: Exception) {
                onPhotoError("Unable to open Android Photo Picker on this device.")
            }
        }
    }

    if (showFeaturedDialog) {
        AlertDialog(
            onDismissRequest = { showFeaturedDialog = false },
            title = { Text("Featured Ads — Coming Soon") },
            text = {
                Text(
                    "Ordinary advertisements on eKashbuy are always free with zero commission. " +
                        "Optional paid Featured Ad placement to highlight listings at the top of search results will be introduced in a future update."
                )
            },
            confirmButton = {
                Button(
                    onClick = { showFeaturedDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("Got It")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isEditing) "Edit Advertisement" else "Post an Ad",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            text = "Free ordinary listing • Direct buyer contact",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = onOpenMyAds,
                        modifier = Modifier.testTag("post_ad_my_ads_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Inventory2,
                            contentDescription = null,
                            tint = RoyalBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("My Ads", color = RoyalBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!uiState.isAuthenticated) {
                AuthRequiredCard(
                    title = "Sign in to Post a Free Ad",
                    subtitle = "Sign in with Google to publish listings and connect directly with local buyers in Kashmir.",
                    onOpenLogin = onOpenLogin,
                    onOpenRegister = onOpenRegister,
                    testTag = "post_ad_signin_prompt"
                )
                BusinessRulesBanner(compact = false)
                return@Column
            }

            if (isEditing) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = RoyalBlueContainer,
                    border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_ad_editing_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Editing your existing advertisement",
                                style = MaterialTheme.typography.labelLarge,
                                color = RoyalBlue
                            )
                        }
                        TextButton(
                            onClick = onResetDraft,
                            modifier = Modifier.testTag("post_ad_cancel_edit_button")
                        ) {
                            Text("Cancel Edit", color = VibrantOrange)
                        }
                    }
                }
            }

            uiState.adActionError?.let { error ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_ad_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ErrorOutline,
                            contentDescription = "Form error",
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Photo Selection & Preview Grid (Android Photo Picker, up to 6 local previews)
            PostAdPhotoSection(
                selectedPhotos = draft.selectedPhotos,
                photoError = draft.photoError,
                enabled = !uiState.isSubmittingAd,
                onAddPhotosClick = launchPhotoPicker,
                onRemovePhoto = onRemovePhoto,
                onMovePhoto = onMovePhoto,
                onSetMainPhoto = onSetMainPhoto,
                onDismissPhotoError = { onPhotoError(null) }
            )

            // Category Selection
            Column {
                Text("Category", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdCategory.entries.forEach { cat ->
                        val selected = draft.category == cat
                        FilterChip(
                            selected = selected,
                            enabled = !uiState.isSubmittingAd,
                            onClick = { onUpdateDraft { it.copy(category = cat) } },
                            label = { Text(cat.shortTitle) },
                            modifier = Modifier.testTag("post_ad_category_${cat.name.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            EkashbuyOutlinedTextField(
                value = titleValue,
                onValueChange = { titleValue = it },
                label = "Ad Title",
                placeholder = "e.g., iPhone 14 128GB in Mint Condition",
                enabled = !uiState.isSubmittingAd,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    autoCorrectEnabled = false,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_ad_title_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EkashbuyOutlinedTextField(
                    value = priceValue,
                    onValueChange = { incoming ->
                        priceValue = TextFieldInputSanitizers.sanitizeDigits(incoming, maxLength = 9)
                    },
                    label = "Price (₹ INR)",
                    placeholder = "e.g., 28000",
                    enabled = !uiState.isSubmittingAd,
                    keyboardOptions = KeyboardOptions(
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("post_ad_price_input")
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Negotiable", style = MaterialTheme.typography.labelMedium)
                    Switch(
                        checked = draft.negotiable,
                        enabled = !uiState.isSubmittingAd,
                        onCheckedChange = { checked -> onUpdateDraft { it.copy(negotiable = checked) } },
                        modifier = Modifier.testTag("post_ad_negotiable_switch"),
                        colors = SwitchDefaults.colors(checkedTrackColor = RoyalBlue)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Monthly", style = MaterialTheme.typography.labelMedium)
                    Switch(
                        checked = draft.isMonthlyRent,
                        enabled = !uiState.isSubmittingAd,
                        onCheckedChange = { checked -> onUpdateDraft { it.copy(isMonthlyRent = checked) } },
                        modifier = Modifier.testTag("post_ad_monthly_rent_switch"),
                        colors = SwitchDefaults.colors(checkedTrackColor = RoyalBlue)
                    )
                }
            }

            // Condition
            Column {
                Text("Item Condition", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdCondition.entries.forEach { cond ->
                        FilterChip(
                            selected = draft.condition == cond,
                            enabled = !uiState.isSubmittingAd,
                            onClick = { onUpdateDraft { it.copy(condition = cond) } },
                            label = { Text(cond.label) },
                            modifier = Modifier.testTag("post_ad_condition_${cond.name.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VibrantOrange,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // District
            Column {
                Text("District in Kashmir", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KashmirDistrict.entries.filter { it != KashmirDistrict.ALL }.forEach { dist ->
                        FilterChip(
                            selected = draft.district == dist,
                            enabled = !uiState.isSubmittingAd,
                            onClick = { onUpdateDraft { it.copy(district = dist) } },
                            label = { Text(dist.displayName) },
                            modifier = Modifier.testTag("post_ad_district_${dist.name.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            EkashbuyOutlinedTextField(
                value = localityValue,
                onValueChange = { localityValue = it },
                label = "Locality / Location",
                placeholder = "e.g., Lal Chowk, Humhama, Sopore, KP Road",
                enabled = !uiState.isSubmittingAd,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    autoCorrectEnabled = false,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_ad_locality_input")
            )

            EkashbuyOutlinedTextField(
                value = descriptionValue,
                onValueChange = { descriptionValue = it },
                label = "Description",
                placeholder = "Share condition, age, accessories, and pickup details…",
                enabled = !uiState.isSubmittingAd,
                singleLine = false,
                minLines = 3,
                maxLines = 5,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    autoCorrectEnabled = false
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_ad_description_input")
            )

            // Seller Details
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Seller Contact Details", style = MaterialTheme.typography.titleSmall)

                EkashbuyOutlinedTextField(
                    value = sellerNameValue,
                    onValueChange = { sellerNameValue = it },
                    label = "Seller Name",
                    placeholder = "Your name shown to buyers",
                    enabled = !uiState.isSubmittingAd,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        autoCorrectEnabled = false,
                        imeAction = ImeAction.Next
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_ad_seller_name_input")
                )

                EkashbuyOutlinedTextField(
                    value = sellerPhoneValue,
                    onValueChange = { incoming ->
                        sellerPhoneValue = TextFieldInputSanitizers.sanitizePhone(incoming)
                    },
                    label = "Direct Contact Number",
                    placeholder = "+91 9XXXXXXXXX",
                    enabled = !uiState.isSubmittingAd,
                    keyboardOptions = KeyboardOptions(
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Done
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_ad_phone_input")
                )
            }

            // Ad Placement Tier Section
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Ad Listing Plan", style = MaterialTheme.typography.titleSmall)

                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = EmeraldContainer,
                    border = BorderStroke(1.5.dp, EmeraldBadge)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = "Selected plan",
                            tint = EmeraldBadge
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Ordinary Advertisement — FREE (₹0)",
                                style = MaterialTheme.typography.titleSmall,
                                color = EmeraldBadge
                            )
                            Text(
                                text = "0% commission • Buyers contact you directly",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { showFeaturedDialog = true }
                        .testTag("post_ad_featured_future_card"),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = "Featured Ad coming soon",
                            tint = VibrantOrange
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Featured Advertisement",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = VibrantOrange.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "Future Paid Feature",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VibrantOrange,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Pin listings at the top of Kashmir search results (coming in a future update)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Outlined.LockClock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            BusinessRulesBanner(compact = true)

            uiState.adActionError?.let { error ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ErrorOutline,
                            contentDescription = "Validation error",
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onResetDraft,
                    enabled = !uiState.isSubmittingAd,
                    modifier = Modifier
                        .weight(0.38f)
                        .height(50.dp)
                        .testTag("post_ad_reset_button")
                ) {
                    Text(if (isEditing) "Cancel" else "Clear")
                }
                Button(
                    onClick = {
                        onSubmitListing(
                            titleValue.text,
                            priceValue.text,
                            draft.isMonthlyRent,
                            draft.negotiable,
                            draft.category,
                            draft.district,
                            localityValue.text,
                            draft.condition,
                            descriptionValue.text,
                            sellerNameValue.text,
                            sellerPhoneValue.text
                        )
                    },
                    enabled = !uiState.isSubmittingAd,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VibrantOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(0.62f)
                        .height(50.dp)
                        .testTag("post_ad_submit_button")
                ) {
                    if (uiState.isSubmittingAd) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isEditing) "Saving…" else "Publishing…")
                    } else {
                        Text(if (isEditing) "Save Changes" else "Publish Free Ad")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
