package com.example.ui.screens

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasAnyAncestor
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.isDialog
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.ActivityResultRegistryOwner
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityOptionsCompat
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.firestore.FavouritesRepository
import com.example.data.firestore.ListingsRepository
import com.example.data.firestore.model.FirestoreFavourite
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.model.FirestoreUser
import com.example.data.media.AdPhotoValidator
import com.example.data.media.PhotoCandidate
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.ChatMessagePreview
import com.example.model.ConversationPreview
import com.example.model.KashmirDistrict
import com.example.model.MarketplaceFilters
import com.example.model.ProductListing
import com.example.model.SelectedAdPhoto
import com.example.ui.components.PostAdPhotoSection
import com.example.ui.navigation.EkashbuyApp
import com.example.ui.state.AuthUiState
import com.example.ui.state.AuthViewModel
import com.example.ui.state.MarketplaceUiState
import com.example.ui.state.MarketplaceViewModel
import com.example.ui.theme.EkashbuyTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MarketplaceScreensTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun homeScreen_displaysSignInLoadingErrorAndLoadedListingsStates() {
        var state by mutableStateOf(MarketplaceUiState(isAuthenticated = false))
        var retryClicks = 0

        composeTestRule.setContent {
            EkashbuyTheme {
                HomeScreen(
                    uiState = state,
                    onSelectHomeDistrict = {},
                    onHomeSearchChange = {},
                    onSubmitSearchToListings = {},
                    onOpenCategories = {},
                    onCategoryClick = {},
                    onOpenAllListings = {},
                    onProductClick = {},
                    onToggleFavorite = {},
                    onOpenMyAds = {},
                    onOpenSell = {},
                    onOpenLogin = {},
                    onOpenRegister = {},
                    onRetryListings = { retryClicks++ }
                )
            }
        }

        // Unauthenticated prompt
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("home_signin_prompt"))
        composeTestRule.onNodeWithTag("home_signin_prompt").assertIsDisplayed()

        // Loading indicator
        state = MarketplaceUiState(isAuthenticated = true, isListingsLoading = true)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("home_loading_indicator"))
        composeTestRule.onNodeWithTag("home_loading_indicator").assertIsDisplayed()

        // Error state + Retry button
        state = MarketplaceUiState(isAuthenticated = true, listingsError = "Network unavailable")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("home_error_state"))
        composeTestRule.onNodeWithTag("home_error_state").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_retry_button").performScrollTo().performClick()
        assertEquals(1, retryClicks)

        // Loaded real listing card
        val sample = ProductListing(
            id = "live_1",
            title = "Kashmir Willow Cricket Bat",
            priceInr = 2500,
            category = AdCategory.FASHION,
            district = KashmirDistrict.ANANTNAG,
            locality = "Bijbehara",
            description = "Grade-A seasoned willow bat from Bijbehara.",
            condition = AdCondition.BRAND_NEW,
            postedAgo = "Just now",
            sellerName = "Tariq Wani",
            sellerPhone = "+919622000588",
            sellerId = "seller_1"
        )
        state = MarketplaceUiState(
            isAuthenticated = true,
            allListings = listOf(sample),
            homeListings = listOf(sample)
        )
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("product_card_live_1"))
        composeTestRule.onNodeWithTag("product_card_live_1").assertIsDisplayed()
    }

    @Test
    fun postAdScreen_typingDoesNotDuplicateCharacters_andSubmitsAllFields() {
        var uiState by mutableStateOf(
            MarketplaceUiState(
                isAuthenticated = true,
                currentUserId = "uid_1",
                adActionError = "Previous validation warning"
            )
        )
        var capturedTitle = ""
        var capturedPrice = ""
        var capturedLocality = ""
        var capturedDescription = ""
        var capturedSellerName = ""
        var capturedPhone = ""

        composeTestRule.setContent {
            EkashbuyTheme {
                PostAdScreen(
                    uiState = uiState,
                    onUpdateDraft = { transform ->
                        uiState = uiState.copy(postAdDraft = transform(uiState.postAdDraft))
                    },
                    onResetDraft = {},
                    onSubmitListing = { title, price, _, _, _, _, locality, _, desc, sellerName, phone ->
                        capturedTitle = title
                        capturedPrice = price
                        capturedLocality = locality
                        capturedDescription = desc
                        capturedSellerName = sellerName
                        capturedPhone = phone
                    },
                    onAddPhotoCandidates = {},
                    onRemovePhoto = {},
                    onMovePhoto = { _, _ -> },
                    onSetMainPhoto = {},
                    onPhotoError = {},
                    onClearMessages = {
                        uiState = uiState.copy(adActionError = null)
                    },
                    onOpenMyAds = {},
                    onOpenLogin = {},
                    onOpenRegister = {}
                )
            }
        }

        val titleNode = composeTestRule.onNodeWithTag("post_ad_title_input")
        titleNode.performScrollTo()
        titleNode.performClick()
        "Swift Car".forEach { ch -> titleNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        titleNode.assertTextContains("Swift Car")

        val priceNode = composeTestRule.onNodeWithTag("post_ad_price_input")
        priceNode.performScrollTo()
        priceNode.performClick()
        "450000".forEach { ch -> priceNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        priceNode.assertTextContains("450000")

        val localityNode = composeTestRule.onNodeWithTag("post_ad_locality_input")
        localityNode.performScrollTo()
        localityNode.performClick()
        "Rajbagh".forEach { ch -> localityNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        localityNode.assertTextContains("Rajbagh")

        val descNode = composeTestRule.onNodeWithTag("post_ad_description_input")
        descNode.performScrollTo()
        descNode.performClick()
        "Clean family car".forEach { ch -> descNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()

        val sellerNode = composeTestRule.onNodeWithTag("post_ad_seller_name_input")
        sellerNode.performScrollTo()
        sellerNode.performClick()
        "Aamir".forEach { ch -> sellerNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        sellerNode.assertTextContains("Aamir")

        val phoneNode = composeTestRule.onNodeWithTag("post_ad_phone_input")
        phoneNode.performScrollTo()
        phoneNode.performClick()
        "9419000112".forEach { ch -> phoneNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        phoneNode.assertTextContains("9419000112")

        val submitBtn = composeTestRule.onNodeWithTag("post_ad_submit_button")
        submitBtn.performScrollTo()
        submitBtn.performClick()
        composeTestRule.waitForIdle()

        assertEquals("Swift Car", capturedTitle)
        assertEquals("450000", capturedPrice)
        assertEquals("Rajbagh", capturedLocality)
        assertEquals("Clean family car", capturedDescription)
        assertEquals("Aamir", capturedSellerName)
        assertEquals("9419000112", capturedPhone)
    }

    @Test
    fun productDetailsScreen_showsOwnerEditDeleteForOwner_andCallMessageForBuyer() {
        val listing = ProductListing(
            id = "ad_99",
            title = "Pashmina Shawl",
            priceInr = 18000,
            category = AdCategory.FASHION,
            district = KashmirDistrict.BARAMULLA,
            locality = "Pattan",
            description = "Authentic handwoven winter Pashmina shawl from Pattan.",
            condition = AdCondition.BRAND_NEW,
            postedAgo = "1h ago",
            sellerName = "Shazia Akhtar",
            sellerPhone = "+918899000832",
            sellerId = "owner_uid"
        )
        var isOwner by mutableStateOf(true)
        var editClicked = false
        var deletedId: String? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                ProductDetailsScreen(
                    listing = listing,
                    isLoading = false,
                    isOwnListing = isOwner,
                    isDeleting = false,
                    isFavorite = false,
                    onToggleFavorite = {},
                    onNavigateBack = {},
                    onOpenMessagesPreview = {},
                    onEditListing = { editClicked = true },
                    onDeleteListing = { deletedId = it }
                )
            }
        }

        composeTestRule.onNodeWithText("+918899000832").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("details_edit_button").performClick()
        assertTrue(editClicked)

        composeTestRule.onNodeWithTag("details_delete_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("details_confirm_delete_button").performClick()
        assertEquals("ad_99", deletedId)

        // Buyer view shows Call Seller and Message instead of Edit/Delete
        isOwner = false
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("details_call_seller_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("details_message_seller_button").assertIsDisplayed()
    }

    @Test
    fun productDetailsScreen_handlesUnavailableDialAndShareAppsWithoutCrashing() {
        val listing = ProductListing(
            id = "ad_missing_apps",
            title = "Handcrafted Walnut Table",
            priceInr = 12500,
            category = AdCategory.HOME_FURNITURE,
            district = KashmirDistrict.SRINAGAR,
            locality = "Rainawari",
            description = "Carved walnut side table in excellent condition.",
            condition = AdCondition.LIKE_NEW,
            postedAgo = "2h ago",
            sellerName = "Tariq Lone",
            sellerPhone = "+919419000555",
            sellerId = "other_seller"
        )

        composeTestRule.setContent {
            val baseContext = LocalContext.current
            val noAppsContext = object : ContextWrapper(baseContext) {
                override fun startActivity(intent: Intent?) {
                    throw ActivityNotFoundException("No Activity found to handle Intent { ${intent?.action} }")
                }
            }
            EkashbuyTheme {
                CompositionLocalProvider(LocalContext provides noAppsContext) {
                    ProductDetailsScreen(
                        listing = listing,
                        isLoading = false,
                        isOwnListing = false,
                        isDeleting = false,
                        isFavorite = false,
                        onToggleFavorite = {},
                        onNavigateBack = {},
                        onOpenMessagesPreview = {},
                        onEditListing = {},
                        onDeleteListing = {}
                    )
                }
            }
        }

        // Bottom Call Seller button handles ActivityNotFoundException cleanly
        composeTestRule.onNodeWithTag("details_call_seller_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Phone app is unavailable on this device. Call +919419000555 directly.")
            .assertIsDisplayed()

        // Top bar Share button handles ActivityNotFoundException cleanly
        composeTestRule.onNodeWithTag("details_share_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("No sharing or messaging app is available on this device.")
            .assertIsDisplayed()

        // Message Seller dialog -> Call Seller handles ActivityNotFoundException cleanly
        composeTestRule.onNodeWithTag("details_message_seller_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Direct Seller Contact").assertIsDisplayed()
        composeTestRule.onNode(hasText("Call Seller") and hasAnyAncestor(isDialog())).performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Phone app is unavailable on this device. Call +919419000555 directly.")
            .assertIsDisplayed()
    }

    @Test
    fun postAdPhotoSection_displaysSixLimit_countIndicator_mainBadge_reorder_remove_andErrorBanner() {
        var photos by mutableStateOf<List<SelectedAdPhoto>>(emptyList())
        var photoError by mutableStateOf<String?>(null)
        var addClicks = 0

        composeTestRule.setContent {
            EkashbuyTheme {
                PostAdPhotoSection(
                    selectedPhotos = photos,
                    photoError = photoError,
                    enabled = true,
                    onAddPhotosClick = { addClicks++ },
                    onRemovePhoto = { index ->
                        photos = AdPhotoValidator.removePhotoAt(photos, index)
                    },
                    onMovePhoto = { from, to ->
                        photos = AdPhotoValidator.movePhoto(photos, from, to)
                    },
                    onSetMainPhoto = { index ->
                        photos = AdPhotoValidator.setMainPhoto(photos, index)
                    },
                    onDismissPhotoError = { photoError = null }
                )
            }
        }

        // Initial empty state shows 0/6 and picker card
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("0/6")
        composeTestRule.onNodeWithTag("post_ad_photo_picker").performClick()
        assertEquals(1, addClicks)

        // Add 3 photos -> 3/6 indicator, grid visible, MAIN badge on first item
        photos = listOf(
            SelectedAdPhoto("1", "content://media/picker/1", "front.jpg"),
            SelectedAdPhoto("2", "content://media/picker/2", "side.jpg"),
            SelectedAdPhoto("3", "content://media/picker/3", "back.jpg")
        )
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("3/6")
        composeTestRule.onNodeWithTag("post_ad_photo_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_main_photo_badge").assertIsDisplayed()

        // Move index 0 right -> item "2" becomes main
        composeTestRule.onNodeWithTag("post_ad_photo_move_right_0").performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf("2", "1", "3"), photos.map { it.id })

        // Set index 2 ("3") as main -> moves to index 0
        composeTestRule.onNodeWithTag("post_ad_photo_set_main_2").performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf("3", "2", "1"), photos.map { it.id })

        // Remove middle photo -> 2/6 indicator
        composeTestRule.onNodeWithTag("post_ad_photo_remove_1").performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf("3", "1"), photos.map { it.id })
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("2/6")

        // Validation error banner renders and dismisses cleanly
        photoError = "Maximum 6 photos allowed per ad (1 extra skipped)."
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_error_banner").assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_photo_error_dismiss").performClick()
        composeTestRule.waitForIdle()
        assertEquals(null, photoError)

        // Fill up to 6 photos -> 6/6 indicator
        val merged = AdPhotoValidator.mergeSelectedPhotos(
            existing = photos,
            candidates = (10..15).map { idx ->
                PhotoCandidate("content://media/picker/$idx", "img_$idx.jpg", "image/jpeg", 2048L)
            }
        )
        photos = merged.photos
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("6/6")
        composeTestRule.onNodeWithText("Maximum 6/6 Photos Selected").assertIsDisplayed()
    }

    @Test
    fun postAdFlow_preservesSelectedPhotosCountAndMainOrderAcrossNavigation() {
        val alice = AuthUser(
            uid = "alice_1",
            displayName = "Alice Bhat",
            email = "alice@ekashbuy.in",
            phoneNumber = "+919419000111"
        )
        val authRepo = FakeNavAuthRepository(alice)
        val listingsRepo = FakeNavListingsRepository()
        val favRepo = FakeNavFavouritesRepository()
        val marketplaceViewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)
        val authViewModel = AuthViewModel(authRepo)

        composeTestRule.setContent {
            EkashbuyTheme {
                EkashbuyApp(
                    viewModel = marketplaceViewModel,
                    authViewModel = authViewModel
                )
            }
        }

        // Navigate to Sell tab
        composeTestRule.onNodeWithTag("bottom_nav_sell").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator")
            .performScrollTo()
            .assertTextContains("0/6")

        // Select 3 photos and promote index 1 ("picker/2") to main
        composeTestRule.runOnUiThread {
            marketplaceViewModel.addSelectedPhotoCandidates(
                listOf(
                    PhotoCandidate("content://media/picker/1", "one.jpg", "image/jpeg", 1024L),
                    PhotoCandidate("content://media/picker/2", "two.jpg", "image/jpeg", 1024L),
                    PhotoCandidate("content://media/picker/3", "three.jpg", "image/jpeg", 1024L)
                )
            )
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("3/6")
        composeTestRule.onNodeWithTag("post_ad_photo_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_photo_set_main_1").performClick()
        composeTestRule.waitForIdle()
        assertEquals(
            "content://media/picker/2",
            marketplaceViewModel.uiState.value.postAdDraft.mainPhoto?.uriString
        )

        // Navigate to My Ads and back to Post Ad
        composeTestRule.onNodeWithTag("post_ad_my_ads_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("my_ads_back_button").performClick()
        composeTestRule.waitForIdle()

        // Switch away to Home tab and back to Sell tab
        composeTestRule.onNodeWithTag("bottom_nav_home").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("bottom_nav_sell").performClick()
        composeTestRule.waitForIdle()

        // Verify 3/6 count, preview grid, main badge, and promoted main photo order survived navigation
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator")
            .performScrollTo()
            .assertTextContains("3/6")
        composeTestRule.onNodeWithTag("post_ad_photo_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_main_photo_badge").assertIsDisplayed()
        assertEquals(
            listOf(
                "content://media/picker/2",
                "content://media/picker/1",
                "content://media/picker/3"
            ),
            marketplaceViewModel.uiState.value.postAdDraft.selectedPhotos.map { it.uriString }
        )
    }

    @Test
    fun postAdScreen_opensAndroidPhotoPicker_selectsUpToSix_reordersAndHandlesSingleRemainingSlot() {
        val alice = AuthUser(
            uid = "alice_1",
            displayName = "Alice Bhat",
            email = "alice@ekashbuy.in",
            phoneNumber = "+919419000111"
        )
        val marketplaceViewModel = MarketplaceViewModel(
            FakeNavAuthRepository(alice),
            FakeNavListingsRepository(),
            FakeNavFavouritesRepository()
        )
        val launchedContracts = mutableListOf<String>()
        var nextMultiResult: List<Uri> = (1..6).map { Uri.parse("content://media/picker/$it") }
        var nextSingleResult: Uri? = Uri.parse("content://media/picker/7")

        val fakeRegistryOwner = object : ActivityResultRegistryOwner {
            override val activityResultRegistry: ActivityResultRegistry = object : ActivityResultRegistry() {
                @Suppress("UNCHECKED_CAST")
                override fun <I, O> onLaunch(
                    requestCode: Int,
                    contract: ActivityResultContract<I, O>,
                    input: I,
                    options: ActivityOptionsCompat?
                ) {
                    launchedContracts += contract.javaClass.simpleName
                    val intent = contract.createIntent(
                        androidx.test.core.app.ApplicationProvider.getApplicationContext(),
                        input
                    )
                    when (contract) {
                        is ActivityResultContracts.PickMultipleVisualMedia -> {
                            assertTrue(
                                intent.action == MediaStore.ACTION_PICK_IMAGES ||
                                    intent.action == Intent.ACTION_OPEN_DOCUMENT
                            )
                            dispatchResult(requestCode, nextMultiResult as O)
                        }
                        is ActivityResultContracts.PickVisualMedia -> {
                            assertTrue(
                                intent.action == MediaStore.ACTION_PICK_IMAGES ||
                                    intent.action == Intent.ACTION_OPEN_DOCUMENT
                            )
                            dispatchResult(requestCode, nextSingleResult as O)
                        }
                    }
                }
            }
        }

        composeTestRule.setContent {
            val state by marketplaceViewModel.uiState.collectAsState()
            EkashbuyTheme {
                CompositionLocalProvider(LocalActivityResultRegistryOwner provides fakeRegistryOwner) {
                    PostAdScreen(
                        uiState = state,
                        onUpdateDraft = marketplaceViewModel::updatePostAdDraft,
                        onResetDraft = marketplaceViewModel::resetPostAdDraft,
                        onSubmitListing = { _, _, _, _, _, _, _, _, _, _, _ -> },
                        onAddPhotoCandidates = marketplaceViewModel::addSelectedPhotoCandidates,
                        onRemovePhoto = marketplaceViewModel::removeSelectedPhoto,
                        onMovePhoto = marketplaceViewModel::moveSelectedPhoto,
                        onSetMainPhoto = marketplaceViewModel::setMainSelectedPhoto,
                        onPhotoError = marketplaceViewModel::setPhotoSelectionError,
                        onClearMessages = marketplaceViewModel::clearAdMessages,
                        onOpenMyAds = {},
                        onOpenLogin = {},
                        onOpenRegister = {}
                    )
                }
            }
        }

        // Launch multi-photo picker -> 6/6 photos displayed in grid
        composeTestRule.onNodeWithTag("post_ad_photo_picker")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf("PickMultipleVisualMedia"), launchedContracts)
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("6/6")
        composeTestRule.onNodeWithTag("post_ad_photo_grid").assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_photo_item_5").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("post_ad_main_photo_badge").performScrollTo().assertIsDisplayed()

        // Remove 1 photo -> drops to 5/6
        composeTestRule.onNodeWithTag("post_ad_photo_remove_0").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("5/6")
        assertEquals(
            "content://media/picker/2",
            marketplaceViewModel.uiState.value.postAdDraft.mainPhoto?.uriString
        )

        // When 1 slot remains (5/6), clicking Add More Photos uses single PickVisualMedia contract
        composeTestRule.onNodeWithTag("post_ad_add_more_photos_button")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf("PickMultipleVisualMedia", "PickVisualMedia"), launchedContracts)
        composeTestRule.onNodeWithTag("post_ad_photo_count_indicator").assertTextContains("6/6")
        assertEquals(6, marketplaceViewModel.uiState.value.postAdDraft.selectedPhotoCount)
    }

    @Test
    fun messagesScreen_handlesAuthLoadingErrorAndLiveReplyComposer() {
        var state by mutableStateOf(MarketplaceUiState(isAuthenticated = false))
        var retryClicks = 0
        var sentConvId = ""
        var sentText = ""

        composeTestRule.setContent {
            EkashbuyTheme {
                MessagesScreen(
                    uiState = state,
                    onOpenProductDetails = {},
                    onSelectConversation = { id ->
                        state = state.copy(selectedConversationId = id)
                    },
                    onSendMessage = { convId, text, onDone ->
                        sentConvId = convId
                        sentText = text
                        onDone()
                    },
                    onRetryConversations = { retryClicks++ }
                )
            }
        }

        // Signed-out gate
        composeTestRule.onNodeWithTag("messages_signin_prompt").assertIsDisplayed()

        // Loading state
        state = MarketplaceUiState(isAuthenticated = true, isConversationsLoading = true)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("messages_loading_indicator").assertIsDisplayed()

        // Error + retry
        state = MarketplaceUiState(isAuthenticated = true, conversationsError = "Network unavailable")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("messages_error_state").assertIsDisplayed()
        composeTestRule.onNodeWithTag("messages_retry_button").performClick()
        assertEquals(1, retryClicks)

        // Loaded conversation -> open thread -> type reply -> send
        val conv = ConversationPreview(
            id = "conv_1",
            participantName = "Tariq Lone",
            district = KashmirDistrict.SRINAGAR,
            productId = "ad_1",
            productTitle = "Walnut Chair Set",
            productPriceInr = 22000,
            lastMessage = "Is this available?",
            timestamp = "2m ago",
            isBuyingInquiry = true
        )
        state = MarketplaceUiState(
            isAuthenticated = true,
            currentUserId = "alice_1",
            conversations = listOf(conv),
            activeConversationMessages = listOf(
                ChatMessagePreview(
                    id = "m1",
                    senderName = "You",
                    text = "Is this available?",
                    timeLabel = "2m ago",
                    isFromBuyer = true,
                    isFromCurrentUser = true
                )
            )
        )
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("conversation_card_conv_1").performClick()
        composeTestRule.waitForIdle()

        val input = composeTestRule.onNodeWithTag("chat_message_input")
        input.performClick()
        "Yes please".forEach { ch -> input.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        input.assertTextContains("Yes please")

        composeTestRule.onNodeWithTag("chat_send_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals("conv_1", sentConvId)
        assertEquals("Yes please", sentText)
    }

    @Test
    fun myAdsScreen_supportsPausedToSoldTransition_andRemovingUnavailableSavedFavourite() {
        val pausedAd = ProductListing(
            id = "paused_1",
            title = "Paused Copper Samovar",
            priceInr = 5500,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Zainakadal",
            description = "Engraved copper samovar.",
            condition = AdCondition.GOOD,
            postedAgo = "1d ago",
            sellerName = "Alice",
            sellerPhone = "+919419000111",
            sellerId = "alice_1",
            status = FirestoreListingStatus.PAUSED.name
        )
        val soldAd = pausedAd.copy(id = "sold_1", title = "Sold Rug", status = FirestoreListingStatus.SOLD.name)
        val staleFav = FirestoreFavourite(
            id = "alice_1_gone_1",
            userId = "alice_1",
            listingId = "gone_1",
            listingTitle = "Deleted Pashmina Coat",
            priceInr = 14000L,
            district = KashmirDistrict.BARAMULLA.name
        )
        var statusUpdate: Pair<String, FirestoreListingStatus>? = null
        var toggledFavId: String? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                MyAdsScreen(
                    uiState = MarketplaceUiState(
                        isAuthenticated = true,
                        currentUserId = "alice_1",
                        myListings = listOf(pausedAd, soldAd),
                        favoriteIds = setOf("gone_1"),
                        savedFavourites = listOf(staleFav)
                    ),
                    onNavigateBack = {},
                    onOpenSell = {},
                    onProductClick = {},
                    onEditListing = {},
                    onUpdateStatus = { id, status -> statusUpdate = id to status },
                    onDeleteListing = {},
                    onToggleFavorite = { id -> toggledFavId = id },
                    onRetryMyAds = {},
                    onClearMessages = {},
                    onOpenLogin = {},
                    onOpenRegister = {}
                )
            }
        }

        // Paused / Sold tab allows marking a paused ad as Sold after confirmation
        composeTestRule.onNodeWithTag("my_ads_tab_inactive").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("my_ad_sold_paused_1").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("my_ads_confirm_sold_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals("paused_1" to FirestoreListingStatus.SOLD, statusUpdate)
        composeTestRule.onNodeWithTag("my_ad_sold_sold_1").assertDoesNotExist()

        // Saved tab displays unavailable favourited ad with working Remove button
        composeTestRule.onNodeWithTag("my_ads_tab_saved").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("saved_unavailable_card_gone_1").assertIsDisplayed()
        composeTestRule.onNodeWithTag("saved_remove_button_gone_1").performClick()
        assertEquals("gone_1", toggledFavId)
    }

    @Test
    fun profileScreen_editProfileDialog_submitsUpdatedDetails() {
        val user = AuthUser("uid_1", "Alice Bhat", "alice@ekashbuy.in", "+919419000111")
        val profile = FirestoreUser(
            id = "uid_1",
            userId = "uid_1",
            displayName = "Alice Bhat",
            mobileNumber = "+919419000111",
            district = KashmirDistrict.SRINAGAR.name,
            locality = "Rajbagh"
        )
        var capturedName = ""
        var capturedDistrict: KashmirDistrict? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                ProfileScreen(
                    uiState = MarketplaceUiState(isAuthenticated = true, currentUserId = "uid_1"),
                    authState = AuthUiState(currentUser = user, userProfile = profile),
                    onSelectHomeDistrict = {},
                    onOpenMyAds = {},
                    onOpenLogin = {},
                    onOpenRegister = {},
                    onSignOut = {},
                    onUpdateProfile = { name, _, dist, _, onDone ->
                        capturedName = name
                        capturedDistrict = dist
                        onDone()
                    }
                )
            }
        }

        composeTestRule.onNodeWithTag("profile_edit_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("profile_edit_district_budgam").performClick()
        composeTestRule.onNodeWithTag("profile_edit_name_input").performTextInput(" Jr")
        composeTestRule.onNodeWithTag("profile_edit_save_button").performClick()
        composeTestRule.waitForIdle()

        assertEquals("Alice Bhat Jr", capturedName)
        assertEquals(KashmirDistrict.BUDGAM, capturedDistrict)
    }

    @Test
    fun productDetailsScreen_ownerStatusActions_andBuyerLiveMessageSubmit() {
        val listing = ProductListing(
            id = "ad_77",
            title = "Brass Kangri Set",
            priceInr = 3200,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.BUDGAM,
            locality = "Chadoora",
            description = "Handwoven willow kangri set from Chadoora.",
            condition = AdCondition.BRAND_NEW,
            postedAgo = "3h ago",
            sellerName = "Rashid Dar",
            sellerPhone = "+919419000777",
            sellerId = "owner_1",
            status = FirestoreListingStatus.ACTIVE.name
        )
        var isOwner by mutableStateOf(true)
        var updatedStatus: Pair<String, FirestoreListingStatus>? = null
        var startedMessage = ""

        composeTestRule.setContent {
            EkashbuyTheme {
                ProductDetailsScreen(
                    listing = listing,
                    isLoading = false,
                    isOwnListing = isOwner,
                    isDeleting = false,
                    isFavorite = false,
                    onToggleFavorite = {},
                    onNavigateBack = {},
                    onOpenMessagesPreview = {},
                    onEditListing = {},
                    onDeleteListing = {},
                    isAuthenticated = true,
                    onUpdateStatus = { id, status -> updatedStatus = id to status },
                    onStartConversation = { _, message -> startedMessage = message }
                )
            }
        }

        composeTestRule.onNodeWithTag("details_status_toggle_button").performScrollTo().performClick()
        assertEquals("ad_77" to FirestoreListingStatus.PAUSED, updatedStatus)

        composeTestRule.onNodeWithTag("details_mark_sold_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("details_confirm_sold_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals("ad_77" to FirestoreListingStatus.SOLD, updatedStatus)

        isOwner = false
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("details_message_seller_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("details_send_message_button").performClick()
        assertTrue(startedMessage.contains("Brass Kangri Set"))
    }

    @Test
    fun productListingsScreen_customMinMaxPriceRangeValidation_andSearchHistoryChips() {
        var filters by mutableStateOf(MarketplaceFilters())
        var searchHistory by mutableStateOf(listOf("Carpet", "iPhone"))
        var clearedHistory = false

        composeTestRule.setContent {
            EkashbuyTheme {
                ProductListingsScreen(
                    uiState = MarketplaceUiState(
                        isAuthenticated = true,
                        currentUserId = "alice_1",
                        filters = filters,
                        searchHistory = searchHistory
                    ),
                    onUpdateFilters = { transform -> filters = transform(filters) },
                    onResetFilters = { filters = MarketplaceFilters() },
                    onProductClick = {},
                    onToggleFavorite = {},
                    onNavigateBack = {},
                    onOpenLogin = {},
                    onOpenRegister = {},
                    onRetryListings = {},
                    onOpenSell = {},
                    onClearSearchHistory = {
                        clearedHistory = true
                        searchHistory = emptyList()
                    }
                )
            }
        }

        // Tapping history chip populates search query
        composeTestRule.onNodeWithTag("listings_search_history_chip_0").performClick()
        composeTestRule.waitForIdle()
        assertEquals("Carpet", filters.query)

        // Open filter bottom sheet and validate Min > Max guard
        composeTestRule.onNodeWithTag("listings_open_filters_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("filter_min_price_input").performScrollTo().performTextInput("50000")
        composeTestRule.onNodeWithTag("filter_max_price_input").performScrollTo().performTextInput("20000")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("filter_price_error").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("filter_sheet_apply_button").assertIsNotEnabled()

        // Fix max > min and apply
        composeTestRule.onNodeWithTag("filter_max_price_input").performTextInput("0")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("filter_price_error").assertDoesNotExist()
        composeTestRule.onNodeWithTag("filter_sheet_apply_button")
            .performScrollTo()
            .assertIsEnabled()
            .performClick()
        composeTestRule.waitForIdle()

        assertEquals(50000, filters.minPriceInr)
        assertEquals(200000, filters.maxPriceInr)

        // Clear search history
        composeTestRule.onNodeWithTag("clear_search_history_button").performClick()
        composeTestRule.waitForIdle()
        assertTrue(clearedHistory)
    }

    @Test
    fun messagesScreen_displaysUnreadBadgeAndFilter_andOpensThreadHistory() {
        val unreadConv = ConversationPreview(
            id = "conv_unread",
            participantName = "Tariq Lone",
            district = KashmirDistrict.SRINAGAR,
            productId = "ad_1",
            productTitle = "Walnut Dining Table",
            productPriceInr = 22000,
            lastMessage = "Still interested in inspecting tomorrow?",
            timestamp = "5m ago",
            isBuyingInquiry = false,
            unreadCount = 1,
            lastSenderId = "tariq_2"
        )
        val readConv = ConversationPreview(
            id = "conv_read",
            participantName = "Shazia",
            district = KashmirDistrict.BUDGAM,
            productId = "ad_2",
            productTitle = "Pashmina Wrap",
            productPriceInr = 9500,
            lastMessage = "Thanks!",
            timestamp = "1h ago",
            isBuyingInquiry = true,
            unreadCount = 0,
            lastSenderId = "alice_1"
        )

        composeTestRule.setContent {
            EkashbuyTheme {
                MessagesScreen(
                    uiState = MarketplaceUiState(
                        isAuthenticated = true,
                        currentUserId = "alice_1",
                        conversations = listOf(unreadConv, readConv),
                        unreadConversationsCount = 1
                    ),
                    onOpenProductDetails = {}
                )
            }
        }

        composeTestRule.onNodeWithTag(
            "conversation_unread_badge_conv_unread",
            useUnmergedTree = true
        ).assertIsDisplayed()
        composeTestRule.onNodeWithTag("messages_filter_unread").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("conversation_card_conv_unread").assertIsDisplayed()
        composeTestRule.onNodeWithTag("conversation_card_conv_read").assertDoesNotExist()
    }

    @Test
    fun profileScreen_savedFavoritesRow_opensMyAdsOnSavedTab() {
        val alice = AuthUser(
            uid = "alice_1",
            displayName = "Alice Bhat",
            email = "alice@ekashbuy.in",
            phoneNumber = "+919419000111"
        )
        val authRepo = FakeNavAuthRepository(alice)
        val marketplaceViewModel = MarketplaceViewModel(
            authRepo,
            FakeNavListingsRepository(),
            FakeNavFavouritesRepository()
        )
        val authViewModel = AuthViewModel(authRepo)

        composeTestRule.setContent {
            EkashbuyTheme {
                EkashbuyApp(
                    viewModel = marketplaceViewModel,
                    authViewModel = authViewModel
                )
            }
        }

        composeTestRule.onNodeWithTag("bottom_nav_profile").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("profile_favorites_row").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("No saved listings yet").assertIsDisplayed()
    }

    @Test
    fun productDetailsScreen_buyerSeesUpdatedDetails_soldPill_andUnavailableSoldState() {
        val initialListing = ProductListing(
            id = "ad_99",
            title = "Kani Pashmina Shawl",
            priceInr = 18500,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Zainakadal",
            description = "Authentic handwoven shawl.",
            condition = AdCondition.BRAND_NEW,
            postedAgo = "Just now",
            sellerName = "Aamir Lone",
            sellerPhone = "+919419000111",
            sellerId = "user_a",
            status = FirestoreListingStatus.ACTIVE.name
        )
        var currentListing by mutableStateOf<ProductListing?>(initialListing)

        composeTestRule.setContent {
            EkashbuyTheme {
                ProductDetailsScreen(
                    listing = currentListing,
                    isLoading = false,
                    isOwnListing = false,
                    isDeleting = false,
                    isFavorite = false,
                    onToggleFavorite = {},
                    onNavigateBack = {},
                    onOpenMessagesPreview = {},
                    onEditListing = {},
                    onDeleteListing = {}
                )
            }
        }

        composeTestRule.onNodeWithText("Kani Pashmina Shawl").assertIsDisplayed()

        // Updated details propagate immediately
        currentListing = initialListing.copy(
            title = "Kani Pashmina Shawl - Pure Wool",
            priceInr = 16900,
            locality = "Rajbagh"
        )
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Kani Pashmina Shawl - Pure Wool").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Rajbagh, Srinagar").performScrollTo().assertIsDisplayed()

        // Direct SOLD status displays Sold pill; removal from buyer active stream displays sold/removed empty state
        currentListing = currentListing?.copy(status = FirestoreListingStatus.SOLD.name)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Sold").assertIsDisplayed()

        currentListing = null
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Listing not found").assertIsDisplayed()
        composeTestRule.onNodeWithText("This advertisement may have been removed or sold.").assertIsDisplayed()
    }

    private class FakeNavAuthRepository(initialUser: AuthUser?) : AuthRepository {
        private val state = MutableStateFlow(initialUser)
        override fun observeAuthState(): Flow<AuthUser?> = state.asStateFlow()
        override fun currentUser(): AuthUser? = state.value
        override suspend fun signInWithGoogleIdToken(idToken: String) =
            Result.failure<AuthUser>(UnsupportedOperationException())
        override fun signOut() {
            state.value = null
        }
    }

    private class FakeNavListingsRepository : ListingsRepository {
        override fun observeActiveListings(
            district: KashmirDistrict?,
            category: AdCategory?
        ): Flow<List<FirestoreListing>> = flowOf(emptyList())
        override fun observeSellerListings(sellerId: String): Flow<List<FirestoreListing>> = flowOf(emptyList())
        override suspend fun getListingById(listingId: String): Result<FirestoreListing?> = Result.success(null)
        override suspend fun createListing(listing: FirestoreListing): Result<String> = Result.success("id_1")
        override suspend fun updateListing(listing: FirestoreListing): Result<Unit> = Result.success(Unit)
        override suspend fun updateListingStatus(listingId: String, status: FirestoreListingStatus): Result<Unit> =
            Result.success(Unit)
        override suspend fun deleteListing(listingId: String): Result<Unit> = Result.success(Unit)
    }

    private class FakeNavFavouritesRepository : FavouritesRepository {
        override fun observeUserFavourites(userId: String): Flow<List<FirestoreFavourite>> = flowOf(emptyList())
        override suspend fun addFavourite(listing: FirestoreListing): Result<String> = Result.success("fav_1")
        override suspend fun removeFavourite(listingId: String): Result<Unit> = Result.success(Unit)
    }
}
