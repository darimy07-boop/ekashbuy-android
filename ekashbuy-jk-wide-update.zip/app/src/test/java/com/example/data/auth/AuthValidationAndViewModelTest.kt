package com.example.data.auth

import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreUser
import com.example.model.KashmirDistrict
import com.example.ui.state.AuthViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@OptIn(ExperimentalCoroutinesApi::class)
class AuthValidationAndViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun phoneNormalization_andNameValidation_handleExpectedFormats() {
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("9876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("09876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("919876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("+91 98765-43210"))
        assertEquals("+14155552671", AuthValidation.normalizePhoneToE164("+1 (415) 555-2671"))

        assertNull(AuthValidation.normalizePhoneToE164(""))
        assertNull(AuthValidation.normalizePhoneToE164("12345"))
        assertNull(AuthValidation.normalizePhoneToE164("5876543210"))
        assertNull(AuthValidation.normalizePhoneToE164("abcdefghij"))

        assertNotNull(AuthValidation.validateFullName("A"))
        assertNull(AuthValidation.validateFullName("Aamir Lone"))
    }

    @Test
    fun errorMapper_returnsClearGoogleAuthMessages() {
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_INVALID_CREDENTIAL").contains("Google Sign-In"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_USER_DISABLED").contains("disabled"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL").contains("already exists"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_OPERATION_NOT_ALLOWED").contains("Google Sign-In"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_TOO_MANY_REQUESTS").contains("Too many"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_APP_NOT_AUTHORIZED").contains("SHA-1/SHA-256"))
    }

    @Test
    fun authViewModel_googleSignIn_cancellation_error_andLogout_updateStateCorrectly() = runTest(testDispatcher) {
        val fakeRepo = FakeAuthRepository()
        val fakeProfileRepo = FakeUserProfileRepository()
        val existingProfile = FirestoreUser(
            id = "uid-google-1",
            userId = "uid-google-1",
            displayName = "Zoya Mir",
            mobileNumber = "+919419012345",
            district = KashmirDistrict.SRINAGAR.name,
            locality = "Rajbagh"
        )
        fakeProfileRepo.savedProfiles["uid-google-1"] = existingProfile

        val viewModel = AuthViewModel(authRepository = fakeRepo, userProfileRepository = fakeProfileRepo)

        // Cancelled flow clears loading without error
        viewModel.beginGoogleSignIn()
        assertTrue(viewModel.uiState.value.isLoading)
        viewModel.onGoogleSignInCancelled()
        assertFalse(viewModel.uiState.value.isLoading)
        assertNull(viewModel.uiState.value.errorMessage)

        // Interactive Google Sign-In failure surfaces error
        fakeRepo.nextSignInFailure = IllegalStateException("Google Sign-In credentials could not be verified.")
        viewModel.signInWithGoogleIdToken("bad-token")
        advanceUntilIdle()
        assertNull(viewModel.uiState.value.currentUser)
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(
            "Google Sign-In credentials could not be verified.",
            viewModel.uiState.value.errorMessage
        )

        // Successful Google Sign-In updates currentUser and loads existing Firestore profile
        viewModel.signInWithGoogleIdToken("valid-google-id-token")
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.errorMessage)
        assertFalse(viewModel.uiState.value.isLoading)
        assertFalse(viewModel.uiState.value.isSyncingProfile)
        assertEquals("uid-google-1", viewModel.uiState.value.currentUser?.uid)
        assertEquals("zoya@ekashbuy.in", viewModel.uiState.value.currentUser?.email)
        assertEquals("Rajbagh", viewModel.uiState.value.userProfile?.locality)

        // Sign out clears session and sets info message
        viewModel.signOut()
        advanceUntilIdle()
        assertNull(viewModel.uiState.value.currentUser)
        assertNull(viewModel.uiState.value.userProfile)
        assertNotNull(viewModel.uiState.value.infoMessage)
    }

    @Test
    fun authViewModel_silentSignInFailure_doesNotSurfaceErrorBanner() = runTest(testDispatcher) {
        val fakeRepo = FakeAuthRepository().apply {
            nextSignInFailure = IllegalStateException("Silent check failed")
        }
        val viewModel = AuthViewModel(authRepository = fakeRepo, userProfileRepository = null)

        viewModel.signInWithGoogleIdToken("stale-token", isSilent = true)
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.currentUser)
        assertNull(viewModel.uiState.value.errorMessage)
        assertFalse(viewModel.uiState.value.isLoading)
        assertFalse(viewModel.uiState.value.isSyncingProfile)
    }

    @Test
    fun authViewModel_updateUserProfile_validatesFieldsAndSavesToFirestoreAfterGoogleSignIn() = runTest(testDispatcher) {
        val fakeAuth = FakeAuthRepository()
        val fakeProfileRepo = FakeUserProfileRepository()
        val viewModel = AuthViewModel(authRepository = fakeAuth, userProfileRepository = fakeProfileRepo)

        // Signed-out user cannot update profile
        viewModel.updateUserProfile(
            displayName = "Bilal Bhat",
            mobileNumber = "9876543210",
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh"
        )
        assertEquals("Please sign in to update your profile.", viewModel.uiState.value.errorMessage)

        // Sign in with Google (user initially has no mobile number / Firestore profile)
        viewModel.signInWithGoogleIdToken("valid-google-id-token")
        advanceUntilIdle()
        assertNotNull(viewModel.uiState.value.currentUser)
        assertNull(viewModel.uiState.value.userProfile)

        // Validation rejects KashmirDistrict.ALL and short names
        var successCalls = 0
        viewModel.updateUserProfile(
            displayName = "Z",
            mobileNumber = "9876543210",
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh",
            onSuccess = { successCalls++ }
        )
        assertNotNull(viewModel.uiState.value.errorMessage)
        assertEquals(0, successCalls)

        viewModel.updateUserProfile(
            displayName = "Zoya Mir",
            mobileNumber = "9876543210",
            district = KashmirDistrict.ALL,
            locality = "Rajbagh",
            onSuccess = { successCalls++ }
        )
        assertTrue(viewModel.uiState.value.errorMessage?.contains("district") == true)
        assertEquals(0, successCalls)

        // Valid update normalizes phone and persists to repository
        viewModel.updateUserProfile(
            displayName = "Zoya Tariq",
            mobileNumber = "9876543210",
            district = KashmirDistrict.ANANTNAG,
            locality = "KP Road",
            onSuccess = { successCalls++ }
        )
        advanceUntilIdle()

        assertEquals(1, successCalls)
        assertFalse(viewModel.uiState.value.isUpdatingProfile)
        assertNull(viewModel.uiState.value.errorMessage)
        assertEquals("Profile details updated.", viewModel.uiState.value.infoMessage)
        val saved = fakeProfileRepo.savedProfiles["uid-google-1"]
        assertNotNull(saved)
        assertEquals("Zoya Tariq", saved?.displayName)
        assertEquals("+919876543210", saved?.mobileNumber)
        assertEquals(KashmirDistrict.ANANTNAG.name, saved?.district)
        assertEquals("KP Road", saved?.locality)
    }

    private class FakeUserProfileRepository : UserProfileRepository {
        val savedProfiles = mutableMapOf<String, FirestoreUser>()
        private val flows = mutableMapOf<String, MutableStateFlow<FirestoreUser?>>()

        override fun observeUserProfile(userId: String): Flow<FirestoreUser?> {
            return flows.getOrPut(userId) { MutableStateFlow(savedProfiles[userId]) }.asStateFlow()
        }

        override suspend fun getUserProfile(userId: String): Result<FirestoreUser?> {
            return Result.success(savedProfiles[userId])
        }

        override suspend fun saveUserProfile(user: FirestoreUser): Result<Unit> {
            savedProfiles[user.userId] = user
            flows.getOrPut(user.userId) { MutableStateFlow(user) }.value = user
            return Result.success(Unit)
        }
    }

    private class FakeAuthRepository : AuthRepository {
        private val state = MutableStateFlow<AuthUser?>(null)
        var nextSignInFailure: Throwable? = null

        override fun observeAuthState(): Flow<AuthUser?> = state.asStateFlow()

        override fun currentUser(): AuthUser? = state.value

        override suspend fun signInWithGoogleIdToken(idToken: String): Result<AuthUser> {
            nextSignInFailure?.let { failure ->
                nextSignInFailure = null
                return Result.failure(failure)
            }
            val user = AuthUser(
                uid = "uid-google-1",
                displayName = "Zoya Mir",
                email = "zoya@ekashbuy.in",
                phoneNumber = null,
                providerIds = listOf("google.com")
            )
            state.value = user
            return Result.success(user)
        }

        override fun signOut() {
            state.value = null
        }
    }
}
