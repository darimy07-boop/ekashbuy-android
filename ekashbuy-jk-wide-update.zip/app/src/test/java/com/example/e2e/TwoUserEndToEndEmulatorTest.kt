package com.example.e2e

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.auth.FirebaseAuthRepository
import com.example.data.firestore.FirestoreFavouritesRepository
import com.example.data.firestore.FirestoreListingsRepository
import com.example.data.firestore.FirestoreMessagesRepository
import com.example.data.firestore.FirestoreUserRepository
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.toFirestoreListingSnapshot
import com.example.data.firestore.unwrapFirestoreException
import com.example.data.local.InMemoryMarketplaceLocalStore
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.example.ui.state.AuthViewModel
import com.example.ui.state.MarketplaceViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

/**
 * Two-user end-to-end integration test executed against the real Firebase Auth and
 * Cloud Firestore Emulators (127.0.0.1:9099 and 127.0.0.1:8085) enforcing live firestore.rules.
 *
 * Uses two independent named FirebaseApp sessions ("e2e_user_a" and "e2e_user_b") wired into
 * separate real repository, AuthViewModel, and MarketplaceViewModel stacks so User A and User B
 * run concurrently with distinct Firebase Auth tokens.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [36])
@LooperMode(LooperMode.Mode.INSTRUMENTATION_TEST)
class TwoUserEndToEndEmulatorTest {

    private lateinit var mainExecutor: ExecutorService
    private lateinit var mainDispatcher: ExecutorCoroutineDispatcher

    private lateinit var authA: FirebaseAuth
    private lateinit var firestoreA: FirebaseFirestore
    private lateinit var authB: FirebaseAuth
    private lateinit var firestoreB: FirebaseFirestore

    private val activeJobs = mutableListOf<Job>()

    @Before
    fun setUp() {
        mainExecutor = Executors.newSingleThreadExecutor()
        mainDispatcher = mainExecutor.asCoroutineDispatcher()
        Dispatchers.setMain(mainDispatcher)

        val context = ApplicationProvider.getApplicationContext<Context>()
        val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
        val databaseId = if (resId != 0) context.getString(resId) else "(default)"

        val appA = getOrCreateNamedEmulatorApp(context, APP_NAME_USER_A, databaseId)
        val appB = getOrCreateNamedEmulatorApp(context, APP_NAME_USER_B, databaseId)

        authA = FirebaseAuth.getInstance(appA)
        firestoreA = FirebaseFirestore.getInstance(appA, databaseId)
        authB = FirebaseAuth.getInstance(appB)
        firestoreB = FirebaseFirestore.getInstance(appB, databaseId)

        authA.signOut()
        authB.signOut()
    }

    @After
    fun tearDown() {
        activeJobs.forEach { it.cancel() }
        activeJobs.clear()
        authA.signOut()
        authB.signOut()
        Dispatchers.resetMain()
        mainExecutor.shutdownNow()
    }

    @Test
    fun twoUsers_fullMarketplaceLifecycle_andSecurityIsolation() = runBlocking {
        val runSuffix = UUID.randomUUID().toString().replace("-", "").take(8)

        // Real repository + ViewModel stack for User A
        val userRepoA = FirestoreUserRepository(firestoreA, authA)
        val authRepoA = FirebaseAuthRepository(authA, userRepoA)
        val listingsRepoA = FirestoreListingsRepository(firestoreA, authA)
        val favRepoA = FirestoreFavouritesRepository(firestoreA, authA)
        val msgRepoA = FirestoreMessagesRepository(firestoreA, authA)
        val localStoreA = InMemoryMarketplaceLocalStore()
        val authVmA = AuthViewModel(authRepoA, userRepoA)
        val marketVmA = MarketplaceViewModel(
            authRepository = authRepoA,
            listingsRepository = listingsRepoA,
            favouritesRepository = favRepoA,
            userProfileRepository = userRepoA,
            messagesRepository = msgRepoA,
            localStore = localStoreA
        )

        // Real repository + ViewModel stack for User B
        val userRepoB = FirestoreUserRepository(firestoreB, authB)
        val authRepoB = FirebaseAuthRepository(authB, userRepoB)
        val listingsRepoB = FirestoreListingsRepository(firestoreB, authB)
        val favRepoB = FirestoreFavouritesRepository(firestoreB, authB)
        val msgRepoB = FirestoreMessagesRepository(firestoreB, authB)
        val localStoreB = InMemoryMarketplaceLocalStore()
        val authVmB = AuthViewModel(authRepoB, userRepoB)
        val marketVmB = MarketplaceViewModel(
            authRepository = authRepoB,
            listingsRepository = listingsRepoB,
            favouritesRepository = favRepoB,
            userProfileRepository = userRepoB,
            messagesRepository = msgRepoB,
            localStore = localStoreB
        )

        val collectorScope = CoroutineScope(mainDispatcher + SupervisorJob())
        activeJobs += collectorScope.launch { marketVmA.uiState.collect() }
        activeJobs += collectorScope.launch { marketVmB.uiState.collect() }

        // =========================================================================
        // 1. User A signs in with Google, completes profile, and creates an advertisement
        // =========================================================================
        val tokenA = buildEmulatorGoogleIdToken(
            sub = "google_sub_a_$runSuffix",
            email = "user_a_$runSuffix@ekashbuy.test",
            name = "Aamir Lone"
        )
        authVmA.signInWithGoogleIdToken(tokenA)
        val authStateA = awaitState(authVmA.uiState) {
            it.currentUser != null && !it.isLoading && !it.isSyncingProfile
        }
        assertNull("User A Google sign-in should have no error", authStateA.errorMessage)
        val userAUid = authStateA.currentUser!!.uid

        authVmA.updateUserProfile(
            displayName = "Aamir Lone",
            mobileNumber = "9419000111",
            district = KashmirDistrict.SRINAGAR,
            locality = "Zainakadal"
        )
        awaitState(authVmA.uiState) {
            !it.isUpdatingProfile && it.userProfile?.mobileNumber == "+919419000111"
        }

        val savedProfileA = userRepoA.getUserProfile(userAUid).getOrThrow()
        assertNotNull(savedProfileA)
        assertEquals("Aamir Lone", savedProfileA?.displayName)
        assertEquals("+919419000111", savedProfileA?.mobileNumber)
        assertEquals(KashmirDistrict.SRINAGAR.name, savedProfileA?.district)

        awaitState(marketVmA.uiState) { it.isAuthenticated && !it.isListingsLoading && !it.isMyAdsLoading }

        val titleA = "Kani Pashmina Shawl $runSuffix"
        marketVmA.submitListing(
            title = titleA,
            priceText = "18500",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Zainakadal",
            condition = AdCondition.BRAND_NEW,
            description = "Authentic handwoven Kani Pashmina shawl from Zainakadal, Srinagar.",
            sellerName = "Aamir Lone",
            sellerPhone = "+919419000111"
        )

        val stateAAfterCreate = awaitState(marketVmA.uiState) { state ->
            !state.isSubmittingAd && state.myListings.any { it.title == titleA }
        }
        assertNull(stateAAfterCreate.adActionError)
        val createdAdA = stateAAfterCreate.myListings.first { it.title == titleA }
        val adAId = createdAdA.id
        assertEquals(userAUid, createdAdA.sellerId)
        assertEquals(FirestoreListingStatus.ACTIVE.name, createdAdA.status)

        // =========================================================================
        // 2. User B signs in with Google and discovers that advertisement
        // =========================================================================
        val tokenB = buildEmulatorGoogleIdToken(
            sub = "google_sub_b_$runSuffix",
            email = "user_b_$runSuffix@ekashbuy.test",
            name = "Zoya Mir"
        )
        val regB = authRepoB.signInWithGoogleIdToken(tokenB)
        assertTrue("User B initial Google sign-in should succeed", regB.isSuccess)
        authRepoB.signOut()

        authVmB.signInWithGoogleIdToken(tokenB)
        val authStateB = awaitState(authVmB.uiState) {
            it.currentUser != null && !it.isLoading && !it.isSyncingProfile
        }
        assertNull("User B Google sign-in should have no error", authStateB.errorMessage)
        val userBUid = authStateB.currentUser!!.uid
        assertNotEquals(userAUid, userBUid)

        val stateBDiscovery = awaitState(marketVmB.uiState) { state ->
            state.isAuthenticated && !state.isListingsLoading && state.allListings.any { it.id == adAId }
        }
        assertTrue(stateBDiscovery.allListings.any { it.id == adAId })

        marketVmB.updateFilters {
            it.copy(
                query = runSuffix,
                district = KashmirDistrict.SRINAGAR,
                category = AdCategory.HANDICRAFTS,
                minPriceInr = 15_000,
                maxPriceInr = 25_000
            )
        }
        val stateBFiltered = awaitState(marketVmB.uiState) { state ->
            state.filters.query == runSuffix &&
                state.filteredListings.map { it.id } == listOf(adAId)
        }
        assertEquals(listOf(adAId), stateBFiltered.filteredListings.map { it.id })

        // =========================================================================
        // 3. User B opens the product details
        // =========================================================================
        val openedByB = marketVmB.getProductById(adAId)
        assertNotNull("User B must be able to open product details", openedByB)
        assertEquals(titleA, openedByB!!.title)
        assertEquals(18500, openedByB.priceInr)
        assertEquals("Zainakadal", openedByB.locality)
        assertEquals(KashmirDistrict.SRINAGAR, openedByB.district)
        assertEquals(userAUid, openedByB.sellerId)
        assertFalse("User B is buyer, not owner", openedByB.sellerId == userBUid)

        // Also save User A's ad as a favourite for User B (used for Step 11 privacy check)
        marketVmB.toggleFavorite(adAId)
        awaitState(marketVmB.uiState) { adAId in it.favoriteIds && it.savedFavourites.any { fav -> fav.listingId == adAId } }

        // =========================================================================
        // 4 & 5. User B contacts User A; verify conversation creation & message delivery
        // =========================================================================
        val buyerMessage = "Assalamualikum, is this Pashmina shawl still available in Zainakadal?"
        var createdConvId: String? = null
        marketVmB.startConversation(
            listing = openedByB,
            initialMessage = buyerMessage
        ) { convId ->
            createdConvId = convId
        }

        val stateBAfterContact = awaitState(marketVmB.uiState) { state ->
            !state.isStartingConversation &&
                createdConvId != null &&
                state.conversations.any { it.id == createdConvId } &&
                state.activeConversationMessages.any { it.text == buyerMessage }
        }
        val convId = createdConvId!!
        assertEquals("${adAId}_$userBUid", convId)
        assertNull(stateBAfterContact.messageActionError)
        val buyerConv = stateBAfterContact.conversations.first { it.id == convId }
        assertTrue(buyerConv.isBuyingInquiry)
        assertEquals(buyerMessage, buyerConv.lastMessage)

        // User A receives conversation + unread indicator
        val stateAUnread = awaitState(marketVmA.uiState) { state ->
            state.conversations.any { it.id == convId && it.unreadCount > 0 }
        }
        val sellerConv = stateAUnread.conversations.first { it.id == convId }
        assertFalse(sellerConv.isBuyingInquiry)
        assertEquals(buyerMessage, sellerConv.lastMessage)
        assertTrue(stateAUnread.unreadConversationsCount >= 1)

        // User A opens conversation -> unread clears -> reads message -> sends reply
        marketVmA.selectConversation(convId)
        val stateAThread = awaitState(marketVmA.uiState) { state ->
            state.selectedConversationId == convId &&
                state.activeConversationMessages.any { it.text == buyerMessage } &&
                state.conversations.first { it.id == convId }.unreadCount == 0
        }
        assertEquals(1, stateAThread.activeConversationMessages.size)

        val sellerReply = "Walaikum Assalam, yes it is available. You can inspect it today."
        marketVmA.sendChatMessage(convId, sellerReply)
        awaitState(marketVmA.uiState) { state ->
            !state.isSendingMessage && state.activeConversationMessages.any { it.text == sellerReply }
        }

        // User B receives Seller's reply in live thread
        val stateBReceivedReply = awaitState(marketVmB.uiState) { state ->
            state.activeConversationMessages.any { it.text == sellerReply }
        }
        assertEquals(listOf(buyerMessage, sellerReply), stateBReceivedReply.activeConversationMessages.map { it.text })

        // =========================================================================
        // 6. Verify that neither user can modify the other's advertisement
        // =========================================================================
        // User B creates their own ad so we can also test User A -> User B isolation
        val titleB = "Budgam Walnut Coffee Table $runSuffix"
        marketVmB.submitListing(
            title = titleB,
            priceText = "12000",
            isMonthlyRent = false,
            negotiable = false,
            category = AdCategory.HOME_FURNITURE,
            district = KashmirDistrict.BUDGAM,
            locality = "Humhama",
            condition = AdCondition.LIKE_NEW,
            description = "Handcarved walnut wood coffee table in Humhama, Budgam.",
            sellerName = "Zoya Mir",
            sellerPhone = "+917006000222"
        )
        val stateBAfterOwnAd = awaitState(marketVmB.uiState) { state ->
            !state.isSubmittingAd && state.myListings.any { it.title == titleB }
        }
        val adB = stateBAfterOwnAd.myListings.first { it.title == titleB }
        val adBId = adB.id

        // Wait for User A to see User B's ad in allListings & save it as User A's private favourite
        awaitState(marketVmA.uiState) { state -> state.allListings.any { it.id == adBId } }
        marketVmA.toggleFavorite(adBId)
        awaitState(marketVmA.uiState) { adBId in it.favoriteIds }

        // User B attempts to mutate User A's ad via ViewModel -> blocked by client owner guard
        marketVmB.updateListingStatus(adAId, FirestoreListingStatus.SOLD)
        awaitState(marketVmB.uiState) { it.adActionError?.contains("only update your own") == true }
        marketVmB.clearAdMessages()

        marketVmB.deleteListing(adAId)
        awaitState(marketVmB.uiState) { it.adActionError?.contains("only delete your own") == true }
        marketVmB.clearAdMessages()

        // User B attempts to mutate User A's ad directly via Firestore -> blocked by firestore.rules
        val bEditAttempt = listingsRepoB.updateListing(createdAdA.toFirestoreListingSnapshot().copy(priceInr = 100L))
        assertTrue(bEditAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            bEditAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
        val bStatusAttempt = listingsRepoB.updateListingStatus(adAId, FirestoreListingStatus.PAUSED)
        assertTrue(bStatusAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            bStatusAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
        val bDeleteAttempt = listingsRepoB.deleteListing(adAId)
        assertTrue(bDeleteAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            bDeleteAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        // User A attempts to mutate User B's ad via ViewModel and directly via Firestore -> blocked
        marketVmA.updateListingStatus(adBId, FirestoreListingStatus.SOLD)
        awaitState(marketVmA.uiState) { it.adActionError?.contains("only update your own") == true }
        marketVmA.clearAdMessages()

        marketVmA.deleteListing(adBId)
        awaitState(marketVmA.uiState) { it.adActionError?.contains("only delete your own") == true }
        marketVmA.clearAdMessages()

        val aEditAttempt = listingsRepoA.updateListing(adB.toFirestoreListingSnapshot().copy(priceInr = 50L))
        assertTrue(aEditAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            aEditAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
        val aStatusAttempt = listingsRepoA.updateListingStatus(adBId, FirestoreListingStatus.SOLD)
        assertTrue(aStatusAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            aStatusAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
        val aDeleteAttempt = listingsRepoA.deleteListing(adBId)
        assertTrue(aDeleteAttempt.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            aDeleteAttempt.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        // =========================================================================
        // 7. User A edits the advertisement
        // =========================================================================
        val editedTitleA = "Kani Pashmina Shawl Pure Wool $runSuffix"
        marketVmA.startEditingListing(createdAdA)
        marketVmA.submitListing(
            title = editedTitleA,
            priceText = "16900",
            isMonthlyRent = false,
            negotiable = false,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh",
            condition = AdCondition.BRAND_NEW,
            description = "Updated description: pure handwoven wool Kani shawl in Rajbagh.",
            sellerName = "Aamir Lone",
            sellerPhone = "+919419000111"
        )
        awaitState(marketVmA.uiState) { state ->
            !state.isSubmittingAd &&
                state.myListings.any { it.id == adAId && it.title == editedTitleA && it.priceInr == 16900 }
        }

        // =========================================================================
        // 8. User B verifies the updated information
        // =========================================================================
        val stateBAfterEdit = awaitState(marketVmB.uiState) { state ->
            val updated = state.allListings.firstOrNull { it.id == adAId }
            updated != null &&
                updated.title == editedTitleA &&
                updated.priceInr == 16900 &&
                updated.locality == "Rajbagh" &&
                !updated.negotiable
        }
        val verifiedUpdatedByB = stateBAfterEdit.allListings.first { it.id == adAId }
        assertEquals(editedTitleA, verifiedUpdatedByB.title)
        assertEquals(16900, verifiedUpdatedByB.priceInr)
        assertEquals("Rajbagh", verifiedUpdatedByB.locality)

        // =========================================================================
        // 9. User A marks the advertisement as sold
        // =========================================================================
        marketVmA.updateListingStatus(adAId, FirestoreListingStatus.SOLD)
        val stateASold = awaitState(marketVmA.uiState) { state ->
            state.updatingStatusListingId == null &&
                state.myListings.firstOrNull { it.id == adAId }?.status == FirestoreListingStatus.SOLD.name &&
                state.allListings.none { it.id == adAId }
        }
        assertEquals(
            FirestoreListingStatus.SOLD.name,
            stateASold.myListings.first { it.id == adAId }.status
        )

        // =========================================================================
        // 10. User B verifies the SOLD / removed-from-active status
        // =========================================================================
        val stateBAfterSold = awaitState(marketVmB.uiState) { state ->
            state.allListings.none { it.id == adAId }
        }
        assertNull(
            "Sold listing must no longer appear in User B's active discovery feed",
            stateBAfterSold.allListings.firstOrNull { it.id == adAId }
        )
        // Note on firestore.rules /listings/{listingId}: allow get requires ACTIVE or owner;
        // once SOLD, direct non-owner document fetch by User B is rejected with PERMISSION_DENIED,
        // while ProductDetailsScreen shows 'This advertisement may have been removed or sold.'
        val directSoldReadByB = listingsRepoB.getListingById(adAId)
        assertTrue(directSoldReadByB.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            directSoldReadByB.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        // =========================================================================
        // 11. Verify favourites remain private to each user
        // =========================================================================
        assertEquals(setOf(adBId), marketVmA.uiState.value.favoriteIds)
        assertEquals(setOf(adAId), marketVmB.uiState.value.favoriteIds)

        // User B still retains their private favourite snapshot even after User A marked adA as SOLD
        assertTrue(marketVmB.uiState.value.savedFavourites.any { it.listingId == adAId })
        assertFalse(marketVmA.uiState.value.savedFavourites.any { it.listingId == adAId })

        // Direct cross-user favourite reads & queries fail under firestore.rules
        val aReadsBFavDoc = runCatching {
            firestoreA.collection("favourites").document("${userBUid}_$adAId").get().await()
        }
        assertTrue(aReadsBFavDoc.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            aReadsBFavDoc.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val bReadsAFavDoc = runCatching {
            firestoreB.collection("favourites").document("${userAUid}_$adBId").get().await()
        }
        assertTrue(bReadsAFavDoc.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            bReadsAFavDoc.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val aQueriesBFavs = runCatching {
            firestoreA.collection("favourites").whereEqualTo("userId", userBUid).get().await()
        }
        assertTrue(aQueriesBFavs.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            aQueriesBFavs.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
    }

    private suspend fun <T> awaitState(
        flow: StateFlow<T>,
        timeoutMs: Long = 10_000L,
        predicate: (T) -> Boolean
    ): T = withTimeout(timeoutMs) {
        flow.first(predicate)
    }

    private fun buildEmulatorGoogleIdToken(
        sub: String,
        email: String,
        name: String
    ): String {
        val header = JSONObject(mapOf("alg" to "none", "typ" to "JWT")).toString()
        val nowSeconds = System.currentTimeMillis() / 1000L
        val payload = JSONObject(
            mapOf(
                "iss" to "https://accounts.google.com",
                "aud" to "393159475023-qmk459gg66jbu4iulq1li622esh3m1sq.apps.googleusercontent.com",
                "sub" to sub,
                "email" to email,
                "name" to name,
                "email_verified" to true,
                "iat" to nowSeconds,
                "exp" to (nowSeconds + 3600L)
            )
        ).toString()
        val flags = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        val encodedHeader = Base64.encodeToString(header.toByteArray(StandardCharsets.UTF_8), flags)
        val encodedPayload = Base64.encodeToString(payload.toByteArray(StandardCharsets.UTF_8), flags)
        return "$encodedHeader.$encodedPayload."
    }

    private fun getOrCreateNamedEmulatorApp(
        context: Context,
        appName: String,
        databaseId: String
    ): FirebaseApp {
        FirebaseApp.getApps(context).firstOrNull { it.name == appName }?.let { return it }

        val options = FirebaseOptions.Builder()
            .setApplicationId("com.aistudio.ekashbuy.kshmrp")
            .setProjectId(PROJECT_ID)
            .setApiKey("fake-api-key-for-emulator")
            .build()

        val app = FirebaseApp.initializeApp(context, options, appName)
        val firestore = FirebaseFirestore.getInstance(app, databaseId)
        firestore.useEmulator(EMULATOR_HOST, FIRESTORE_PORT)
        firestore.firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
            .build()

        val auth = FirebaseAuth.getInstance(app)
        auth.useEmulator(EMULATOR_HOST, AUTH_PORT)
        return app
    }

    private companion object {
        const val APP_NAME_USER_A = "e2e_user_a"
        const val APP_NAME_USER_B = "e2e_user_b"
        const val EMULATOR_HOST = "127.0.0.1"
        const val FIRESTORE_PORT = 8085
        const val AUTH_PORT = 9099
        const val PROJECT_ID = "demo-no-project"
    }
}
