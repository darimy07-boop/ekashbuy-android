package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("eKashbuy", appName)
  }

  @Test
  fun `recaptcha callback intent resolves to Firebase RecaptchaActivity`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val callbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("recaptcha://firebase.auth/"))
      .addCategory(Intent.CATEGORY_DEFAULT)
      .addCategory(Intent.CATEGORY_BROWSABLE)

    val matches = context.packageManager.queryIntentActivities(
      callbackIntent,
      PackageManager.MATCH_DEFAULT_ONLY
    )

    assertTrue(
      "Expected RecaptchaActivity to handle recaptcha://firebase.auth/",
      matches.any {
        it.activityInfo.packageName == context.packageName &&
          it.activityInfo.name == "com.google.firebase.auth.internal.RecaptchaActivity"
      }
    )
  }

  @Test
  fun `default_web_client_id is generated from google-services json`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val clientId = context.getString(R.string.default_web_client_id)
    assertTrue(
      "Expected default_web_client_id to be a valid Google OAuth Web Client ID",
      clientId.endsWith(".apps.googleusercontent.com")
    )
  }
}
