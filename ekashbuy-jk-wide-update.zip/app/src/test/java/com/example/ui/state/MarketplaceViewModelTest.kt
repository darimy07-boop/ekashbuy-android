package com.example.ui.state

import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.firestore.FavouritesRepository
import com.example.data.firestore.ListingsRepository
import com.example.data.firestore.MessagesRepository
import com.example.data.firestore.model.FirestoreAdTier
import com.example.data.firestore.model.FirestoreConversation
import com.example.data.firestore.model.FirestoreFavourite
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.model.FirestoreMessageEntry
import com.example.data.local.InMemoryMarketplaceLocalStore
import com.example.data.media.PhotoCandidate
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.example.model.SortOption
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.Date

@OptIn(ExperimentalCoroutinesApi::class)
class MarketplaceViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun unauthenticatedUser_doesNotObserveFirestore_andExposesSignedOutState() = runTest(testDispatcher) {
        val authRepo = FakeAuthRepository(initialUser = null)
        val listingsRepo = FakeListingsRepository()
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)

        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isAuthenticated)
        assertEquals(0, listingsRepo.activeObserverSubscriptions)
        assertEquals(0, listingsRepo.sellerObserverSubscriptions)
        assertTrue(state.allListings.isEmpty())
        assertTrue(state.myListings.isEmpty())
        assertNull(state.listingsError)

        collectJob.cancel()
    }

    @Test
    fun authenticatedUser_loadsListings_filtersBySearchCategoryAndDistrict() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice", email = "a@ekashbuy.in", phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc(
                    id = "ad_1",
                    sellerId = "alice_1",
                    title = "Apple iPhone 14 Pro",
                    category = AdCategory.MOBILES,
                    district = KashmirDistrict.SRINAGAR,
                    locality = "Lal Chowk",
                    priceInr = 72000L
                ),
                sampleDoc(
                    id = "ad_2",
                    sellerId = "bob_2",
                    title = "Kashmiri Walnut Dining Table",
                    category = AdCategory.HOME_FURNITURE,
                    district = KashmirDistrict.ANANTNAG,
                    locality = "KP Road",
                    priceInr = 35000L
                )
            )
        )
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)

        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        assertTrue(viewModel.uiState.value.isAuthenticated)
        assertEquals(2, viewModel.uiState.value.allListings.size)
        assertEquals(1, viewModel.uiState.value.myListings.size)

        // Home search + district filter
        viewModel.setHomeDistrict(KashmirDistrict.ANANTNAG)
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.homeListings.size)
        assertEquals("ad_2", viewModel.uiState.value.homeListings.first().id)

        viewModel.setHomeDistrict(KashmirDistrict.ALL)
        viewModel.setHomeSearchQuery("iphone")
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.homeListings.size)
        assertEquals("ad_1", viewModel.uiState.value.homeListings.first().id)

        // Category shortcut + filters
        viewModel.applyListingShortcut(category = AdCategory.HOME_FURNITURE, district = KashmirDistrict.ALL)
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.filteredListings.size)
        assertEquals("ad_2", viewModel.uiState.value.filteredListings.first().id)

        collectJob.cancel()
    }

    @Test
    fun submitListing_validatesInput_createsFreeOrdinaryAd_andSupportsEditAndDeleteWithOwnershipCheck() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc(
                    id = "bob_ad",
                    sellerId = "bob_2",
                    title = "Bob's Bike",
                    category = AdCategory.VEHICLES,
                    district = KashmirDistrict.BUDGAM,
                    locality = "Humhama",
                    priceInr = 95000L
                )
            )
        )
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Invalid title fails fast before repository call
        viewModel.submitListing(
            title = "Hi",
            priceText = "12000",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.MOBILES,
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh",
            condition = AdCondition.GOOD,
            description = "Clean item in Srinagar ready for pickup.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111"
        )
        advanceUntilIdle()
        assertNotNull(viewModel.uiState.value.adActionError)
        assertEquals(1, listingsRepo.docsFlow.value.size)

        // Valid create succeeds as ORDINARY_FREE
        var successCalled = false
        viewModel.submitListing(
            title = "Sony Alpha Camera Kit",
            priceText = "56000",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.ELECTRONICS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Hazratbal",
            condition = AdCondition.LIKE_NEW,
            description = "Low shutter count camera kit with original box and 2 batteries.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111",
            onSuccess = { successCalled = true }
        )
        advanceUntilIdle()
        assertTrue(successCalled)
        assertNull(viewModel.uiState.value.adActionError)
        val created = viewModel.uiState.value.myListings.first()
        val storedCreated = listingsRepo.docsFlow.value.first { it.id == created.id }
        assertEquals(FirestoreAdTier.ORDINARY_FREE.name, storedCreated.adTier)
        assertEquals("alice_1", created.sellerId)
        assertEquals("Sony Alpha Camera Kit", created.title)

        // Attempting to edit or delete Bob's listing is rejected
        val bobListing = viewModel.getProductById("bob_ad")!!
        viewModel.startEditingListing(bobListing)
        advanceUntilIdle()
        assertNotNull(viewModel.uiState.value.adActionError)
        assertNull(viewModel.uiState.value.postAdDraft.editingListingId)

        viewModel.deleteListing("bob_ad")
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.adActionError?.contains("only delete your own") == true)

        // Owner can edit her own listing
        viewModel.startEditingListing(created)
        advanceUntilIdle()
        assertEquals(created.id, viewModel.uiState.value.postAdDraft.editingListingId)
        viewModel.submitListing(
            title = "Sony Alpha Camera Kit Updated",
            priceText = "52000",
            isMonthlyRent = false,
            negotiable = false,
            category = AdCategory.ELECTRONICS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Hazratbal",
            condition = AdCondition.LIKE_NEW,
            description = "Updated description with extra lens filter included in Hazratbal.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111"
        )
        advanceUntilIdle()
        val updated = viewModel.uiState.value.myListings.first { it.id == created.id }
        assertEquals("Sony Alpha Camera Kit Updated", updated.title)
        assertEquals(52000, updated.priceInr)
        assertNull(viewModel.uiState.value.postAdDraft.editingListingId)

        // Owner can pause and delete own listing
        viewModel.updateListingStatus(created.id, FirestoreListingStatus.PAUSED)
        advanceUntilIdle()
        assertEquals(FirestoreListingStatus.PAUSED.name, viewModel.uiState.value.myListings.first().status)

        viewModel.deleteListing(created.id)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.myListings.isEmpty())

        collectJob.cancel()
    }

    @Test
    fun repositoryReadFailure_surfacesErrorState_andRetryRecovers() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc(
                    id = "ad_1",
                    sellerId = "alice_1",
                    title = "MacBook Air M2",
                    category = AdCategory.ELECTRONICS,
                    district = KashmirDistrict.BUDGAM,
                    locality = "Humhama",
                    priceInr = 68500L
                )
            )
        )
        listingsRepo.failNextObserve = IllegalStateException("Network unavailable")
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)

        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        assertEquals("Network unavailable", viewModel.uiState.value.listingsError)
        assertTrue(viewModel.uiState.value.allListings.isEmpty())

        // Retry recovers
        viewModel.retryListings()
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.listingsError)
        assertEquals(1, viewModel.uiState.value.allListings.size)

        // Toggle favorite adds and removes
        viewModel.toggleFavorite("ad_1")
        advanceUntilIdle()
        assertTrue("ad_1" in viewModel.uiState.value.favoriteIds)

        viewModel.toggleFavorite("ad_1")
        advanceUntilIdle()
        assertFalse("ad_1" in viewModel.uiState.value.favoriteIds)

        collectJob.cancel()
    }

    @Test
    fun photoSelection_supportsUpToSixImages_validatesDuplicatesAndTypes_reordersAndPreservesDraft() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository()
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)

        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Add 4 valid image candidates
        viewModel.addSelectedPhotoCandidates(
            (1..4).map { idx ->
                PhotoCandidate(
                    uriString = "content://media/picker/$idx",
                    displayName = "photo_$idx.jpg",
                    mimeType = "image/jpeg",
                    sizeBytes = 150_000L
                )
            }
        )
        advanceUntilIdle()
        assertEquals(4, viewModel.uiState.value.postAdDraft.selectedPhotoCount)
        assertEquals("content://media/picker/1", viewModel.uiState.value.postAdDraft.mainPhoto?.uriString)
        assertNull(viewModel.uiState.value.postAdDraft.photoError)

        // Add duplicate, non-image, oversized, and 3 more valid photos -> capped at 6 with clear validation message
        viewModel.addSelectedPhotoCandidates(
            listOf(
                PhotoCandidate("content://media/picker/2", "dup.jpg", "image/jpeg", 100_000L),
                PhotoCandidate("content://media/picker/pdf", "doc.pdf", "application/pdf", 50_000L),
                PhotoCandidate("content://media/picker/big", "huge.png", "image/png", 20L * 1024L * 1024L),
                PhotoCandidate("content://media/picker/5", "photo_5.png", "image/png", 120_000L),
                PhotoCandidate("content://media/picker/6", "photo_6.webp", "image/webp", 120_000L),
                PhotoCandidate("content://media/picker/7", "photo_7.jpg", "image/jpeg", 120_000L)
            )
        )
        advanceUntilIdle()
        val draftAfterMerge = viewModel.uiState.value.postAdDraft
        assertEquals(6, draftAfterMerge.selectedPhotoCount)
        assertTrue(draftAfterMerge.photoError?.contains("Maximum 6 photos allowed") == true)
        assertTrue(draftAfterMerge.photoError?.contains("duplicate") == true)
        assertTrue(draftAfterMerge.photoError?.contains("Only image files") == true)
        assertTrue(draftAfterMerge.photoError?.contains("15 MB") == true)

        // Reorder and set main photo
        viewModel.setMainSelectedPhoto(5)
        advanceUntilIdle()
        assertEquals("content://media/picker/6", viewModel.uiState.value.postAdDraft.mainPhoto?.uriString)

        viewModel.moveSelectedPhoto(0, 2)
        advanceUntilIdle()
        assertEquals("content://media/picker/6", viewModel.uiState.value.postAdDraft.selectedPhotos[2].uriString)

        // Remove an image -> 5/6
        viewModel.removeSelectedPhoto(1)
        advanceUntilIdle()
        assertEquals(5, viewModel.uiState.value.postAdDraft.selectedPhotoCount)

        // Updating draft fields preserves selected photos across navigation
        viewModel.updatePostAdDraft { it.copy(title = "Kashmiri Samovar Copper Set") }
        advanceUntilIdle()
        assertEquals("Kashmiri Samovar Copper Set", viewModel.uiState.value.postAdDraft.title)
        assertEquals(5, viewModel.uiState.value.postAdDraft.selectedPhotoCount)

        // Submitting listing does NOT upload local URIs into Firestore imageUrls
        viewModel.submitListing(
            title = "Kashmiri Samovar Copper Set",
            priceText = "4800",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Zainakadal",
            condition = AdCondition.BRAND_NEW,
            description = "Traditional engraved copper samovar ready for pickup.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111"
        )
        advanceUntilIdle()

        val savedDoc = listingsRepo.docsFlow.value.first()
        assertTrue(savedDoc.imageUrls.isEmpty())
        assertEquals(0, viewModel.uiState.value.postAdDraft.selectedPhotoCount)

        collectJob.cancel()
    }

    @Test
    fun strictPriceValidation_statusLifecycle_savedFavouriteRetention_andTrimmedSearch() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc(
                    id = "bob_ad",
                    sellerId = "bob_2",
                    title = "Walnut Coffee Table",
                    category = AdCategory.HOME_FURNITURE,
                    district = KashmirDistrict.ANANTNAG,
                    locality = "KP Road",
                    priceInr = 18000L
                )
            )
        )
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Trimmed district name search finds Anantnag listing
        viewModel.setHomeSearchQuery("  anantnag  ")
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.homeListings.size)
        assertEquals("bob_ad", viewModel.uiState.value.homeListings.first().id)

        // Malformed decimal price is rejected rather than concatenated into 125
        viewModel.submitListing(
            title = "Handcrafted Tea Kettle",
            priceText = "12.5",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Rainawari",
            condition = AdCondition.BRAND_NEW,
            description = "Handcrafted hammered copper kettle in Srinagar.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111"
        )
        advanceUntilIdle()
        assertNotNull(viewModel.uiState.value.adActionError)
        assertTrue(viewModel.uiState.value.myListings.isEmpty())

        // Formatted INR price is accepted cleanly
        viewModel.submitListing(
            title = "Handcrafted Tea Kettle",
            priceText = "45,000",
            isMonthlyRent = false,
            negotiable = true,
            category = AdCategory.HANDICRAFTS,
            district = KashmirDistrict.SRINAGAR,
            locality = "Rainawari",
            condition = AdCondition.BRAND_NEW,
            description = "Handcrafted hammered copper kettle in Srinagar.",
            sellerName = "Alice Bhat",
            sellerPhone = "+919419000111"
        )
        advanceUntilIdle()
        val ownAdId = viewModel.uiState.value.myListings.first().id
        assertEquals(45000, viewModel.uiState.value.myListings.first().priceInr)

        // Status transitions: ACTIVE -> PAUSED -> SOLD -> ACTIVE
        viewModel.updateListingStatus(ownAdId, FirestoreListingStatus.PAUSED)
        advanceUntilIdle()
        assertEquals(FirestoreListingStatus.PAUSED.name, viewModel.uiState.value.myListings.first().status)
        assertNull(viewModel.uiState.value.updatingStatusListingId)

        viewModel.updateListingStatus(ownAdId, FirestoreListingStatus.SOLD)
        advanceUntilIdle()
        assertEquals(FirestoreListingStatus.SOLD.name, viewModel.uiState.value.myListings.first().status)

        viewModel.updateListingStatus(ownAdId, FirestoreListingStatus.ACTIVE)
        advanceUntilIdle()
        assertEquals(FirestoreListingStatus.ACTIVE.name, viewModel.uiState.value.myListings.first().status)

        // Favourite persists even after seller pauses/removes the listing
        viewModel.toggleFavorite("bob_ad")
        advanceUntilIdle()
        assertTrue("bob_ad" in viewModel.uiState.value.favoriteIds)
        listingsRepo.updateListingStatus("bob_ad", FirestoreListingStatus.PAUSED)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.allListings.none { it.id == "bob_ad" })
        assertTrue(viewModel.uiState.value.savedFavourites.any { it.listingId == "bob_ad" })

        viewModel.toggleFavorite("bob_ad")
        advanceUntilIdle()
        assertFalse("bob_ad" in viewModel.uiState.value.favoriteIds)
        assertTrue(viewModel.uiState.value.savedFavourites.isEmpty())

        collectJob.cancel()
    }

    @Test
    fun buyerSellerMessaging_startsConversation_sendsReplies_handlesErrorsAndPreventsSelfMessage() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc(
                    id = "alice_ad",
                    sellerId = "alice_1",
                    title = "Alice's Laptop",
                    category = AdCategory.ELECTRONICS,
                    district = KashmirDistrict.SRINAGAR,
                    locality = "Bemina",
                    priceInr = 55000L
                ),
                sampleDoc(
                    id = "bob_ad",
                    sellerId = "bob_2",
                    title = "Kashmiri Silk Carpet",
                    category = AdCategory.HANDICRAFTS,
                    district = KashmirDistrict.SRINAGAR,
                    locality = "Lal Chowk",
                    priceInr = 25000L
                )
            )
        )
        val favRepo = FakeFavouritesRepository()
        val messagesRepo = FakeMessagesRepository(currentUserId = "alice_1")
        messagesRepo.failNextObserveConversations = IllegalStateException("Network unavailable")
        val viewModel = MarketplaceViewModel(
            authRepository = authRepo,
            listingsRepository = listingsRepo,
            favouritesRepository = favRepo,
            messagesRepository = messagesRepo
        )
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Conversations error surfaces and retry recovers
        assertEquals("Network unavailable", viewModel.uiState.value.conversationsError)
        viewModel.retryConversations()
        advanceUntilIdle()
        assertNull(viewModel.uiState.value.conversationsError)

        // Cannot message own listing
        val ownListing = viewModel.getProductById("alice_ad")!!
        viewModel.startConversation(ownListing, "Hi!")
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.messageActionError?.contains("own advertisement") == true)

        // Starting conversation on Bob's ad creates thread and selects it
        val bobListing = viewModel.getProductById("bob_ad")!!
        var readyId: String? = null
        viewModel.startConversation(bobListing, "Is this silk carpet still available?") { convId ->
            readyId = convId
        }
        advanceUntilIdle()

        assertEquals("bob_ad_alice_1", readyId)
        assertEquals("bob_ad_alice_1", viewModel.uiState.value.selectedConversationId)
        assertEquals(1, viewModel.uiState.value.conversations.size)
        assertEquals(1, viewModel.uiState.value.activeConversationMessages.size)
        assertEquals(
            "Is this silk carpet still available?",
            viewModel.uiState.value.activeConversationMessages.first().text
        )

        // Blank message fails validation without hitting repository
        viewModel.sendChatMessage("bob_ad_alice_1", "   ")
        advanceUntilIdle()
        assertNotNull(viewModel.uiState.value.messageActionError)

        // Sending valid reply appends to live thread
        var replySent = false
        viewModel.sendChatMessage("bob_ad_alice_1", "Can I inspect it today at 4 PM?") {
            replySent = true
        }
        advanceUntilIdle()
        assertTrue(replySent)
        assertNull(viewModel.uiState.value.messageActionError)
        assertEquals(2, viewModel.uiState.value.activeConversationMessages.size)
        assertEquals(
            "Can I inspect it today at 4 PM?",
            viewModel.uiState.value.activeConversationMessages.last().text
        )

        collectJob.cancel()
    }

    @Test
    fun filters_supportCustomMinAndMaxPrice_withDistrictCategoryCondition_andSearchHistoryLifecycle() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice", email = "a@ekashbuy.in", phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc("ad_1", "bob_2", "Budget Phone", AdCategory.MOBILES, KashmirDistrict.SRINAGAR, "Lal Chowk", 8000L),
                sampleDoc("ad_2", "bob_2", "Midrange Phone", AdCategory.MOBILES, KashmirDistrict.SRINAGAR, "Rajbagh", 24000L),
                sampleDoc("ad_3", "bob_2", "Flagship Phone", AdCategory.MOBILES, KashmirDistrict.BUDGAM, "Humhama", 72000L),
                sampleDoc("ad_4", "bob_2", "Walnut Sofa", AdCategory.HOME_FURNITURE, KashmirDistrict.SRINAGAR, "Bemina", 30000L)
            )
        )
        val favRepo = FakeFavouritesRepository()
        val localStore = InMemoryMarketplaceLocalStore()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo, localStore = localStore)
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Custom min & max price range combined with category + district + condition
        viewModel.updateFilters {
            it.copy(
                category = AdCategory.MOBILES,
                district = KashmirDistrict.SRINAGAR,
                condition = AdCondition.LIKE_NEW,
                minPriceInr = 10_000,
                maxPriceInr = 50_000,
                sortOption = SortOption.PRICE_LOW_HIGH
            )
        }
        advanceUntilIdle()
        assertEquals(listOf("ad_2"), viewModel.uiState.value.filteredListings.map { it.id })

        // Min price only + all districts
        viewModel.updateFilters {
            it.copy(
                district = KashmirDistrict.ALL,
                category = null,
                minPriceInr = 25_000,
                maxPriceInr = null,
                sortOption = SortOption.PRICE_HIGH_LOW
            )
        }
        advanceUntilIdle()
        assertEquals(listOf("ad_3", "ad_4"), viewModel.uiState.value.filteredListings.map { it.id })

        // Search history records, deduplicates case-insensitively, removes, and clears
        viewModel.recordSearchQuery("a") // ignored (< 2 chars)
        viewModel.recordSearchQuery("Silk Carpet")
        viewModel.recordSearchQuery("iPhone")
        viewModel.recordSearchQuery("silk carpet") // moves to front without duplicate
        advanceUntilIdle()
        assertEquals(listOf("silk carpet", "iPhone"), viewModel.uiState.value.searchHistory)

        viewModel.removeSearchHistoryItem("iPhone")
        advanceUntilIdle()
        assertEquals(listOf("silk carpet"), viewModel.uiState.value.searchHistory)

        viewModel.clearSearchHistory()
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.searchHistory.isEmpty())

        collectJob.cancel()
    }

    @Test
    fun messaging_unreadIndicator_tracksIncomingMessages_andClearsOnOpen() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc("bob_ad", "bob_2", "Kashmiri Carpet", AdCategory.HANDICRAFTS, KashmirDistrict.SRINAGAR, "Lal Chowk", 25000L)
            )
        )
        val favRepo = FakeFavouritesRepository()
        val messagesRepo = FakeMessagesRepository(currentUserId = "alice_1")
        val localStore = InMemoryMarketplaceLocalStore()
        val viewModel = MarketplaceViewModel(
            authRepository = authRepo,
            listingsRepository = listingsRepo,
            favouritesRepository = favRepo,
            messagesRepository = messagesRepo,
            localStore = localStore
        )
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Buyer starts conversation -> own message is never unread
        val bobListing = viewModel.getProductById("bob_ad")!!
        viewModel.startConversation(bobListing, "Is this available?")
        advanceUntilIdle()
        assertEquals(0, viewModel.uiState.value.unreadConversationsCount)

        // Close conversation dialog, then Bob sends a reply -> unread indicator appears
        viewModel.selectConversation(null)
        advanceUntilIdle()
        messagesRepo.simulateIncomingMessage(
            conversationId = "bob_ad_alice_1",
            senderId = "bob_2",
            senderName = "Bob",
            text = "Yes, come inspect anytime!",
            timestampMillis = System.currentTimeMillis() + 5_000L
        )
        advanceUntilIdle()
        assertEquals(1, viewModel.uiState.value.unreadConversationsCount)
        assertEquals(1, viewModel.uiState.value.conversations.first().unreadCount)

        // Selecting conversation clears unread indicator
        viewModel.selectConversation("bob_ad_alice_1")
        advanceUntilIdle()
        assertEquals(0, viewModel.uiState.value.unreadConversationsCount)
        assertEquals(0, viewModel.uiState.value.conversations.first().unreadCount)

        // Closing after reading keeps it read
        viewModel.selectConversation(null)
        advanceUntilIdle()
        assertEquals(0, viewModel.uiState.value.unreadConversationsCount)

        collectJob.cancel()
    }

    @Test
    fun favourites_preventDuplicates_andRestoreAfterSignOutAndSignBackIn() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc("bob_ad", "bob_2", "Walnut Wood Chest", AdCategory.HOME_FURNITURE, KashmirDistrict.ANANTNAG, "KP Road", 19000L)
            )
        )
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        // Save favourite and verify single entry
        viewModel.toggleFavorite("bob_ad")
        advanceUntilIdle()
        assertEquals(setOf("bob_ad"), viewModel.uiState.value.favoriteIds)
        assertEquals(1, viewModel.uiState.value.savedFavourites.size)

        // Sign out clears in-memory state
        authRepo.signOut()
        advanceUntilIdle()
        assertFalse(viewModel.uiState.value.isAuthenticated)
        assertTrue(viewModel.uiState.value.favoriteIds.isEmpty())
        assertTrue(viewModel.uiState.value.savedFavourites.isEmpty())

        // Sign back in restores saved favourites from Firestore repository
        authRepo.setUser(alice)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.isAuthenticated)
        assertEquals(setOf("bob_ad"), viewModel.uiState.value.favoriteIds)
        assertEquals(1, viewModel.uiState.value.savedFavourites.size)

        collectJob.cancel()
    }

    @Test
    fun listingManagement_rejectsStatusUpdateOnNonOwnerListing() = runTest(testDispatcher) {
        val alice = AuthUser(uid = "alice_1", displayName = "Alice Bhat", email = null, phoneNumber = "+919419000111")
        val authRepo = FakeAuthRepository(initialUser = alice)
        val listingsRepo = FakeListingsRepository(
            initialDocs = listOf(
                sampleDoc("bob_ad", "bob_2", "Bob's Scooter", AdCategory.VEHICLES, KashmirDistrict.BUDGAM, "Humhama", 42000L)
            )
        )
        val favRepo = FakeFavouritesRepository()
        val viewModel = MarketplaceViewModel(authRepo, listingsRepo, favRepo)
        val collectJob = viewModel.uiState.launchIn(backgroundScope)
        advanceUntilIdle()

        viewModel.updateListingStatus("bob_ad", FirestoreListingStatus.SOLD)
        advanceUntilIdle()
        assertTrue(viewModel.uiState.value.adActionError?.contains("only update your own") == true)
        assertEquals(FirestoreListingStatus.ACTIVE.name, listingsRepo.docsFlow.value.first().status)

        collectJob.cancel()
    }

    private fun sampleDoc(
        id: String,
        sellerId: String,
        title: String,
        category: AdCategory,
        district: KashmirDistrict,
        locality: String,
        priceInr: Long
    ) = FirestoreListing(
        id = id,
        sellerId = sellerId,
        sellerName = "Kashmir Seller",
        sellerPhone = "+919419000111",
        title = title,
        description = "Genuine local listing in $locality, ${district.displayName}.",
        priceInr = priceInr,
        isMonthlyRent = false,
        negotiable = true,
        category = category.name,
        district = district.name,
        locality = locality,
        condition = AdCondition.LIKE_NEW.name,
        adTier = FirestoreAdTier.ORDINARY_FREE.name,
        status = FirestoreListingStatus.ACTIVE.name,
        createdAt = Timestamp(Date()),
        updatedAt = Timestamp(Date())
    )

    private class FakeAuthRepository(initialUser: AuthUser?) : AuthRepository {
        private val state = MutableStateFlow(initialUser)
        fun setUser(user: AuthUser?) {
            state.value = user
        }
        override fun observeAuthState(): Flow<AuthUser?> = state.asStateFlow()
        override fun currentUser(): AuthUser? = state.value
        override suspend fun signInWithGoogleIdToken(idToken: String) =
            Result.failure<AuthUser>(UnsupportedOperationException())

        override fun signOut() {
            state.value = null
        }
    }

    private class FakeListingsRepository(
        initialDocs: List<FirestoreListing> = emptyList()
    ) : ListingsRepository {
        val docsFlow = MutableStateFlow(initialDocs)
        var activeObserverSubscriptions = 0
        var sellerObserverSubscriptions = 0
        var failNextObserve: Throwable? = null
        private var idSeq = 1

        override fun observeActiveListings(
            district: KashmirDistrict?,
            category: AdCategory?
        ): Flow<List<FirestoreListing>> = flow {
            activeObserverSubscriptions++
            val error = failNextObserve
            if (error != null) {
                failNextObserve = null
                throw error
            }
            docsFlow
                .map { docs ->
                    docs.filter { it.status == FirestoreListingStatus.ACTIVE.name }
                }
                .collect { emit(it) }
        }

        override fun observeSellerListings(sellerId: String): Flow<List<FirestoreListing>> = flow {
            sellerObserverSubscriptions++
            docsFlow
                .map { docs -> docs.filter { it.sellerId == sellerId } }
                .collect { emit(it) }
        }

        override suspend fun getListingById(listingId: String): Result<FirestoreListing?> {
            return Result.success(docsFlow.value.firstOrNull { it.id == listingId })
        }

        override suspend fun createListing(listing: FirestoreListing): Result<String> {
            val newId = listing.id.ifBlank { "created_${idSeq++}" }
            val created = listing.copy(
                id = newId,
                createdAt = Timestamp(Date()),
                updatedAt = Timestamp(Date())
            )
            docsFlow.update { listOf(created) + it }
            return Result.success(newId)
        }

        override suspend fun updateListing(listing: FirestoreListing): Result<Unit> {
            docsFlow.update { current ->
                current.map { item ->
                    if (item.id == listing.id) {
                        listing.copy(
                            createdAt = item.createdAt,
                            updatedAt = Timestamp(Date()),
                            status = item.status
                        )
                    } else item
                }
            }
            return Result.success(Unit)
        }

        override suspend fun updateListingStatus(
            listingId: String,
            status: FirestoreListingStatus
        ): Result<Unit> {
            docsFlow.update { current ->
                current.map { item ->
                    if (item.id == listingId) item.copy(status = status.name) else item
                }
            }
            return Result.success(Unit)
        }

        override suspend fun deleteListing(listingId: String): Result<Unit> {
            docsFlow.update { current -> current.filterNot { it.id == listingId } }
            return Result.success(Unit)
        }
    }

    private class FakeFavouritesRepository : FavouritesRepository {
        private val favsFlow = MutableStateFlow<List<FirestoreFavourite>>(emptyList())

        override fun observeUserFavourites(userId: String): Flow<List<FirestoreFavourite>> {
            return favsFlow.map { list -> list.filter { it.userId == userId } }
        }

        override suspend fun addFavourite(listing: FirestoreListing): Result<String> {
            val id = "alice_1_${listing.id}"
            favsFlow.update { current ->
                current.filterNot { it.listingId == listing.id } + FirestoreFavourite(
                    id = id,
                    userId = "alice_1",
                    listingId = listing.id,
                    listingTitle = listing.title,
                    priceInr = listing.priceInr,
                    district = listing.district
                )
            }
            return Result.success(id)
        }

        override suspend fun removeFavourite(listingId: String): Result<Unit> {
            favsFlow.update { current -> current.filterNot { it.listingId == listingId } }
            return Result.success(Unit)
        }
    }

    private class FakeMessagesRepository(
        private val currentUserId: String
    ) : MessagesRepository {
        private val conversationsFlow = MutableStateFlow<List<FirestoreConversation>>(emptyList())
        private val messagesMap = mutableMapOf<String, MutableStateFlow<List<FirestoreMessageEntry>>>()
        var failNextObserveConversations: Throwable? = null
        private var msgSeq = 1

        override fun observeUserConversations(userId: String): Flow<List<FirestoreConversation>> = flow {
            val err = failNextObserveConversations
            if (err != null) {
                failNextObserveConversations = null
                throw err
            }
            conversationsFlow
                .map { list -> list.filter { userId in it.participantIds } }
                .collect { emit(it) }
        }

        override fun observeConversationMessages(conversationId: String): Flow<List<FirestoreMessageEntry>> {
            return messagesMap.getOrPut(conversationId) { MutableStateFlow(emptyList()) }.asStateFlow()
        }

        override suspend fun getOrCreateConversation(
            listing: FirestoreListing,
            buyerName: String,
            initialMessage: String
        ): Result<String> {
            val convId = "${listing.id}_$currentUserId"
            val existing = conversationsFlow.value.firstOrNull { it.id == convId }
            if (existing == null) {
                val conv = FirestoreConversation(
                    id = convId,
                    listingId = listing.id,
                    listingTitle = listing.title,
                    listingPriceInr = listing.priceInr,
                    district = listing.district,
                    buyerId = currentUserId,
                    sellerId = listing.sellerId,
                    participantIds = listOf(currentUserId, listing.sellerId),
                    buyerName = buyerName,
                    sellerName = listing.sellerName,
                    lastMessageText = initialMessage.trim(),
                    lastSenderId = currentUserId,
                    createdAt = Timestamp(Date()),
                    lastMessageAt = Timestamp(Date())
                )
                conversationsFlow.update { listOf(conv) + it }
            }
            if (initialMessage.isNotBlank()) {
                sendMessage(convId, buyerName, initialMessage)
            }
            return Result.success(convId)
        }

        override suspend fun sendMessage(
            conversationId: String,
            senderName: String,
            text: String
        ): Result<String> {
            val trimmed = text.trim()
            val entryId = "msg_${msgSeq++}"
            val conv = conversationsFlow.value.firstOrNull { it.id == conversationId }
                ?: return Result.failure(IllegalStateException("Conversation not found"))
            val entry = FirestoreMessageEntry(
                id = entryId,
                conversationId = conversationId,
                listingId = conv.listingId,
                senderId = currentUserId,
                senderName = senderName,
                participantIds = conv.participantIds,
                text = trimmed,
                createdAt = Timestamp(Date())
            )
            val threadFlow = messagesMap.getOrPut(conversationId) { MutableStateFlow(emptyList()) }
            threadFlow.update { it + entry }
            conversationsFlow.update { list ->
                list.map {
                    if (it.id == conversationId) {
                        it.copy(
                            lastMessageText = trimmed,
                            lastSenderId = currentUserId,
                            lastMessageAt = Timestamp(Date())
                        )
                    } else it
                }
            }
            return Result.success(entryId)
        }

        fun simulateIncomingMessage(
            conversationId: String,
            senderId: String,
            senderName: String,
            text: String,
            timestampMillis: Long = System.currentTimeMillis()
        ) {
            val conv = conversationsFlow.value.firstOrNull { it.id == conversationId } ?: return
            val ts = Timestamp(Date(timestampMillis))
            val entry = FirestoreMessageEntry(
                id = "msg_${msgSeq++}",
                conversationId = conversationId,
                listingId = conv.listingId,
                senderId = senderId,
                senderName = senderName,
                participantIds = conv.participantIds,
                text = text,
                createdAt = ts
            )
            val threadFlow = messagesMap.getOrPut(conversationId) { MutableStateFlow(emptyList()) }
            threadFlow.update { it + entry }
            conversationsFlow.update { list ->
                list.map {
                    if (it.id == conversationId) {
                        it.copy(
                            lastMessageText = text,
                            lastSenderId = senderId,
                            lastMessageAt = ts
                        )
                    } else it
                }
            }
        }
    }
}
