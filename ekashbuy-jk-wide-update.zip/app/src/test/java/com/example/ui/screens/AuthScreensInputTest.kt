package com.example.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.example.data.auth.AuthUser
import com.example.ui.components.EkashbuySearchBar
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.AuthUiState
import com.example.ui.theme.EkashbuyTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthScreensInputTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun loginScreen_displaysSingleGoogleSignIn_andInvokesClickHandler() {
        var authState by mutableStateOf(
            AuthUiState(errorMessage = "Google Sign-In failed. Please try again.")
        )
        var launchClicks = 0
        var backClicks = 0

        composeTestRule.setContent {
            EkashbuyTheme {
                LoginScreen(
                    authState = authState,
                    onBeginGoogleSignIn = {},
                    onSignInWithGoogleToken = {},
                    onGoogleSignInCancelled = {},
                    onGoogleSignInError = {},
                    onClearMessages = {
                        authState = authState.copy(errorMessage = null, infoMessage = null)
                    },
                    onNavigateBack = { backClicks++ },
                    onAuthSuccess = {},
                    onLaunchGoogleSignIn = { launchClicks++ }
                )
            }
        }

        composeTestRule.onNodeWithTag("login_error_banner").assertIsDisplayed()
        composeTestRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
        composeTestRule.onNodeWithText("Continue with Google").assertIsDisplayed()
        composeTestRule.onNodeWithText("eKash").assertIsDisplayed()
        composeTestRule.onNodeWithText("Create Account").assertDoesNotExist()
        composeTestRule.onNodeWithText("Password").assertDoesNotExist()
        composeTestRule.onNodeWithText("Send OTP").assertDoesNotExist()

        composeTestRule.onNodeWithTag("google_sign_in_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, launchClicks)

        // When loading, Google Sign-In button disables to prevent duplicate requests
        authState = authState.copy(isLoading = true, errorMessage = null)
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("google_sign_in_button").assertIsNotEnabled()

        composeTestRule.onNodeWithTag("login_back_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, backClicks)
    }

    @Test
    fun authScreens_doNotNavigateBeforeProfileSyncCompletes() {
        val sampleUser = AuthUser(
            uid = "uid_google_sync_1",
            displayName = "Sana Mir",
            email = "sana@ekashbuy.in",
            phoneNumber = null,
            providerIds = listOf("google.com")
        )
        var loginState by mutableStateOf(
            AuthUiState(currentUser = sampleUser, isLoading = false, isSyncingProfile = true)
        )
        var loginSuccessCount = 0

        composeTestRule.setContent {
            EkashbuyTheme {
                LoginScreen(
                    authState = loginState,
                    onBeginGoogleSignIn = {},
                    onSignInWithGoogleToken = {},
                    onGoogleSignInCancelled = {},
                    onGoogleSignInError = {},
                    onClearMessages = {},
                    onNavigateBack = {},
                    onAuthSuccess = { loginSuccessCount++ }
                )
            }
        }

        composeTestRule.waitForIdle()
        assertEquals(0, loginSuccessCount)

        loginState = loginState.copy(isSyncingProfile = false)
        composeTestRule.waitForIdle()
        assertEquals(1, loginSuccessCount)
    }

    @Test
    fun searchBar_typingRapidlyDoesNotDuplicateOrDropCharacters() {
        var query by mutableStateOf("")

        composeTestRule.setContent {
            EkashbuyTheme {
                EkashbuySearchBar(
                    query = query,
                    onQueryChange = { query = it },
                    onSearchSubmit = {},
                    testTag = "test_search_input"
                )
            }
        }

        val searchNode = composeTestRule.onNodeWithTag("test_search_input")
        searchNode.performClick()
        "saffron".forEach { ch ->
            searchNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()
        searchNode.assertTextContains("saffron")
        assertEquals("saffron", query)
    }

    @Test
    fun inputSanitizers_filterInvalidCharsAndPreserveCursor() {
        val otp = TextFieldInputSanitizers.sanitizeDigits(
            TextFieldValue("12a34567", TextRange(8)),
            maxLength = 6
        )
        assertEquals("123456", otp.text)
        assertEquals(TextRange(6), otp.selection)

        val phone = TextFieldInputSanitizers.sanitizePhone(
            TextFieldValue("+91a 987-65+4", TextRange(13))
        )
        assertEquals("+91987654", phone.text)
        assertEquals(TextRange(9), phone.selection)
    }
}
