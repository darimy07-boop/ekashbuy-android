package com.example.ui.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.auth.AuthValidation
import com.example.data.auth.FirebaseAuthRepository
import com.example.data.firestore.FirestoreClientProvider
import com.example.data.firestore.FirestoreUserRepository
import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreUser
import com.example.model.KashmirDistrict
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val currentUser: AuthUser? = null,
    val userProfile: FirestoreUser? = null,
    val isLoading: Boolean = false,
    val isSyncingProfile: Boolean = false,
    val isUpdatingProfile: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModel(
    private val authRepository: AuthRepository,
    private val userProfileRepository: UserProfileRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AuthUiState(currentUser = authRepository.currentUser())
    )
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        val authFlow = authRepository.observeAuthState()

        authFlow
            .onEach { user ->
                _uiState.update { state ->
                    state.copy(
                        currentUser = user,
                        userProfile = if (user == null) null else state.userProfile,
                        isSyncingProfile = if (user == null) false else state.isSyncingProfile
                    )
                }
            }
            .launchIn(viewModelScope)

        if (userProfileRepository != null) {
            authFlow
                .flatMapLatest { user ->
                    if (user == null) {
                        flowOf(null)
                    } else {
                        userProfileRepository.observeUserProfile(user.uid)
                            .catch { emit(null) }
                    }
                }
                .onEach { profile ->
                    _uiState.update { it.copy(userProfile = profile) }
                }
                .launchIn(viewModelScope)
        }
    }

    fun beginGoogleSignIn() {
        _uiState.update {
            it.copy(
                isLoading = true,
                errorMessage = null,
                infoMessage = null
            )
        }
    }

    fun onGoogleSignInCancelled() {
        _uiState.update {
            it.copy(
                isLoading = false,
                isSyncingProfile = false
            )
        }
    }

    fun onGoogleSignInError(message: String) {
        _uiState.update {
            it.copy(
                isLoading = false,
                isSyncingProfile = false,
                errorMessage = message.ifBlank { "Google Sign-In failed. Please try again." },
                infoMessage = null
            )
        }
    }

    fun signInWithGoogleIdToken(idToken: String, isSilent: Boolean = false) {
        if (isSilent && authRepository.currentUser() != null) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = !isSilent,
                    isSyncingProfile = true,
                    errorMessage = if (isSilent) it.errorMessage else null,
                    infoMessage = if (isSilent) it.infoMessage else null
                )
            }
            val result = authRepository.signInWithGoogleIdToken(idToken)
            result.fold(
                onSuccess = { user ->
                    val profile = fetchUserProfileIfPresent(user)
                    _uiState.update {
                        it.copy(
                            currentUser = user,
                            userProfile = profile ?: it.userProfile,
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = null,
                            infoMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = if (isSilent) it.errorMessage else (error.message ?: "Google Sign-In failed. Please try again.")
                        )
                    }
                }
            )
        }
    }

    fun clearMessages() {
        val current = _uiState.value
        if (current.errorMessage != null || current.infoMessage != null) {
            _uiState.update { it.copy(errorMessage = null, infoMessage = null) }
        }
    }

    fun updateUserProfile(
        displayName: String,
        mobileNumber: String,
        district: KashmirDistrict,
        locality: String,
        onSuccess: () -> Unit = {}
    ) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            _uiState.update {
                it.copy(errorMessage = "Please sign in to update your profile.", infoMessage = null)
            }
            return
        }
        val repo = userProfileRepository
        if (repo == null) {
            _uiState.update {
                it.copy(errorMessage = "Profile storage is unavailable right now.", infoMessage = null)
            }
            return
        }

        val nameError = AuthValidation.validateFullName(displayName)
        if (nameError != null) {
            _uiState.update { it.copy(errorMessage = nameError, infoMessage = null) }
            return
        }
        val cleanName = displayName.trim().take(60)

        val normalizedPhone = AuthValidation.normalizePhoneToE164(mobileNumber)
        val cleanPhone = normalizedPhone ?: mobileNumber.trim()
        val phoneDigitCount = cleanPhone.count { it.isDigit() }
        if (cleanPhone.length !in 7..20 || phoneDigitCount < 7) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please enter a valid 10-digit Indian mobile number or phone number (7–20 characters).",
                    infoMessage = null
                )
            }
            return
        }

        if (district == KashmirDistrict.ALL) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please select one of the 20 Jammu & Jammu & Kashmir districts.",
                    infoMessage = null
                )
            }
            return
        }

        val cleanLocality = locality.trim()
        if (cleanLocality.length > 80) {
            _uiState.update {
                it.copy(
                    errorMessage = "Locality must be 80 characters or fewer.",
                    infoMessage = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isUpdatingProfile = true,
                    errorMessage = null,
                    infoMessage = null
                )
            }
            val existing = _uiState.value.userProfile
            val updated = FirestoreUser(
                id = currentUser.uid,
                userId = currentUser.uid,
                displayName = cleanName,
                mobileNumber = cleanPhone,
                district = district.name,
                locality = cleanLocality,
                avatarUrl = existing?.avatarUrl,
                createdAt = existing?.createdAt
            )
            val result = repo.saveUserProfile(updated)
            result.fold(
                onSuccess = {
                    val refreshed = repo.getUserProfile(currentUser.uid).getOrNull() ?: updated
                    _uiState.update {
                        it.copy(
                            userProfile = refreshed,
                            isUpdatingProfile = false,
                            errorMessage = null,
                            infoMessage = "Profile details updated."
                        )
                    }
                    onSuccess()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isUpdatingProfile = false,
                            errorMessage = error.message ?: "Unable to update profile right now."
                        )
                    }
                }
            )
        }
    }

    fun signOut() {
        authRepository.signOut()
        _uiState.update {
            AuthUiState(
                currentUser = null,
                userProfile = null,
                infoMessage = "You have been signed out."
            )
        }
    }

    private suspend fun fetchUserProfileIfPresent(user: AuthUser): FirestoreUser? {
        val repo = userProfileRepository ?: return null
        return repo.getUserProfile(user.uid).getOrNull()
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val auth = Firebase.auth
                val firestore = FirestoreClientProvider.getInstance()
                val userProfileRepo = FirestoreUserRepository(db = firestore, auth = auth)
                val authRepo = FirebaseAuthRepository(auth = auth, userProfileRepository = userProfileRepo)
                return AuthViewModel(
                    authRepository = authRepo,
                    userProfileRepository = userProfileRepo
                ) as T
            }
        }
    }
}
