package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.formatInr
import com.example.model.ConversationPreview
import com.example.ui.components.AuthRequiredCard
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange
import com.example.ui.theme.VibrantOrangeContainer

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MessagesScreen(
    uiState: MarketplaceUiState,
    onOpenProductDetails: (String) -> Unit,
    onSelectConversation: (String?) -> Unit = {},
    onSendMessage: (String, String, () -> Unit) -> Unit = { _, _, _ -> },
    onRetryConversations: () -> Unit = {},
    onClearMessageErrors: () -> Unit = {},
    onOpenLogin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var filterTab by rememberSaveable { mutableIntStateOf(0) }
    var localSelectedConversationId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uiState.isAuthenticated) {
        if (!uiState.isAuthenticated) {
            localSelectedConversationId = null
        }
    }

    val activeConversationId = uiState.selectedConversationId ?: localSelectedConversationId
    val selectedConversation: ConversationPreview? = remember(uiState.conversations, activeConversationId) {
        if (activeConversationId.isNullOrBlank()) {
            null
        } else {
            uiState.conversations.firstOrNull { it.id == activeConversationId }
        }
    }

    val filteredConversations = when (filterTab) {
        1 -> uiState.conversations.filter { it.isBuyingInquiry }
        2 -> uiState.conversations.filter { !it.isBuyingInquiry }
        3 -> uiState.conversations.filter { it.unreadCount > 0 }
        else -> uiState.conversations
    }

    val dismissThreadDialog: () -> Unit = {
        localSelectedConversationId = null
        onSelectConversation(null)
        onClearMessageErrors()
    }

    if (selectedConversation != null) {
        var replyDraft by rememberSaveable(selectedConversation.id, stateSaver = TextFieldValue.Saver) {
            mutableStateOf(TextFieldValue(""))
        }
        val threadMessages = uiState.activeConversationMessages.ifEmpty { selectedConversation.messages }

        AlertDialog(
            onDismissRequest = {
                if (!uiState.isSendingMessage) {
                    dismissThreadDialog()
                }
            },
            title = {
                Column {
                    Text(
                        text = selectedConversation.participantName,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${selectedConversation.productTitle} • ${formatInr(selectedConversation.productPriceInr)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = RoyalBlue,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when {
                        uiState.isMessagesThreadLoading && threadMessages.isEmpty() -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .testTag("chat_thread_loading"),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = RoyalBlue, strokeWidth = 2.5.dp)
                            }
                        }

                        uiState.messagesThreadError != null && threadMessages.isEmpty() -> {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.testTag("chat_thread_error")
                            ) {
                                Text(
                                    text = uiState.messagesThreadError,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                                TextButton(
                                    onClick = { onSelectConversation(selectedConversation.id) },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text("Retry", color = RoyalBlue)
                                }
                            }
                        }

                        threadMessages.isEmpty() -> {
                            Text(
                                text = "No messages in this conversation yet. Send a message below.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        else -> {
                            val threadScrollState = rememberScrollState()
                            LaunchedEffect(selectedConversation.id, threadMessages.size) {
                                threadScrollState.animateScrollTo(threadScrollState.maxValue)
                            }
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 120.dp, max = 280.dp)
                                    .verticalScroll(threadScrollState)
                                    .testTag("chat_thread_history"),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                threadMessages.forEach { msg ->
                                    val isMine = msg.isFromCurrentUser ||
                                        (uiState.currentUserId == null && msg.isFromBuyer)
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isMine) RoyalBlueContainer else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = if (msg.isFromCurrentUser) "You" else msg.senderName,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = RoyalBlue,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = msg.timeLabel,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = msg.text,
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    EkashbuyOutlinedTextField(
                        value = replyDraft,
                        onValueChange = { incoming ->
                            replyDraft = if (incoming.text.length <= 1000) incoming else replyDraft
                            onClearMessageErrors()
                        },
                        label = "Reply",
                        placeholder = "Write a message…",
                        singleLine = false,
                        minLines = 1,
                        maxLines = 3,
                        enabled = !uiState.isSendingMessage,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences,
                            autoCorrectEnabled = false
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_message_input")
                    )

                    uiState.messageActionError?.let { errorMsg ->
                        Text(
                            text = errorMsg,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.testTag("chat_message_error")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSendMessage(selectedConversation.id, replyDraft.text) {
                            replyDraft = TextFieldValue("")
                        }
                    },
                    enabled = !uiState.isSendingMessage && replyDraft.text.trim().isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    modifier = Modifier.testTag("chat_send_button")
                ) {
                    if (uiState.isSendingMessage) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Send")
                    }
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = dismissThreadDialog,
                        enabled = !uiState.isSendingMessage,
                        modifier = Modifier.testTag("chat_close_button")
                    ) {
                        Text("Close")
                    }
                    TextButton(
                        onClick = {
                            val prodId = selectedConversation.productId
                            dismissThreadDialog()
                            onOpenProductDetails(prodId)
                        },
                        enabled = !uiState.isSendingMessage,
                        modifier = Modifier.testTag("chat_view_ad_button")
                    ) {
                        Text("View Ad", color = VibrantOrange)
                    }
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Messages", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            text = if (uiState.unreadConversationsCount > 0) {
                                "Direct buyer & seller chats • ${uiState.unreadConversationsCount} unread"
                            } else {
                                "Direct buyer & seller chats"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (uiState.unreadConversationsCount > 0) VibrantOrange else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                !uiState.isAuthenticated -> {
                    AuthRequiredCard(
                        title = "Sign in to view your messages",
                        subtitle = "Chat directly with local buyers and sellers across Kashmir and inspect items in person.",
                        onOpenLogin = onOpenLogin,
                        testTag = "messages_signin_prompt",
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                uiState.isConversationsLoading -> {
                    LoadingStateView(
                        message = "Loading your conversations…",
                        testTag = "messages_loading_indicator",
                        modifier = Modifier.weight(1f)
                    )
                }

                uiState.conversationsError != null -> {
                    ErrorStateView(
                        title = "Could not load messages",
                        message = uiState.conversationsError,
                        onRetry = onRetryConversations,
                        testTag = "messages_error_state",
                        retryButtonTestTag = "messages_retry_button"
                    )
                }

                else -> {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val filterLabels = listOf(
                            "All",
                            "Buying",
                            "Selling",
                            if (uiState.unreadConversationsCount > 0) "Unread (${uiState.unreadConversationsCount})" else "Unread"
                        )
                        val filterTags = listOf("all", "buying", "selling", "unread")
                        filterLabels.forEachIndexed { idx, label ->
                            FilterChip(
                                selected = filterTab == idx,
                                onClick = { filterTab = idx },
                                label = { Text(label) },
                                modifier = Modifier.testTag("messages_filter_${filterTags[idx]}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (filteredConversations.isEmpty()) {
                        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            EmptyStateView(
                                title = if (uiState.conversations.isEmpty()) {
                                    "No conversations yet"
                                } else {
                                    "No conversations in this filter"
                                },
                                subtitle = if (uiState.conversations.isEmpty()) {
                                    "Open any product advertisement and tap Message to start a direct chat with the seller."
                                } else {
                                    "Switch between All, Buying, Selling, and Unread filters to view your chats."
                                }
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredConversations, key = { it.id }) { conv ->
                                val isUnread = conv.unreadCount > 0
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.medium)
                                        .clickable {
                                            localSelectedConversationId = conv.id
                                            onSelectConversation(conv.id)
                                        }
                                        .testTag("conversation_card_${conv.id}"),
                                    shape = MaterialTheme.shapes.medium,
                                    color = if (isUnread) RoyalBlueContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        width = if (isUnread) 1.5.dp else 1.dp,
                                        color = if (isUnread) RoyalBlue.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = RoyalBlueContainer
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Person,
                                                contentDescription = conv.participantName,
                                                tint = RoyalBlue,
                                                modifier = Modifier
                                                    .padding(12.dp)
                                                    .size(22.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    modifier = Modifier.weight(1f),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(
                                                        text = conv.participantName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f, fill = false)
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(50),
                                                        color = if (conv.isBuyingInquiry) RoyalBlueContainer else EmeraldContainer
                                                    ) {
                                                        Text(
                                                            text = if (conv.isBuyingInquiry) "Buying" else "Selling",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = if (conv.isBuyingInquiry) RoyalBlue else EmeraldBadge,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = conv.timestamp,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (isUnread) VibrantOrange else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = if (isUnread) FontWeight.SemiBold else FontWeight.Normal
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${conv.productTitle} • ${formatInr(conv.productPriceInr)}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = RoyalBlue,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text(
                                                text = conv.lastMessage.ifBlank { "Tap to view messages" },
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = if (isUnread) FontWeight.SemiBold else FontWeight.Normal,
                                                color = if (isUnread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (isUnread) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = VibrantOrange,
                                                modifier = Modifier.testTag("conversation_unread_badge_${conv.id}")
                                            ) {
                                                Text(
                                                    text = if (conv.unreadCount > 1) "${conv.unreadCount}" else "New",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                HorizontalDivider(color = Color.Transparent)
                            }
                        }
                    }
                }
            }
        }
    }
}
