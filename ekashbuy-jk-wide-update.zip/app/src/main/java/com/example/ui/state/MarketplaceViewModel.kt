package com.example.ui.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.auth.FirebaseAuthRepository
import com.example.data.firestore.FavouritesRepository
import com.example.data.firestore.FirestoreClientProvider
import com.example.data.firestore.FirestoreFavouritesRepository
import com.example.data.firestore.FirestoreListingsRepository
import com.example.data.firestore.FirestoreMessagesRepository
import com.example.data.firestore.FirestoreUserRepository
import com.example.data.firestore.ListingValidation
import com.example.data.firestore.ListingValidationResult
import com.example.data.firestore.ListingsRepository
import com.example.data.firestore.MessagesRepository
import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreConversation
import com.example.data.firestore.model.FirestoreFavourite
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.model.FirestoreMessageEntry
import com.example.data.firestore.model.FirestoreUser
import com.example.data.local.InMemoryMarketplaceLocalStore
import com.example.data.local.MarketplaceLocalStore
import com.example.data.local.SharedPreferencesMarketplaceLocalStore
import com.example.data.firestore.toChatMessagePreview
import com.example.data.firestore.toConversationPreview
import com.example.data.firestore.toFirestoreListingSnapshot
import com.example.data.firestore.toProductListing
import com.example.data.firestore.unwrapFirestoreException
import com.example.data.media.AdPhotoValidator
import com.example.data.media.PhotoCandidate
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.ChatMessagePreview
import com.example.model.ConversationPreview
import com.example.model.KashmirDistrict
import com.example.model.MarketplaceFilters
import com.example.model.PostAdDraft
import com.example.model.ProductListing
import com.example.model.SortOption
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MarketplaceUiState(
    val isAuthenticated: Boolean = false,
    val currentUserId: String? = null,
    val currentUserName: String = "",
    val currentUserPhone: String = "",
    val selectedHomeDistrict: KashmirDistrict = KashmirDistrict.ALL,
    val homeSearchQuery: String = "",
    val searchHistory: List<String> = emptyList(),
    val allListings: List<ProductListing> = emptyList(),
    val homeListings: List<ProductListing> = emptyList(),
    val filteredListings: List<ProductListing> = emptyList(),
    val myListings: List<ProductListing> = emptyList(),
    val isListingsLoading: Boolean = false,
    val listingsError: String? = null,
    val isMyAdsLoading: Boolean = false,
    val myAdsError: String? = null,
    val filters: MarketplaceFilters = MarketplaceFilters(),
    val conversations: List<ConversationPreview> = emptyList(),
    val unreadConversationsCount: Int = 0,
    val isConversationsLoading: Boolean = false,
    val conversationsError: String? = null,
    val selectedConversationId: String? = null,
    val activeConversationMessages: List<ChatMessagePreview> = emptyList(),
    val isMessagesThreadLoading: Boolean = false,
    val messagesThreadError: String? = null,
    val isStartingConversation: Boolean = false,
    val isSendingMessage: Boolean = false,
    val messageActionError: String? = null,
    val favoriteIds: Set<String> = emptySet(),
    val savedFavourites: List<FirestoreFavourite> = emptyList(),
    val postAdDraft: PostAdDraft = PostAdDraft(),
    val isSubmittingAd: Boolean = false,
    val deletingListingId: String? = null,
    val updatingStatusListingId: String? = null,
    val adActionError: String? = null,
    val adActionSuccessMessage: String? = null,
    val categoryCounts: Map<AdCategory, Int> = emptyMap(),
    val districtCounts: Map<KashmirDistrict, Int> = emptyMap()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MarketplaceViewModel(
    private val authRepository: AuthRepository,
    private val listingsRepository: ListingsRepository,
    private val favouritesRepository: FavouritesRepository,
    private val userProfileRepository: UserProfileRepository? = null,
    private val messagesRepository: MessagesRepository? = null,
    private val localStore: MarketplaceLocalStore = InMemoryMarketplaceLocalStore()
) : ViewModel() {

    private sealed class ListingsStreamState {
        data object SignedOut : ListingsStreamState()
        data object Loading : ListingsStreamState()
        data class Loaded(val items: List<ProductListing>) : ListingsStreamState()
        data class Error(val message: String) : ListingsStreamState()
    }

    private sealed class ConversationsStreamState {
        data object SignedOut : ConversationsStreamState()
        data object Loading : ConversationsStreamState()
        data class Loaded(val items: List<FirestoreConversation>) : ConversationsStreamState()
        data class Error(val message: String) : ConversationsStreamState()
    }

    private sealed class ThreadStreamState {
        data object Idle : ThreadStreamState()
        data object Loading : ThreadStreamState()
        data class Loaded(val items: List<FirestoreMessageEntry>) : ThreadStreamState()
        data class Error(val message: String) : ThreadStreamState()
    }

    private data class AuthSnapshot(
        val user: AuthUser?,
        val refreshTick: Int
    )

    private data class RemoteData(
        val authUser: AuthUser?,
        val userProfile: FirestoreUser?,
        val activeListings: ListingsStreamState,
        val sellerListings: ListingsStreamState,
        val favourites: List<FirestoreFavourite>
    )

    private data class UiLocalState(
        val homeDistrict: KashmirDistrict,
        val homeSearch: String,
        val searchHistory: List<String>,
        val filters: MarketplaceFilters,
        val draft: PostAdDraft,
        val mutationState: AdMutationState
    )

    private data class MessagingData(
        val conversationsState: ConversationsStreamState,
        val selectedConversationId: String?,
        val threadState: ThreadStreamState,
        val mutationState: MessageMutationState,
        val readTimestamps: Map<String, Long>
    )

    private data class AdMutationState(
        val isSubmittingAd: Boolean = false,
        val deletingListingId: String? = null,
        val updatingStatusListingId: String? = null,
        val errorMessage: String? = null,
        val successMessage: String? = null
    )

    private data class MessageMutationState(
        val isStartingConversation: Boolean = false,
        val isSendingMessage: Boolean = false,
        val errorMessage: String? = null
    )

    private val refreshTriggerFlow = MutableStateFlow(0)
    private val conversationsRefreshTriggerFlow = MutableStateFlow(0)
    private val homeDistrictFlow = MutableStateFlow(KashmirDistrict.ALL)
    private val homeSearchFlow = MutableStateFlow("")
    private val filtersFlow = MutableStateFlow(MarketplaceFilters())
    private val postAdDraftFlow = MutableStateFlow(PostAdDraft())
    private val adMutationFlow = MutableStateFlow(AdMutationState())
    private val activeConversationIdFlow = MutableStateFlow<String?>(null)
    private val messageMutationFlow = MutableStateFlow(MessageMutationState())
    private val pendingFavLock = Any()
    private val pendingFavouriteIds = mutableSetOf<String>()

    private val authSnapshotFlow: Flow<AuthSnapshot> = combine(
        authRepository.observeAuthState(),
        refreshTriggerFlow
    ) { user, tick ->
        if (user == null) {
            activeConversationIdFlow.value = null
        }
        AuthSnapshot(user = user, refreshTick = tick)
    }

    private val messagingAuthSnapshotFlow: Flow<AuthSnapshot> = combine(
        authRepository.observeAuthState(),
        conversationsRefreshTriggerFlow
    ) { user, tick ->
        AuthSnapshot(user = user, refreshTick = tick)
    }

    private val activeListingsFlow: Flow<ListingsStreamState> = authSnapshotFlow.flatMapLatest { snapshot ->
        val user = snapshot.user
        if (user == null) {
            flowOf<ListingsStreamState>(ListingsStreamState.SignedOut)
        } else {
            flow<ListingsStreamState> {
                emit(ListingsStreamState.Loading)
                emitAll(
                    listingsRepository.observeActiveListings()
                        .map<List<com.example.data.firestore.model.FirestoreListing>, ListingsStreamState> { docs ->
                            ListingsStreamState.Loaded(docs.map { it.toProductListing() })
                        }
                        .catch { error ->
                            val firestoreError = error.unwrapFirestoreException()
                            if (firestoreError == null && error is CancellationException) throw error
                            emit(ListingsStreamState.Error(toUserReadError(firestoreError ?: error)))
                        }
                )
            }
        }
    }

    private val sellerListingsFlow: Flow<ListingsStreamState> = authSnapshotFlow.flatMapLatest { snapshot ->
        val user = snapshot.user
        if (user == null) {
            flowOf<ListingsStreamState>(ListingsStreamState.SignedOut)
        } else {
            flow<ListingsStreamState> {
                emit(ListingsStreamState.Loading)
                emitAll(
                    listingsRepository.observeSellerListings(user.uid)
                        .map<List<com.example.data.firestore.model.FirestoreListing>, ListingsStreamState> { docs ->
                            val visible = docs
                                .filter { it.status != FirestoreListingStatus.ARCHIVED.name }
                                .map { it.toProductListing() }
                            ListingsStreamState.Loaded(visible)
                        }
                        .catch { error ->
                            val firestoreError = error.unwrapFirestoreException()
                            if (firestoreError == null && error is CancellationException) throw error
                            emit(ListingsStreamState.Error(toUserReadError(firestoreError ?: error)))
                        }
                )
            }
        }
    }

    private val favoritesFlow: Flow<List<FirestoreFavourite>> = authSnapshotFlow.flatMapLatest { snapshot ->
        val user = snapshot.user
        if (user == null) {
            flowOf(emptyList())
        } else {
            favouritesRepository.observeUserFavourites(user.uid)
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(emptyList())
                }
        }
    }

    private val userProfileFlow: Flow<FirestoreUser?> = authSnapshotFlow.flatMapLatest { snapshot ->
        val user = snapshot.user
        if (user == null || userProfileRepository == null) {
            flowOf(null)
        } else {
            userProfileRepository.observeUserProfile(user.uid)
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(null)
                }
        }
    }

    private val conversationsStreamFlow: Flow<ConversationsStreamState> = messagingAuthSnapshotFlow.flatMapLatest { snapshot ->
        val user = snapshot.user
        val repo = messagesRepository
        if (user == null || repo == null) {
            flowOf<ConversationsStreamState>(ConversationsStreamState.SignedOut)
        } else {
            flow<ConversationsStreamState> {
                emit(ConversationsStreamState.Loading)
                emitAll(
                    repo.observeUserConversations(user.uid)
                        .map<List<FirestoreConversation>, ConversationsStreamState> { docs ->
                            ConversationsStreamState.Loaded(docs)
                        }
                        .catch { error ->
                            val firestoreError = error.unwrapFirestoreException()
                            if (firestoreError == null && error is CancellationException) throw error
                            emit(ConversationsStreamState.Error(toUserMessageReadError(firestoreError ?: error)))
                        }
                )
            }
        }
    }

    private val threadStreamFlow: Flow<ThreadStreamState> = combine(
        messagingAuthSnapshotFlow,
        activeConversationIdFlow
    ) { snapshot, conversationId ->
        snapshot.user to conversationId
    }.flatMapLatest { (user, conversationId) ->
        val repo = messagesRepository
        if (user == null || conversationId.isNullOrBlank() || repo == null) {
            flowOf<ThreadStreamState>(ThreadStreamState.Idle)
        } else {
            flow<ThreadStreamState> {
                emit(ThreadStreamState.Loading)
                emitAll(
                    repo.observeConversationMessages(conversationId)
                        .onEach { entries ->
                            val latestMillis = entries
                                .mapNotNull { it.createdAt?.toDate()?.time }
                                .maxOrNull()
                                ?: 0L
                            localStore.markConversationRead(
                                userId = user.uid,
                                conversationId = conversationId,
                                timestampMillis = maxOf(System.currentTimeMillis(), latestMillis)
                            )
                        }
                        .map<List<FirestoreMessageEntry>, ThreadStreamState> { entries ->
                            ThreadStreamState.Loaded(entries)
                        }
                        .catch { error ->
                            val firestoreError = error.unwrapFirestoreException()
                            if (firestoreError == null && error is CancellationException) throw error
                            emit(ThreadStreamState.Error(toUserMessageReadError(firestoreError ?: error)))
                        }
                )
            }
        }
    }

    private val searchHistoryStreamFlow: Flow<List<String>> = authSnapshotFlow.flatMapLatest { snapshot ->
        localStore.observeSearchHistory(snapshot.user?.uid.orEmpty())
    }

    private val conversationReadMapFlow: Flow<Map<String, Long>> = messagingAuthSnapshotFlow.flatMapLatest { snapshot ->
        val uid = snapshot.user?.uid
        if (uid == null) flowOf(emptyMap()) else localStore.observeConversationLastReadMillis(uid)
    }

    private val remoteDataFlow: Flow<RemoteData> = combine(
        authSnapshotFlow.map { it.user },
        userProfileFlow,
        activeListingsFlow,
        sellerListingsFlow,
        favoritesFlow
    ) { user, profile, activeListings, sellerListings, favourites ->
        RemoteData(
            authUser = user,
            userProfile = profile,
            activeListings = activeListings,
            sellerListings = sellerListings,
            favourites = favourites
        )
    }

    private val localCoreStateFlow = combine(
        homeDistrictFlow,
        homeSearchFlow,
        filtersFlow,
        postAdDraftFlow,
        adMutationFlow
    ) { homeDistrict, homeSearch, filters, draft, mutation ->
        UiLocalState(
            homeDistrict = homeDistrict,
            homeSearch = homeSearch,
            searchHistory = emptyList(),
            filters = filters,
            draft = draft,
            mutationState = mutation
        )
    }

    private val localStateFlow: Flow<UiLocalState> = combine(
        localCoreStateFlow,
        searchHistoryStreamFlow
    ) { core, history ->
        core.copy(searchHistory = history)
    }

    private val messagingDataFlow: Flow<MessagingData> = combine(
        conversationsStreamFlow,
        activeConversationIdFlow,
        threadStreamFlow,
        messageMutationFlow,
        conversationReadMapFlow
    ) { conversationsState, selectedId, threadState, mutationState, readTimestamps ->
        MessagingData(
            conversationsState = conversationsState,
            selectedConversationId = selectedId,
            threadState = threadState,
            mutationState = mutationState,
            readTimestamps = readTimestamps
        )
    }

    val uiState: StateFlow<MarketplaceUiState> = combine(
        remoteDataFlow,
        localStateFlow,
        messagingDataFlow
    ) { remote, local, messaging ->
        val activeItems = when (val state = remote.activeListings) {
            is ListingsStreamState.Loaded -> state.items
            else -> emptyList()
        }
        val myItems = when (val state = remote.sellerListings) {
            is ListingsStreamState.Loaded -> state.items
            else -> emptyList()
        }

        val cleanHomeQuery = local.homeSearch.trim()
        val homeFiltered = activeItems.filter { item ->
            val matchesDistrict = local.homeDistrict == KashmirDistrict.ALL || item.district == local.homeDistrict
            val matchesQuery = cleanHomeQuery.isEmpty() ||
                item.title.contains(cleanHomeQuery, ignoreCase = true) ||
                item.description.contains(cleanHomeQuery, ignoreCase = true) ||
                item.locality.contains(cleanHomeQuery, ignoreCase = true) ||
                item.category.title.contains(cleanHomeQuery, ignoreCase = true) ||
                item.district.displayName.contains(cleanHomeQuery, ignoreCase = true)
            matchesDistrict && matchesQuery
        }

        val listingsFiltered = applyFilters(activeItems, local.filters)

        val categoryCounts = AdCategory.entries.associateWith { cat ->
            activeItems.count { it.category == cat }
        }
        val districtCounts = KashmirDistrict.entries.associateWith { dist ->
            if (dist == KashmirDistrict.ALL) activeItems.size
            else activeItems.count { it.district == dist }
        }

        val resolvedName = remote.userProfile?.displayName?.takeIf { it.isNotBlank() }
            ?: remote.authUser?.displayName?.takeIf { it.isNotBlank() }
            ?: ""
        val resolvedPhone = remote.userProfile?.mobileNumber?.takeIf { it.isNotBlank() }
            ?: remote.authUser?.phoneNumber?.takeIf { it.isNotBlank() }
            ?: ""

        val currentUid = remote.authUser?.uid ?: ""
        val rawConversations = when (val state = messaging.conversationsState) {
            is ConversationsStreamState.Loaded -> state.items
            else -> emptyList()
        }
        val selectedConv = rawConversations.firstOrNull { it.id == messaging.selectedConversationId }
        val activeMessages = when (val thread = messaging.threadState) {
            is ThreadStreamState.Loaded -> thread.items.map { entry ->
                entry.toChatMessagePreview(
                    currentUserId = currentUid,
                    buyerId = selectedConv?.buyerId ?: ""
                )
            }
            else -> emptyList()
        }
        val mappedConversations = rawConversations.map { conv ->
            val preview = conv.toConversationPreview(currentUserId = currentUid)
            val lastReadMillis = messaging.readTimestamps[conv.id] ?: 0L
            val fromOtherParticipant = currentUid.isNotBlank() &&
                conv.lastSenderId.isNotBlank() &&
                conv.lastSenderId != currentUid &&
                conv.id != messaging.selectedConversationId
            val isUnread = fromOtherParticipant && (
                preview.lastMessageAtMillis > lastReadMillis ||
                    (lastReadMillis == 0L && conv.lastMessageText.isNotBlank())
                )
            preview.copy(unreadCount = if (isUnread) 1 else 0)
        }
        val unreadConversationsCount = mappedConversations.count { it.unreadCount > 0 }

        MarketplaceUiState(
            isAuthenticated = remote.authUser != null,
            currentUserId = remote.authUser?.uid,
            currentUserName = resolvedName,
            currentUserPhone = resolvedPhone,
            selectedHomeDistrict = local.homeDistrict,
            homeSearchQuery = local.homeSearch,
            searchHistory = local.searchHistory,
            allListings = activeItems,
            homeListings = homeFiltered,
            filteredListings = listingsFiltered,
            myListings = myItems,
            isListingsLoading = remote.activeListings is ListingsStreamState.Loading,
            listingsError = (remote.activeListings as? ListingsStreamState.Error)?.message,
            isMyAdsLoading = remote.sellerListings is ListingsStreamState.Loading,
            myAdsError = (remote.sellerListings as? ListingsStreamState.Error)?.message,
            filters = local.filters,
            conversations = mappedConversations,
            unreadConversationsCount = unreadConversationsCount,
            isConversationsLoading = messaging.conversationsState is ConversationsStreamState.Loading,
            conversationsError = (messaging.conversationsState as? ConversationsStreamState.Error)?.message,
            selectedConversationId = messaging.selectedConversationId,
            activeConversationMessages = activeMessages,
            isMessagesThreadLoading = messaging.threadState is ThreadStreamState.Loading,
            messagesThreadError = (messaging.threadState as? ThreadStreamState.Error)?.message,
            isStartingConversation = messaging.mutationState.isStartingConversation,
            isSendingMessage = messaging.mutationState.isSendingMessage,
            messageActionError = messaging.mutationState.errorMessage,
            favoriteIds = remote.favourites.map { it.listingId }.toSet(),
            savedFavourites = remote.favourites,
            postAdDraft = local.draft,
            isSubmittingAd = local.mutationState.isSubmittingAd,
            deletingListingId = local.mutationState.deletingListingId,
            updatingStatusListingId = local.mutationState.updatingStatusListingId,
            adActionError = local.mutationState.errorMessage,
            adActionSuccessMessage = local.mutationState.successMessage,
            categoryCounts = categoryCounts,
            districtCounts = districtCounts
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MarketplaceUiState(
            isAuthenticated = authRepository.currentUser() != null,
            currentUserId = authRepository.currentUser()?.uid
        )
    )

    fun setHomeDistrict(district: KashmirDistrict) {
        homeDistrictFlow.value = district
    }

    fun setHomeSearchQuery(query: String) {
        homeSearchFlow.value = query
    }

    fun updateFilters(transform: (MarketplaceFilters) -> MarketplaceFilters) {
        filtersFlow.update(transform)
    }

    fun applyListingShortcut(
        category: AdCategory? = null,
        district: KashmirDistrict? = null,
        query: String? = null
    ) {
        filtersFlow.value = MarketplaceFilters(
            query = query ?: "",
            district = district ?: homeDistrictFlow.value,
            category = category
        )
    }

    fun recordSearchQuery(query: String) {
        val clean = query.trim()
        if (clean.length < 2) return
        val uid = authRepository.currentUser()?.uid.orEmpty()
        localStore.recordSearchQuery(uid, clean)
    }

    fun removeSearchHistoryItem(query: String) {
        val uid = authRepository.currentUser()?.uid.orEmpty()
        localStore.removeSearchQuery(uid, query)
    }

    fun clearSearchHistory() {
        val uid = authRepository.currentUser()?.uid.orEmpty()
        localStore.clearSearchHistory(uid)
    }

    fun resetFilters() {
        filtersFlow.value = MarketplaceFilters()
    }

    fun retryListings() {
        refreshTriggerFlow.update { it + 1 }
    }

    fun retryConversations() {
        conversationsRefreshTriggerFlow.update { it + 1 }
    }

    fun selectConversation(conversationId: String?) {
        activeConversationIdFlow.value = conversationId
        messageMutationFlow.update { it.copy(errorMessage = null) }
        val uid = authRepository.currentUser()?.uid
        if (uid != null && !conversationId.isNullOrBlank()) {
            val convMillis = uiState.value.conversations
                .firstOrNull { it.id == conversationId }
                ?.lastMessageAtMillis
                ?: 0L
            localStore.markConversationRead(
                userId = uid,
                conversationId = conversationId,
                timestampMillis = maxOf(System.currentTimeMillis(), convMillis)
            )
        }
    }

    fun startConversation(
        listing: ProductListing,
        initialMessage: String,
        onConversationReady: (String) -> Unit = {}
    ) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Please sign in to message sellers.")
            }
            return
        }
        if (listing.sellerId == currentUser.uid) {
            messageMutationFlow.update {
                it.copy(errorMessage = "You cannot start a buyer chat on your own advertisement.")
            }
            return
        }
        val repo = messagesRepository
        if (repo == null) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Messaging service is unavailable right now.")
            }
            return
        }

        val trimmedMessage = initialMessage.trim()
        if (trimmedMessage.isEmpty() || trimmedMessage.length > 1000) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Please enter a message between 1 and 1000 characters.")
            }
            return
        }

        val buyerName = uiState.value.currentUserName
            .ifBlank { currentUser.displayName.orEmpty() }
            .ifBlank { currentUser.phoneNumber.orEmpty() }
            .ifBlank { "eKashbuy Buyer" }
            .trim()
            .take(60)

        viewModelScope.launch {
            messageMutationFlow.update {
                it.copy(isStartingConversation = true, errorMessage = null)
            }
            val result = repo.getOrCreateConversation(
                listing = listing.toFirestoreListingSnapshot(),
                buyerName = buyerName,
                initialMessage = trimmedMessage
            )
            result.fold(
                onSuccess = { conversationId ->
                    localStore.markConversationRead(
                        userId = currentUser.uid,
                        conversationId = conversationId,
                        timestampMillis = System.currentTimeMillis()
                    )
                    activeConversationIdFlow.value = conversationId
                    messageMutationFlow.update {
                        it.copy(isStartingConversation = false, errorMessage = null)
                    }
                    onConversationReady(conversationId)
                },
                onFailure = { error ->
                    messageMutationFlow.update {
                        it.copy(
                            isStartingConversation = false,
                            errorMessage = toUserMessageWriteError(error)
                        )
                    }
                }
            )
        }
    }

    fun sendChatMessage(
        conversationId: String,
        text: String,
        onSuccess: () -> Unit = {}
    ) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Please sign in to send messages.")
            }
            return
        }
        val repo = messagesRepository
        if (repo == null) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Messaging service is unavailable right now.")
            }
            return
        }

        val trimmedText = text.trim()
        if (trimmedText.isEmpty() || trimmedText.length > 1000) {
            messageMutationFlow.update {
                it.copy(errorMessage = "Message must be between 1 and 1000 characters.")
            }
            return
        }

        val senderName = uiState.value.currentUserName
            .ifBlank { currentUser.displayName.orEmpty() }
            .ifBlank { currentUser.phoneNumber.orEmpty() }
            .ifBlank { "eKashbuy User" }
            .trim()
            .take(60)

        viewModelScope.launch {
            messageMutationFlow.update {
                it.copy(isSendingMessage = true, errorMessage = null)
            }
            val result = repo.sendMessage(
                conversationId = conversationId,
                senderName = senderName,
                text = trimmedText
            )
            result.fold(
                onSuccess = {
                    localStore.markConversationRead(
                        userId = currentUser.uid,
                        conversationId = conversationId,
                        timestampMillis = System.currentTimeMillis()
                    )
                    messageMutationFlow.update {
                        it.copy(isSendingMessage = false, errorMessage = null)
                    }
                    onSuccess()
                },
                onFailure = { error ->
                    messageMutationFlow.update {
                        it.copy(
                            isSendingMessage = false,
                            errorMessage = toUserMessageWriteError(error)
                        )
                    }
                }
            )
        }
    }

    fun clearMessageErrors() {
        messageMutationFlow.update {
            if (it.errorMessage != null) it.copy(errorMessage = null) else it
        }
    }

    fun toggleFavorite(productId: String) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            adMutationFlow.update { it.copy(errorMessage = "Please sign in to save advertisements.") }
            return
        }
        synchronized(pendingFavLock) {
            if (productId in pendingFavouriteIds) return
            pendingFavouriteIds.add(productId)
        }
        val state = uiState.value
        viewModelScope.launch {
            try {
                if (productId in state.favoriteIds) {
                    val result = favouritesRepository.removeFavourite(productId)
                    result.onFailure { error ->
                        adMutationFlow.update { it.copy(errorMessage = toUserWriteError(error)) }
                    }
                } else {
                    val product = state.allListings.firstOrNull { it.id == productId }
                        ?: state.myListings.firstOrNull { it.id == productId }
                    if (product == null) {
                        adMutationFlow.update {
                            it.copy(errorMessage = "This advertisement is no longer available to save.")
                        }
                        return@launch
                    }
                    val result = favouritesRepository.addFavourite(product.toFirestoreListingSnapshot())
                    result.onFailure { error ->
                        adMutationFlow.update { it.copy(errorMessage = toUserWriteError(error)) }
                    }
                }
            } finally {
                synchronized(pendingFavLock) {
                    pendingFavouriteIds.remove(productId)
                }
            }
        }
    }

    fun getProductById(productId: String): ProductListing? {
        val state = uiState.value
        return state.allListings.firstOrNull { it.id == productId }
            ?: state.myListings.firstOrNull { it.id == productId }
    }

    fun updatePostAdDraft(transform: (PostAdDraft) -> PostAdDraft) {
        postAdDraftFlow.update(transform)
    }

    fun resetPostAdDraft() {
        postAdDraftFlow.update { current ->
            PostAdDraft(draftVersion = current.draftVersion + 1)
        }
        adMutationFlow.update { it.copy(errorMessage = null) }
    }

    fun addSelectedPhotoCandidates(candidates: List<PhotoCandidate>) {
        postAdDraftFlow.update { current ->
            val merged = AdPhotoValidator.mergeSelectedPhotos(
                existing = current.selectedPhotos,
                candidates = candidates
            )
            current.copy(
                selectedPhotos = merged.photos,
                photoError = merged.errorMessage
            )
        }
    }

    fun removeSelectedPhoto(index: Int) {
        postAdDraftFlow.update { current ->
            current.copy(
                selectedPhotos = AdPhotoValidator.removePhotoAt(current.selectedPhotos, index),
                photoError = null
            )
        }
    }

    fun moveSelectedPhoto(fromIndex: Int, toIndex: Int) {
        postAdDraftFlow.update { current ->
            current.copy(
                selectedPhotos = AdPhotoValidator.movePhoto(current.selectedPhotos, fromIndex, toIndex),
                photoError = null
            )
        }
    }

    fun setMainSelectedPhoto(index: Int) {
        postAdDraftFlow.update { current ->
            current.copy(
                selectedPhotos = AdPhotoValidator.setMainPhoto(current.selectedPhotos, index),
                photoError = null
            )
        }
    }

    fun setPhotoSelectionError(message: String?) {
        postAdDraftFlow.update { current ->
            current.copy(photoError = message)
        }
    }

    fun clearPhotoSelectionError() {
        postAdDraftFlow.update { current ->
            if (current.photoError != null) current.copy(photoError = null) else current
        }
    }

    fun startEditingListing(listing: ProductListing) {
        val currentUid = authRepository.currentUser()?.uid
        if (currentUid == null || listing.sellerId != currentUid) {
            adMutationFlow.update { it.copy(errorMessage = "You can only edit your own advertisements.") }
            return
        }
        postAdDraftFlow.update { current ->
            PostAdDraft(
                editingListingId = listing.id,
                title = listing.title,
                priceText = listing.priceInr.toString(),
                isMonthlyRent = listing.isMonthlyRent,
                negotiable = listing.negotiable,
                category = listing.category,
                district = if (listing.district == KashmirDistrict.ALL) KashmirDistrict.SRINAGAR else listing.district,
                locality = listing.locality,
                condition = listing.condition,
                description = listing.description,
                sellerName = listing.sellerName,
                sellerPhone = listing.sellerPhone,
                selectedPhotos = emptyList(),
                photoError = null,
                draftVersion = current.draftVersion + 1
            )
        }
        adMutationFlow.update { it.copy(errorMessage = null, successMessage = null) }
    }

    fun submitListing(
        title: String,
        priceText: String,
        isMonthlyRent: Boolean,
        negotiable: Boolean,
        category: AdCategory,
        district: KashmirDistrict,
        locality: String,
        condition: AdCondition,
        description: String,
        sellerName: String,
        sellerPhone: String,
        onSuccess: () -> Unit = {}
    ) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            adMutationFlow.update {
                it.copy(errorMessage = "Please sign in with Google to publish an advertisement.")
            }
            return
        }

        val editingId = postAdDraftFlow.value.editingListingId
        val existingOwnedListing = if (editingId != null) {
            uiState.value.myListings.firstOrNull { it.id == editingId }
                ?: uiState.value.allListings.firstOrNull { it.id == editingId }
        } else null

        if (editingId != null && existingOwnedListing != null && existingOwnedListing.sellerId != currentUser.uid) {
            adMutationFlow.update {
                it.copy(errorMessage = "You can only edit advertisements posted from your own account.")
            }
            return
        }

        when (
            val validation = ListingValidation.validateAndBuild(
                editingListingId = editingId,
                sellerId = currentUser.uid,
                title = title,
                priceText = priceText,
                isMonthlyRent = isMonthlyRent,
                negotiable = negotiable,
                category = category,
                district = district,
                locality = locality,
                condition = condition,
                description = description,
                sellerName = sellerName,
                sellerPhone = sellerPhone,
                existingSpecs = existingOwnedListing?.specs ?: emptyMap(),
                existingImageUrls = existingOwnedListing?.imageUrls ?: emptyList()
            )
        ) {
            is ListingValidationResult.Invalid -> {
                adMutationFlow.update {
                    it.copy(errorMessage = validation.message, successMessage = null)
                }
            }

            is ListingValidationResult.Valid -> {
                viewModelScope.launch {
                    adMutationFlow.update {
                        it.copy(isSubmittingAd = true, errorMessage = null, successMessage = null)
                    }
                    val result = if (editingId != null) {
                        listingsRepository.updateListing(validation.listing)
                    } else {
                        listingsRepository.createListing(validation.listing).map { Unit }
                    }
                    result.fold(
                        onSuccess = {
                            postAdDraftFlow.update { current ->
                                PostAdDraft(draftVersion = current.draftVersion + 1)
                            }
                            val msg = if (editingId != null) {
                                "Your advertisement has been updated."
                            } else {
                                "Your free ordinary ad is now live in ${district.displayName}!"
                            }
                            adMutationFlow.update {
                                it.copy(
                                    isSubmittingAd = false,
                                    errorMessage = null,
                                    successMessage = msg
                                )
                            }
                            onSuccess()
                        },
                        onFailure = { error ->
                            adMutationFlow.update {
                                it.copy(
                                    isSubmittingAd = false,
                                    errorMessage = toUserWriteError(error)
                                )
                            }
                        }
                    )
                }
            }
        }
    }

    fun updateListingStatus(listingId: String, newStatus: FirestoreListingStatus) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            adMutationFlow.update { it.copy(errorMessage = "Please sign in to manage your ads.") }
            return
        }
        val owned = uiState.value.myListings.firstOrNull { it.id == listingId }
            ?: uiState.value.allListings.firstOrNull { it.id == listingId }
        if (owned != null && owned.sellerId != currentUser.uid) {
            adMutationFlow.update { it.copy(errorMessage = "You can only update your own advertisements.") }
            return
        }

        viewModelScope.launch {
            adMutationFlow.update {
                it.copy(updatingStatusListingId = listingId, errorMessage = null, successMessage = null)
            }
            val result = listingsRepository.updateListingStatus(listingId, newStatus)
            result.fold(
                onSuccess = {
                    val statusLabel = when (newStatus) {
                        FirestoreListingStatus.ACTIVE -> "reactivated"
                        FirestoreListingStatus.PAUSED -> "paused"
                        FirestoreListingStatus.SOLD -> "marked as sold"
                        FirestoreListingStatus.ARCHIVED -> "archived"
                    }
                    adMutationFlow.update {
                        it.copy(
                            updatingStatusListingId = null,
                            successMessage = "Advertisement $statusLabel."
                        )
                    }
                },
                onFailure = { error ->
                    adMutationFlow.update {
                        it.copy(
                            updatingStatusListingId = null,
                            errorMessage = toUserWriteError(error)
                        )
                    }
                }
            )
        }
    }

    fun deleteListing(listingId: String, onSuccess: () -> Unit = {}) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            adMutationFlow.update { it.copy(errorMessage = "Please sign in to delete your ad.") }
            return
        }
        val owned = uiState.value.myListings.firstOrNull { it.id == listingId }
            ?: uiState.value.allListings.firstOrNull { it.id == listingId }
        if (owned != null && owned.sellerId != currentUser.uid) {
            adMutationFlow.update { it.copy(errorMessage = "You can only delete your own advertisements.") }
            return
        }

        viewModelScope.launch {
            adMutationFlow.update {
                it.copy(deletingListingId = listingId, errorMessage = null, successMessage = null)
            }
            val result = listingsRepository.deleteListing(listingId)
            result.fold(
                onSuccess = {
                    if (postAdDraftFlow.value.editingListingId == listingId) {
                        postAdDraftFlow.update { current ->
                            PostAdDraft(draftVersion = current.draftVersion + 1)
                        }
                    }
                    adMutationFlow.update {
                        it.copy(
                            deletingListingId = null,
                            errorMessage = null,
                            successMessage = "Advertisement deleted."
                        )
                    }
                    onSuccess()
                },
                onFailure = { error ->
                    adMutationFlow.update {
                        it.copy(
                            deletingListingId = null,
                            errorMessage = toUserWriteError(error)
                        )
                    }
                }
            )
        }
    }

    fun clearAdMessages() {
        adMutationFlow.update {
            if (it.errorMessage != null || it.successMessage != null) {
                it.copy(errorMessage = null, successMessage = null)
            } else {
                it
            }
        }
    }

    private fun applyFilters(
        listings: List<ProductListing>,
        filters: MarketplaceFilters
    ): List<ProductListing> {
        val cleanQuery = filters.query.trim()
        val filtered = listings.filter { item ->
            val matchesQuery = cleanQuery.isEmpty() ||
                item.title.contains(cleanQuery, ignoreCase = true) ||
                item.description.contains(cleanQuery, ignoreCase = true) ||
                item.locality.contains(cleanQuery, ignoreCase = true) ||
                item.category.title.contains(cleanQuery, ignoreCase = true) ||
                item.district.displayName.contains(cleanQuery, ignoreCase = true)

            val matchesDistrict = filters.district == KashmirDistrict.ALL ||
                item.district == filters.district

            val matchesCategory = filters.category == null ||
                item.category == filters.category

            val matchesCondition = filters.condition == null ||
                item.condition == filters.condition

            val matchesMinPrice = filters.minPriceInr == null ||
                item.priceInr >= filters.minPriceInr

            val matchesMaxPrice = filters.maxPriceInr == null ||
                item.priceInr <= filters.maxPriceInr

            matchesQuery && matchesDistrict && matchesCategory && matchesCondition && matchesMinPrice && matchesMaxPrice
        }

        return when (filters.sortOption) {
            SortOption.NEWEST -> filtered
            SortOption.PRICE_LOW_HIGH -> filtered.sortedBy { it.priceInr }
            SortOption.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.priceInr }
        }
    }

    private fun toUserReadError(error: Throwable): String {
        val firestoreEx = error.unwrapFirestoreException()
        return when (firestoreEx?.code?.name) {
            "PERMISSION_DENIED" ->
                "Please sign in again to load marketplace listings."
            "UNAVAILABLE",
            "DEADLINE_EXCEEDED" ->
                "Network unavailable. Check your connection and tap Retry."
            else -> firestoreEx?.localizedMessage
                ?: error.message
                ?: "Unable to load listings from Firestore."
        }
    }

    private fun toUserWriteError(error: Throwable): String {
        val firestoreEx = error.unwrapFirestoreException()
        return when (firestoreEx?.code?.name) {
            "PERMISSION_DENIED" ->
                "Permission denied. You can only modify advertisements you posted."
            "NOT_FOUND" ->
                "This advertisement no longer exists."
            "UNAVAILABLE",
            "DEADLINE_EXCEEDED" ->
                "Network error while saving your advertisement. Please try again."
            else -> firestoreEx?.localizedMessage
                ?: error.message
                ?: "Unable to save advertisement changes. Please try again."
        }
    }

    private fun toUserMessageReadError(error: Throwable): String {
        val firestoreEx = error.unwrapFirestoreException()
        return when (firestoreEx?.code?.name) {
            "PERMISSION_DENIED" ->
                "Please sign in again to view your messages."
            "UNAVAILABLE",
            "DEADLINE_EXCEEDED" ->
                "Network unavailable while loading messages. Tap Retry."
            else -> firestoreEx?.localizedMessage
                ?: error.message
                ?: "Unable to load conversations from Firestore."
        }
    }

    private fun toUserMessageWriteError(error: Throwable): String {
        val firestoreEx = error.unwrapFirestoreException()
        return when (firestoreEx?.code?.name) {
            "PERMISSION_DENIED" ->
                "Unable to send message. Ensure you are signed in and part of this conversation."
            "NOT_FOUND" ->
                "This conversation or advertisement is no longer available."
            "UNAVAILABLE",
            "DEADLINE_EXCEEDED" ->
                "Network error while sending your message. Please try again."
            else -> firestoreEx?.localizedMessage
                ?: error.message
                ?: "Unable to send message right now."
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
                val appContext = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]
                val localStore: MarketplaceLocalStore = if (appContext != null) {
                    SharedPreferencesMarketplaceLocalStore(appContext)
                } else {
                    InMemoryMarketplaceLocalStore()
                }
                val auth = Firebase.auth
                val firestore = FirestoreClientProvider.getInstance()
                val userProfileRepo = FirestoreUserRepository(db = firestore, auth = auth)
                val authRepo = FirebaseAuthRepository(auth = auth, userProfileRepository = userProfileRepo)
                val listingsRepo = FirestoreListingsRepository(db = firestore, auth = auth)
                val favouritesRepo = FirestoreFavouritesRepository(db = firestore, auth = auth)
                val messagesRepo = FirestoreMessagesRepository(db = firestore, auth = auth)
                return MarketplaceViewModel(
                    authRepository = authRepo,
                    listingsRepository = listingsRepo,
                    favouritesRepository = favouritesRepo,
                    userProfileRepository = userProfileRepo,
                    messagesRepository = messagesRepo,
                    localStore = localStore
                ) as T
            }

            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return create(modelClass, CreationExtras.Empty)
            }
        }
    }
}
