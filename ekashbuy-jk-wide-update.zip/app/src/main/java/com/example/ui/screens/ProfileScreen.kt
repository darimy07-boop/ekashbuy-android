package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.model.KashmirDistrict
import com.example.ui.components.DistrictPickerBottomSheet
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.PreviewModeNoticeCard
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.AuthUiState
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    uiState: MarketplaceUiState,
    authState: AuthUiState,
    onSelectHomeDistrict: (KashmirDistrict) -> Unit,
    onOpenMyAds: () -> Unit,
    onOpenLogin: () -> Unit,
    onSignOut: () -> Unit,
    onOpenSavedFavorites: () -> Unit = onOpenMyAds,
    onUpdateProfile: ((displayName: String, mobileNumber: String, district: KashmirDistrict, locality: String, onSuccess: () -> Unit) -> Unit)? = null,
    onClearAuthMessages: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showDistrictSheet by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(authState.infoMessage, authState.errorMessage, showEditDialog) {
        if (!showEditDialog) {
            val feedback = authState.errorMessage ?: authState.infoMessage
            if (!feedback.isNullOrBlank()) {
                snackbarHostState.currentSnackbarData?.dismiss()
                snackbarHostState.showSnackbar(feedback)
                onClearAuthMessages()
            }
        }
    }

    if (showDistrictSheet) {
        DistrictPickerBottomSheet(
            selectedDistrict = uiState.selectedHomeDistrict,
            districtCounts = uiState.districtCounts,
            onSelectDistrict = onSelectHomeDistrict,
            onDismiss = { showDistrictSheet = false }
        )
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Sign Out") },
            text = {
                Text("Are you sure you want to sign out of your eKashbuy account?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        onSignOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    modifier = Modifier.testTag("logout_confirm_button")
                ) {
                    Text("Sign Out")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showLogoutConfirm = false },
                    modifier = Modifier.testTag("logout_cancel_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    val signedInUser = authState.currentUser
    if (showEditDialog && signedInUser != null && onUpdateProfile != null) {
        val initialName = authState.userProfile?.displayName?.takeIf { it.isNotBlank() }
            ?: signedInUser.displayName.orEmpty()
        val initialPhone = authState.userProfile?.mobileNumber?.takeIf { it.isNotBlank() }
            ?: signedInUser.phoneNumber.orEmpty()
        val initialDistrict = authState.userProfile?.district?.let { name ->
            KashmirDistrict.entries.firstOrNull { it.name == name && it != KashmirDistrict.ALL }
        } ?: if (uiState.selectedHomeDistrict != KashmirDistrict.ALL) {
            uiState.selectedHomeDistrict
        } else {
            KashmirDistrict.SRINAGAR
        }
        val initialLocality = authState.userProfile?.locality.orEmpty()

        var nameValue by remember(showEditDialog) {
            mutableStateOf(TextFieldValue(initialName, TextRange(initialName.length)))
        }
        var phoneValue by remember(showEditDialog) {
            mutableStateOf(TextFieldValue(initialPhone, TextRange(initialPhone.length)))
        }
        var selectedDistrict by remember(showEditDialog) {
            mutableStateOf(initialDistrict)
        }
        var localityValue by remember(showEditDialog) {
            mutableStateOf(TextFieldValue(initialLocality, TextRange(initialLocality.length)))
        }

        AlertDialog(
            onDismissRequest = {
                if (!authState.isUpdatingProfile) {
                    showEditDialog = false
                    onClearAuthMessages()
                }
            },
            title = { Text("Edit Profile") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    EkashbuyOutlinedTextField(
                        value = nameValue,
                        onValueChange = { incoming ->
                            nameValue = incoming
                            onClearAuthMessages()
                        },
                        label = "Full Name",
                        placeholder = "e.g., Aamir Lone",
                        enabled = !authState.isUpdatingProfile,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            autoCorrectEnabled = false,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_edit_name_input")
                    )

                    EkashbuyOutlinedTextField(
                        value = phoneValue,
                        onValueChange = { incoming ->
                            phoneValue = TextFieldInputSanitizers.sanitizePhone(incoming)
                            onClearAuthMessages()
                        },
                        label = "Mobile Number",
                        placeholder = "+91 9XXXXXXXXX",
                        enabled = !authState.isUpdatingProfile,
                        keyboardOptions = KeyboardOptions(
                            autoCorrectEnabled = false,
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_edit_phone_input")
                    )

                    Text("Home District", style = MaterialTheme.typography.labelLarge)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        KashmirDistrict.entries.filter { it != KashmirDistrict.ALL }.forEach { dist ->
                            FilterChip(
                                selected = selectedDistrict == dist,
                                enabled = !authState.isUpdatingProfile,
                                onClick = { selectedDistrict = dist },
                                label = { Text(dist.displayName, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("profile_edit_district_${dist.name.lowercase()}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = RoyalBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    EkashbuyOutlinedTextField(
                        value = localityValue,
                        onValueChange = { incoming ->
                            localityValue = incoming
                            onClearAuthMessages()
                        },
                        label = "Locality (Optional)",
                        placeholder = "e.g., Rajbagh, Humhama",
                        enabled = !authState.isUpdatingProfile,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            autoCorrectEnabled = false,
                            imeAction = ImeAction.Done
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_edit_locality_input")
                    )

                    authState.errorMessage?.let { err ->
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.testTag("profile_edit_error")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateProfile(
                            nameValue.text,
                            phoneValue.text,
                            selectedDistrict,
                            localityValue.text
                        ) {
                            showEditDialog = false
                        }
                    },
                    enabled = !authState.isUpdatingProfile,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    modifier = Modifier.testTag("profile_edit_save_button")
                ) {
                    if (authState.isUpdatingProfile) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text("Save Profile")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showEditDialog = false
                        onClearAuthMessages()
                    },
                    enabled = !authState.isUpdatingProfile,
                    modifier = Modifier.testTag("profile_edit_cancel_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Profile", style = MaterialTheme.typography.headlineSmall) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (signedInUser == null) {
                // Guest Account Banner
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = RoyalBlue
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.16f)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.PersonOutline,
                                    contentDescription = "Guest user",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .padding(14.dp)
                                        .size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Guest Account",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Sign in with Google to manage your eKashbuy profile",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onOpenLogin,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VibrantOrange,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("profile_login_button")
                        ) {
                            Text("Continue with Google", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                val resolvedName = authState.userProfile?.displayName?.takeIf { it.isNotBlank() }
                    ?: signedInUser.displayName?.takeIf { it.isNotBlank() }
                    ?: "eKashbuy Member"
                val contactLine = listOfNotNull(
                    authState.userProfile?.mobileNumber?.takeIf { it.isNotBlank() }
                        ?: signedInUser.phoneNumber?.takeIf { it.isNotBlank() },
                    signedInUser.email?.takeIf { it.isNotBlank() }
                ).joinToString(" • ").ifBlank { "Signed-in account" }
                val profileDistrict = authState.userProfile?.district?.let { name ->
                    KashmirDistrict.entries.firstOrNull { it.name == name }?.displayName
                } ?: uiState.selectedHomeDistrict.displayName
                val profileLocality = authState.userProfile?.locality?.takeIf { it.isNotBlank() }
                val locationSummary = if (profileLocality != null) {
                    "$profileLocality, $profileDistrict"
                } else {
                    profileDistrict
                }

                // Signed-In Account Banner
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = RoyalBlue,
                    modifier = Modifier.testTag("profile_signed_in_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.16f)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.PersonOutline,
                                    contentDescription = "Signed in user",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .padding(14.dp)
                                        .size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = resolvedName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = contactLine,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Location: $locationSummary",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (onUpdateProfile != null) {
                                Button(
                                    onClick = {
                                        onClearAuthMessages()
                                        showEditDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = VibrantOrange,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("profile_edit_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Edit,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Edit Profile", fontWeight = FontWeight.SemiBold)
                                }
                            }
                            OutlinedButton(
                                onClick = { showLogoutConfirm = true },
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("profile_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = "Sign Out",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sign Out", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Quick Actions List
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column {
                    ProfileMenuRow(
                        icon = Icons.Outlined.Inventory2,
                        title = "My Ads",
                        subtitle = "Manage your ordinary ads & saved items",
                        onClick = onOpenMyAds,
                        testTag = "profile_my_ads_row"
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    ProfileMenuRow(
                        icon = Icons.Outlined.FavoriteBorder,
                        title = "Saved Favorites",
                        subtitle = "${uiState.favoriteIds.size} saved listings",
                        onClick = onOpenSavedFavorites,
                        testTag = "profile_favorites_row"
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    ProfileMenuRow(
                        icon = Icons.Outlined.LocationOn,
                        title = "Preferred District",
                        subtitle = uiState.selectedHomeDistrict.displayName,
                        onClick = { showDistrictSheet = true },
                        testTag = "profile_district_row"
                    )
                }
            }

            // Business Principles Card
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = EmeraldContainer,
                border = BorderStroke(1.dp, EmeraldBadge.copy(alpha = 0.25f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "How eKashbuy Works",
                        style = MaterialTheme.typography.titleSmall,
                        color = EmeraldBadge,
                        fontWeight = FontWeight.Bold
                    )
                    RuleBullet("Ordinary advertisements are always free")
                    RuleBullet("0% commission on every sale")
                    RuleBullet("Buyers contact sellers directly by phone or chat")
                    RuleBullet("No online payments — inspect locally before paying")
                    RuleBullet("Featured advertisements will be an optional future paid feature")
                }
            }

            // Firebase Auth Status Card
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.CloudDone,
                            contentDescription = null,
                            tint = RoyalBlue
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Firebase Authentication Active",
                            style = MaterialTheme.typography.titleSmall,
                            color = RoyalBlue
                        )
                    }
                    Text(
                        text = "Google Sign-In is connected via Firebase Auth, with your account profile stored securely in Cloud Firestore.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            PreviewModeNoticeCard(
                title = "No Fake Verification or Ratings",
                message = "eKashbuy never displays fabricated seller ratings or fake verification badges."
            )
        }
    }
}

@Composable
private fun ProfileMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = RoyalBlueContainer
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = RoyalBlue,
                modifier = Modifier
                    .padding(9.dp)
                    .size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun RuleBullet(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Outlined.Payments,
            contentDescription = null,
            tint = EmeraldBadge,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
