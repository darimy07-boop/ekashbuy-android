package com.example.data.auth

import android.util.Log
import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreUser
import com.example.model.KashmirDistrict
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class AuthUser(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val phoneNumber: String?,
    val providerIds: List<String> = emptyList()
)

object AuthValidation {
    private val E164_REGEX = Regex("^\\+[1-9]\\d{7,14}$")
    private val INDIAN_10_DIGIT_REGEX = Regex("^[6-9]\\d{9}$")

    fun validateFullName(name: String): String? {
        val trimmed = name.trim()
        return when {
            trimmed.length < 2 -> "Please enter your full name (at least 2 characters)."
            trimmed.length > 60 -> "Full name must be 60 characters or fewer."
            else -> null
        }
    }

    /**
     * Normalizes Indian mobile numbers and E.164 phone numbers to E.164 format.
     * Examples:
     * - "9876543210" -> "+919876543210"
     * - "09876543210" -> "+919876543210"
     * - "919876543210" -> "+919876543210"
     * - "+91 98765-43210" -> "+919876543210"
     */
    fun normalizePhoneToE164(raw: String): String? {
        val cleaned = raw.trim()
            .replace(" ", "")
            .replace("-", "")
            .replace("(", "")
            .replace(")", "")

        if (cleaned.isEmpty()) return null

        if (cleaned.startsWith("+")) {
            return if (E164_REGEX.matches(cleaned)) cleaned else null
        }

        if (!cleaned.all { it.isDigit() }) return null

        return when {
            INDIAN_10_DIGIT_REGEX.matches(cleaned) -> "+91$cleaned"
            cleaned.length == 11 && cleaned.startsWith("0") &&
                INDIAN_10_DIGIT_REGEX.matches(cleaned.drop(1)) -> "+91${cleaned.drop(1)}"
            cleaned.length == 12 && cleaned.startsWith("91") &&
                INDIAN_10_DIGIT_REGEX.matches(cleaned.drop(2)) -> "+$cleaned"
            else -> null
        }
    }
}

object AuthErrorMapper {
    fun toUserMessage(error: Throwable): String {
        if (error is FirebaseNetworkException) {
            return "Network error. Please check your internet connection and try again."
        }
        if (error is FirebaseTooManyRequestsException) {
            return "Too many attempts right now. Please wait a few minutes before trying again."
        }
        if (error is FirebaseAuthUserCollisionException) {
            return "This email is already linked to another sign-in method."
        }
        if (error is FirebaseAuthInvalidUserException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseAuthInvalidCredentialsException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseAuthException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseException) {
            return mapRawMessage(error.message)
        }
        return mapRawMessage(error.message)
    }

    fun mapAuthCode(errorCode: String, rawMessage: String? = null): String {
        return when (errorCode) {
            "ERROR_INVALID_CREDENTIAL" ->
                "Google Sign-In credentials could not be verified. Please try again."
            "ERROR_USER_DISABLED" -> "This account has been disabled. Please contact support."
            "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" ->
                "An account already exists with this email address using a different sign-in method."
            "ERROR_TOO_MANY_REQUESTS" ->
                "Too many sign-in attempts right now. Please wait a bit and try again."
            "ERROR_OPERATION_NOT_ALLOWED" ->
                "Google Sign-In is not enabled in Firebase Console yet."
            "ERROR_APP_NOT_AUTHORIZED", "ERROR_INVALID_APP_CREDENTIAL" ->
                "Google Sign-In setup issue: confirm SHA-1/SHA-256 and Google Sign-In are enabled in Firebase Console."
            else -> mapRawMessage(rawMessage)
        }
    }

    private fun mapRawMessage(rawMessage: String?): String {
        val msg = rawMessage?.trim().orEmpty()
        if (msg.isEmpty()) return "Google Sign-In failed. Please try again."
        val lower = msg.lowercase()
        return when {
            "network" in lower || "unable to resolve host" in lower ->
                "Network error. Please check your internet connection and try again."
            "too many" in lower || "blocked all requests" in lower ->
                "Too many attempts right now. Please try again shortly."
            "operation_not_allowed" in lower || "not enabled" in lower ->
                "Google Sign-In is not enabled in Firebase Console yet."
            else -> msg
        }
    }
}

interface AuthRepository {
    fun observeAuthState(): Flow<AuthUser?>
    fun currentUser(): AuthUser?
    suspend fun signInWithGoogleIdToken(idToken: String): Result<AuthUser>
    fun signOut()
}

class FirebaseAuthRepository(
    private val auth: FirebaseAuth,
    private val userProfileRepository: UserProfileRepository? = null
) : AuthRepository {

    override fun observeAuthState(): Flow<AuthUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser?.toDomainUser())
        }
        auth.addAuthStateListener(listener)
        trySend(auth.currentUser?.toDomainUser())
        awaitClose {
            auth.removeAuthStateListener(listener)
        }
    }

    override fun currentUser(): AuthUser? = auth.currentUser?.toDomainUser()

    override suspend fun signInWithGoogleIdToken(idToken: String): Result<AuthUser> {
        val cleanToken = idToken.trim()
        if (cleanToken.isEmpty()) {
            return Result.failure(IllegalArgumentException("Google ID token was empty."))
        }

        return try {
            val credential = GoogleAuthProvider.getCredential(cleanToken, null)
            val result = auth.signInWithCredential(credential).await()
            val firebaseUser = result.user
                ?: return Result.failure(IllegalStateException("Signed-in user was not returned by Firebase."))

            syncExistingProfileMetadataIfNeeded(firebaseUser)
            Result.success(firebaseUser.toDomainUser())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Google sign-in failed", e)
            Result.failure(IllegalStateException(AuthErrorMapper.toUserMessage(e), e))
        }
    }

    override fun signOut() {
        auth.signOut()
    }

    private suspend fun syncExistingProfileMetadataIfNeeded(firebaseUser: FirebaseUser) {
        val repo = userProfileRepository ?: return
        val phone = firebaseUser.phoneNumber?.trim()?.takeIf { it.length in 7..20 } ?: return
        val existing = repo.getUserProfile(firebaseUser.uid).getOrNull()
        if (existing != null) return

        val safeName = firebaseUser.displayName?.trim()?.takeIf { it.length >= 2 }?.take(60)
            ?: "eKashbuy Member"
        try {
            repo.saveUserProfile(
                FirestoreUser(
                    id = firebaseUser.uid,
                    userId = firebaseUser.uid,
                    displayName = safeName,
                    mobileNumber = phone,
                    district = KashmirDistrict.SRINAGAR.name,
                    locality = "",
                    avatarUrl = firebaseUser.photoUrl?.toString()?.take(500)
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Best-effort Firestore user profile sync failed", e)
        }
    }

    private fun FirebaseUser.toDomainUser(): AuthUser {
        return AuthUser(
            uid = uid,
            displayName = displayName,
            email = email,
            phoneNumber = phoneNumber,
            providerIds = providerData.map { it.providerId }.filter { it != "firebase" }
        )
    }

    private companion object {
        const val TAG = "FirebaseAuthRepository"
    }
}
