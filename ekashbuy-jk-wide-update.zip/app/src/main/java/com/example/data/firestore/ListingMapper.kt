package com.example.data.firestore

import com.example.data.firestore.model.FirestoreAdTier
import com.example.data.firestore.model.FirestoreConversation
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.model.FirestoreMessageEntry
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.AdTier
import com.example.model.ChatMessagePreview
import com.example.model.ConversationPreview
import com.example.model.KashmirDistrict
import com.example.model.ProductListing
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ListingValidationResult {
    data class Valid(val listing: FirestoreListing) : ListingValidationResult()
    data class Invalid(val message: String) : ListingValidationResult()
}

object ListingValidation {
    const val MAX_PRICE_INR = 500_000_000L

    fun validateAndBuild(
        editingListingId: String?,
        sellerId: String,
        title: String,
        priceText: String,
        isMonthlyRent: Boolean,
        negotiable: Boolean,
        category: AdCategory,
        district: KashmirDistrict,
        locality: String,
        condition: AdCondition,
        description: String,
        sellerName: String,
        sellerPhone: String,
        existingSpecs: Map<String, String> = emptyMap(),
        existingImageUrls: List<String> = emptyList()
    ): ListingValidationResult {
        val cleanTitle = title.trim()
        if (cleanTitle.length !in 3..120) {
            return ListingValidationResult.Invalid(
                "Ad title must be between 3 and 120 characters."
            )
        }

        val normalizedPriceInput = priceText.trim().replace(",", "").replace(" ", "")
        val isAllDigits = normalizedPriceInput.isNotEmpty() && normalizedPriceInput.all { it.isDigit() }
        val parsedPrice = if (isAllDigits) normalizedPriceInput.toLongOrNull() else null
        if (parsedPrice == null || parsedPrice < 0L || parsedPrice > MAX_PRICE_INR) {
            return ListingValidationResult.Invalid(
                "Please enter a valid price between ₹0 and ₹50,00,00,000."
            )
        }

        if (district == KashmirDistrict.ALL) {
            return ListingValidationResult.Invalid(
                "Please select one of the 20 Jammu & Jammu & Kashmir districts."
            )
        }

        val cleanLocality = locality.trim()
        if (cleanLocality.length !in 2..80) {
            return ListingValidationResult.Invalid(
                "Locality / area must be between 2 and 80 characters."
            )
        }

        val cleanDescription = description.trim()
        if (cleanDescription.length !in 10..2000) {
            return ListingValidationResult.Invalid(
                "Description must be between 10 and 2000 characters."
            )
        }

        val cleanSellerName = sellerName.trim()
        if (cleanSellerName.length !in 2..60) {
            return ListingValidationResult.Invalid(
                "Seller name must be between 2 and 60 characters."
            )
        }

        val cleanSellerPhone = sellerPhone.trim()
        val phoneDigitCount = cleanSellerPhone.count { it.isDigit() }
        if (cleanSellerPhone.length !in 7..20 || phoneDigitCount < 7) {
            return ListingValidationResult.Invalid(
                "Please enter a valid contact phone number (7–20 characters)."
            )
        }

        val firestoreListing = FirestoreListing(
            id = editingListingId.orEmpty(),
            sellerId = sellerId,
            sellerName = cleanSellerName,
            sellerPhone = cleanSellerPhone,
            title = cleanTitle,
            description = cleanDescription,
            priceInr = parsedPrice,
            isMonthlyRent = isMonthlyRent,
            negotiable = negotiable,
            category = category.name,
            district = district.name,
            locality = cleanLocality,
            condition = condition.name,
            imageUrls = existingImageUrls.take(6),
            specs = existingSpecs.entries.take(12).associate { it.key to it.value },
            adTier = FirestoreAdTier.ORDINARY_FREE.name,
            status = FirestoreListingStatus.ACTIVE.name
        )
        return ListingValidationResult.Valid(firestoreListing)
    }
}

fun FirestoreListing.toProductListing(nowMillis: Long = System.currentTimeMillis()): ProductListing {
    val parsedCategory = AdCategory.entries.firstOrNull { it.name == category } ?: AdCategory.SERVICES
    val parsedDistrict = KashmirDistrict.entries.firstOrNull {
        it.name == district && it != KashmirDistrict.ALL
    } ?: KashmirDistrict.SRINAGAR
    val parsedCondition = AdCondition.entries.firstOrNull { it.name == condition } ?: AdCondition.GOOD
    val createdMillis = createdAt?.toDate()?.time ?: 0L

    return ProductListing(
        id = id,
        title = title,
        priceInr = priceInr.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(),
        isMonthlyRent = isMonthlyRent,
        negotiable = negotiable,
        category = parsedCategory,
        district = parsedDistrict,
        locality = locality,
        description = description,
        condition = parsedCondition,
        postedAgo = formatRelativeTimestamp(createdAt, nowMillis),
        sellerName = sellerName,
        sellerPhone = sellerPhone,
        sellerId = sellerId,
        status = status,
        createdAtMillis = createdMillis,
        imageUrls = imageUrls,
        imageResId = null,
        specs = specs,
        adTier = AdTier.ORDINARY_FREE
    )
}

fun ProductListing.toFirestoreListingSnapshot(): FirestoreListing {
    return FirestoreListing(
        id = id,
        sellerId = sellerId,
        sellerName = sellerName,
        sellerPhone = sellerPhone,
        title = title,
        description = description,
        priceInr = priceInr.toLong().coerceAtLeast(0L),
        isMonthlyRent = isMonthlyRent,
        negotiable = negotiable,
        category = category.name,
        district = if (district == KashmirDistrict.ALL) KashmirDistrict.SRINAGAR.name else district.name,
        locality = locality,
        condition = condition.name,
        imageUrls = imageUrls,
        specs = specs,
        adTier = FirestoreAdTier.ORDINARY_FREE.name,
        status = status
    )
}

fun FirestoreConversation.toConversationPreview(
    currentUserId: String,
    nowMillis: Long = System.currentTimeMillis()
): ConversationPreview {
    val isBuying = buyerId == currentUserId
    val otherName = if (isBuying) {
        sellerName.ifBlank { "Seller" }
    } else {
        buyerName.ifBlank { "Buyer" }
    }
    val parsedDistrict = KashmirDistrict.entries.firstOrNull {
        it.name == district && it != KashmirDistrict.ALL
    } ?: KashmirDistrict.SRINAGAR

    val lastTimestampMillis = (lastMessageAt ?: createdAt)?.toDate()?.time ?: 0L

    return ConversationPreview(
        id = id,
        participantName = otherName,
        district = parsedDistrict,
        productId = listingId,
        productTitle = listingTitle,
        productPriceInr = listingPriceInr.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(),
        lastMessage = lastMessageText.ifBlank { "Tap to open conversation" },
        timestamp = formatRelativeTimestamp(lastMessageAt ?: createdAt, nowMillis),
        isBuyingInquiry = isBuying,
        unreadCount = 0,
        messages = emptyList(),
        lastSenderId = lastSenderId,
        lastMessageAtMillis = lastTimestampMillis
    )
}

fun FirestoreMessageEntry.toChatMessagePreview(
    currentUserId: String,
    buyerId: String,
    nowMillis: Long = System.currentTimeMillis()
): ChatMessagePreview {
    return ChatMessagePreview(
        id = id,
        senderName = if (senderId == currentUserId) "You" else senderName.ifBlank { "Participant" },
        text = text,
        timeLabel = formatRelativeTimestamp(createdAt, nowMillis),
        isFromBuyer = senderId == buyerId,
        isFromCurrentUser = senderId == currentUserId
    )
}

fun formatRelativeTimestamp(timestamp: Timestamp?, nowMillis: Long = System.currentTimeMillis()): String {
    val millis = timestamp?.toDate()?.time ?: return "Just now"
    val diff = (nowMillis - millis).coerceAtLeast(0L)
    val minuteMs = 60_000L
    val hourMs = 60 * minuteMs
    val dayMs = 24 * hourMs

    return when {
        diff < minuteMs -> "Just now"
        diff < hourMs -> "${diff / minuteMs}m ago"
        diff < dayMs -> "${diff / hourMs}h ago"
        diff < 2 * dayMs -> "Yesterday"
        diff < 7 * dayMs -> "${diff / dayMs}d ago"
        else -> SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date(millis))
    }
}
