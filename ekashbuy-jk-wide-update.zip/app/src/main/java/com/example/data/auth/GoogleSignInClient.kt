package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val AUTH_LOG_TAG = "Auth"

internal tailrec fun Context.findHostActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findHostActivity()
    else -> null
}

/**
 * Attempts silent single-tap Google Sign-In on startup using previously authorized accounts.
 * Uses a single GetGoogleIdOption per GetCredentialRequest so the Credential Manager sheet
 * stays responsive across Android API levels.
 */
fun attemptAutoGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager = CredentialManager.create(context),
    scope: CoroutineScope,
    onTokenReceived: (String) -> Unit,
    onUnauthenticated: () -> Unit = {}
) {
    if (Firebase.auth.currentUser != null) return

    val clientId = try {
        context.getString(R.string.default_web_client_id).takeIf { it.isNotBlank() }
    } catch (_: Exception) {
        null
    }
    if (clientId == null) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val credentialHost = context.findHostActivity() ?: context
            val credential = credentialManager.getCredential(credentialHost, request).credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                if (idToken.isNotBlank()) {
                    onTokenReceived(idToken)
                } else {
                    onUnauthenticated()
                }
            } else {
                onUnauthenticated()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

/**
 * Launches interactive Google Sign-In via Jetpack Credential Manager using GetSignInWithGoogleOption.
 */
fun launchInteractiveGoogleSignIn(
    context: Context,
    credentialManager: CredentialManager = CredentialManager.create(context),
    scope: CoroutineScope,
    onTokenReceived: (String) -> Unit,
    onCancelled: () -> Unit,
    onError: (String) -> Unit
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id).takeIf { it.isNotBlank() }
    } catch (_: Exception) {
        null
    }
    if (clientId == null) {
        onError("Google Sign-In configuration is missing. Please rebuild with google-services.json.")
        return
    }

    val activity = context.findHostActivity()
    if (activity == null) {
        onError("Unable to launch Google Sign-In from this screen. Please try again.")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val credential = credentialManager.getCredential(activity, request).credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                if (idToken.isNotBlank()) {
                    onTokenReceived(idToken)
                } else {
                    onError("Google Sign-In did not return a valid ID token.")
                }
            } else {
                onError("Unexpected credential returned by Google Sign-In.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(AUTH_LOG_TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onCancelled()
        } catch (e: NoCredentialException) {
            Log.w(AUTH_LOG_TAG, "No Google credential available: ${e.message}", e)
            onError("No Google account is available on this device. Please add a Google account in device Settings and try again.")
        } catch (e: GetCredentialException) {
            Log.e(AUTH_LOG_TAG, "Google Sign-In failed: ${e.type}", e)
            onError(e.errorMessage?.toString()?.takeIf { it.isNotBlank() } ?: "Google Sign-In failed. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(AUTH_LOG_TAG, "Google Sign-In failed", e)
            onError(e.localizedMessage ?: "Google Sign-In failed. Please try again.")
        }
    }
}

/**
 * Clears active Credential Manager state cleanly inside NonCancellable before signing out.
 */
suspend fun clearGoogleCredentialState(context: Context) {
    withContext(NonCancellable) {
        try {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.w(AUTH_LOG_TAG, "Failed to clear credential state: ${e.message}")
        }
    }
}
