const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const ts = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_srinagar";
const BOB_UID = "bob_anantnag";
const CHARLIE_UID = "charlie_baramulla";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validListingPayload(sellerId) {
  return {
    sellerId,
    sellerName: "Aamir Lone",
    sellerPhone: "+919419000112",
    title: "Maruti Swift VXi 2021",
    description: "Clean single-owner car in Rajbagh, Srinagar with service record.",
    priceInr: 545000,
    isMonthlyRent: false,
    negotiable: true,
    category: "VEHICLES",
    district: "SRINAGAR",
    locality: "Rajbagh",
    condition: "LIKE_NEW",
    imageUrls: [],
    specs: { Year: "2021", Fuel: "Petrol" },
    adTier: "ORDINARY_FREE",
    status: "ACTIVE",
    createdAt: ts(),
    updatedAt: ts(),
  };
}

// --- 1. Unauthenticated Rejections ---
test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("listings").where("status", "==", "ACTIVE").get());
  await assertFails(unauthDb.collection("messages").get());
  await assertFails(unauthDb.collection("favourites").get());
  await assertFails(unauthDb.collection("notifications").get());
  await assertFails(unauthDb.collection("listings").doc("ad1").set(validListingPayload(ALICE_UID)));
});

// --- 2. Users Collection (Owner-isolated PII) ---
test("User can create and read own profile; cannot read another user's profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Bhat",
      mobileNumber: "+919419000111",
      district: "SRINAGAR",
      locality: "Rajbagh",
      createdAt: ts(),
      updatedAt: ts(),
    })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
});

test("User profile rejects ghost/fake verification fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Bhat",
      mobileNumber: "+919419000111",
      district: "SRINAGAR",
      locality: "Rajbagh",
      isVerified: true,
      createdAt: ts(),
      updatedAt: ts(),
    })
  );
});

// --- 3. Listings Collection ---
test("Seller can create ordinary free listing; another user cannot edit or delete it", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").set(validListingPayload(ALICE_UID))
  );

  // Buyer Bob can query ACTIVE listings
  await assertSucceeds(
    bobDb.collection("listings").where("status", "==", "ACTIVE").get()
  );

  // Unfiltered listings query fails (rules are not filters)
  await assertFails(bobDb.collection("listings").get());

  // Bob cannot modify or delete Alice's listing
  await assertFails(
    bobDb.collection("listings").doc("listing_1").update({ priceInr: 100, updatedAt: ts() })
  );
  await assertFails(bobDb.collection("listings").doc("listing_1").delete());

  // Alice cannot forge a paid featured tier
  const badTier = validListingPayload(ALICE_UID);
  badTier.adTier = "FEATURED_PAID";
  await assertFails(aliceDb.collection("listings").doc("listing_2").set(badTier));

  // Alice can edit her own listing fields and change status
  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").update({
      title: "Maruti Swift VXi 2021 Updated",
      priceInr: 525000,
      locality: "Jawahar Nagar",
      updatedAt: ts(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").update({
      status: "PAUSED",
      updatedAt: ts(),
    })
  );

  // Alice cannot transfer sellerId or change adTier during edit
  await assertFails(
    aliceDb.collection("listings").doc("listing_1").update({
      sellerId: BOB_UID,
      updatedAt: ts(),
    })
  );
  await assertFails(
    aliceDb.collection("listings").doc("listing_1").update({
      adTier: "FEATURED_PAID",
      updatedAt: ts(),
    })
  );

  // Alice cannot edit after archiving
  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").update({
      status: "ARCHIVED",
      updatedAt: ts(),
    })
  );
  await assertFails(
    aliceDb.collection("listings").doc("listing_1").update({
      priceInr: 510000,
      updatedAt: ts(),
    })
  );

  // Alice can delete her own listing
  await assertSucceeds(aliceDb.collection("listings").doc("listing_1").delete());
});

// --- 4. Messages Collection (Listing-related conversations) ---
test("Only buyer and seller can read/write listing conversation and entries", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").set(validListingPayload(ALICE_UID))
  );

  const convId = `listing_1_${BOB_UID}`;
  await assertSucceeds(
    bobDb.collection("messages").doc(convId).set({
      listingId: "listing_1",
      listingTitle: "Maruti Swift VXi 2021",
      listingPriceInr: 545000,
      district: "SRINAGAR",
      buyerId: BOB_UID,
      sellerId: ALICE_UID,
      participantIds: [BOB_UID, ALICE_UID],
      buyerName: "Bob Wani",
      sellerName: "Aamir Lone",
      lastMessageText: "Is this available?",
      lastSenderId: BOB_UID,
      lastMessageAt: ts(),
      createdAt: ts(),
    })
  );

  await assertSucceeds(
    bobDb.collection("messages").doc(convId).collection("entries").doc("msg_1").set({
      conversationId: convId,
      listingId: "listing_1",
      senderId: BOB_UID,
      senderName: "Bob Wani",
      participantIds: [BOB_UID, ALICE_UID],
      text: "Is this available?",
      createdAt: ts(),
    })
  );

  // Seller Alice can read and reply
  await assertSucceeds(aliceDb.collection("messages").doc(convId).get());
  await assertSucceeds(
    aliceDb
      .collection("messages")
      .doc(convId)
      .collection("entries")
      .where("participantIds", "array-contains", ALICE_UID)
      .get()
  );

  // Outsider Charlie cannot read or send messages
  await assertFails(charlieDb.collection("messages").doc(convId).get());
  await assertFails(
    charlieDb.collection("messages").doc(convId).collection("entries").doc("msg_2").set({
      conversationId: convId,
      listingId: "listing_1",
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      participantIds: [BOB_UID, ALICE_UID],
      text: "Unauthorized",
      createdAt: ts(),
    })
  );
});

// --- 5. Favourites & Notifications Collections ---
test("Favourites and notifications are strictly owner-isolated", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("listings").doc("listing_1").set(validListingPayload(ALICE_UID))
  );

  const favId = `${BOB_UID}_listing_1`;
  await assertSucceeds(
    bobDb.collection("favourites").doc(favId).set({
      userId: BOB_UID,
      listingId: "listing_1",
      listingTitle: "Maruti Swift VXi 2021",
      priceInr: 545000,
      district: "SRINAGAR",
      createdAt: ts(),
    })
  );
  await assertFails(aliceDb.collection("favourites").doc(favId).get());

  await assertSucceeds(
    bobDb.collection("notifications").doc("notif_1").set({
      userId: BOB_UID,
      type: "NEW_MESSAGE",
      title: "New inquiry",
      body: "Seller replied to your message",
      listingId: "listing_1",
      isRead: false,
      createdAt: ts(),
    })
  );
  await assertFails(aliceDb.collection("notifications").doc("notif_1").get());
  await assertSucceeds(bobDb.collection("notifications").doc("notif_1").update({ isRead: true }));
});
