package com.example.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performKeyInput
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.example.model.KashmirDistrict
import com.example.ui.components.EkashbuySearchBar
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.AuthUiState
import com.example.ui.theme.EkashbuyTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthScreensInputTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun loginScreen_typingEmailPasswordAndPhone_doesNotDuplicateCharacters() {
        var authState by mutableStateOf(
            AuthUiState(errorMessage = "Previous error to clear on edit")
        )
        var submittedEmail: String? = null
        var submittedPassword: String? = null
        var submittedPhone: String? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                LoginScreen(
                    authState = authState,
                    onSignInWithEmail = { email, password ->
                        submittedEmail = email
                        submittedPassword = password
                    },
                    onRequestPhoneOtp = { _, phone, _ ->
                        submittedPhone = phone
                    },
                    onVerifyOtp = {},
                    onResetOtpFlow = {},
                    onClearMessages = {
                        authState = authState.copy(errorMessage = null, infoMessage = null)
                    },
                    onNavigateBack = {},
                    onNavigateToRegister = {},
                    onAuthSuccess = {}
                )
            }
        }

        // Test phone field character-by-character typing while error banner clears
        val phoneNode = composeTestRule.onNodeWithTag("login_phone_input")
        phoneNode.performClick()
        "9876543210".forEach { ch ->
            phoneNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()

        assertNull(authState.errorMessage)
        phoneNode.assertTextContains("9876543210")

        composeTestRule.onNodeWithTag("login_send_otp_button").performClick()
        composeTestRule.waitForIdle()
        assertEquals("9876543210", submittedPhone)

        // Switch to Email & Password tab and re-seed an error to test clearing during typing
        authState = AuthUiState(errorMessage = "Invalid email")
        composeTestRule.onNodeWithTag("auth_tab_email_password").performClick()
        composeTestRule.waitForIdle()

        val emailNode = composeTestRule.onNodeWithTag("login_email_input")
        emailNode.performScrollTo()
        emailNode.performClick()
        "a1b@kashmir.in".forEach { ch ->
            emailNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()

        assertNull(authState.errorMessage)
        emailNode.assertTextContains("a1b@kashmir.in")

        val passwordNode = composeTestRule.onNodeWithTag("login_password_input")
        passwordNode.performScrollTo()
        passwordNode.performClick()
        "Pass12".forEach { ch ->
            passwordNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()

        val submitButton = composeTestRule.onNodeWithTag("login_submit_button")
        submitButton.performScrollTo()
        submitButton.performClick()
        composeTestRule.waitForIdle()

        assertEquals("a1b@kashmir.in", submittedEmail)
        assertEquals("Pass12", submittedPassword)
    }

    @Test
    fun registrationScreen_typingNamePhoneEmailPassword_doesNotDuplicateCharacters() {
        var authState by mutableStateOf(
            AuthUiState(errorMessage = "Please check your details.")
        )
        var regName: String? = null
        var regEmail: String? = null
        var regPhone: String? = null
        var regPassword: String? = null
        var regDistrict: KashmirDistrict? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                RegistrationScreen(
                    authState = authState,
                    onRegisterWithEmail = { name, email, phone, district, password ->
                        regName = name
                        regEmail = email
                        regPhone = phone
                        regDistrict = district
                        regPassword = password
                    },
                    onRequestPhoneOtp = { _, _, _, _, _ -> },
                    onVerifyOtpWithProfile = { _, _, _ -> },
                    onResetOtpFlow = {},
                    onClearMessages = {
                        authState = authState.copy(errorMessage = null, infoMessage = null)
                    },
                    onNavigateBack = {},
                    onNavigateToLogin = {},
                    onAuthSuccess = {}
                )
            }
        }

        val nameNode = composeTestRule.onNodeWithTag("register_name_input")
        nameNode.performClick()
        "Zoya".forEach { ch -> nameNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        assertNull(authState.errorMessage)
        nameNode.assertTextContains("Zoya")

        val phoneNode = composeTestRule.onNodeWithTag("register_phone_input")
        phoneNode.performClick()
        "9419012345".forEach { ch -> phoneNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        phoneNode.assertTextContains("9419012345")

        val emailNode = composeTestRule.onNodeWithTag("register_email_input")
        emailNode.performScrollTo()
        emailNode.performClick()
        "zoya07@ekashbuy.in".forEach { ch -> emailNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()
        emailNode.assertTextContains("zoya07@ekashbuy.in")

        val passwordNode = composeTestRule.onNodeWithTag("register_password_input")
        passwordNode.performScrollTo()
        passwordNode.performClick()
        "Kashmir9".forEach { ch -> passwordNode.performTextInput(ch.toString()) }
        composeTestRule.waitForIdle()

        val submitButton = composeTestRule.onNodeWithTag("register_submit_button")
        submitButton.performScrollTo()
        submitButton.performClick()
        composeTestRule.waitForIdle()

        assertEquals("Zoya", regName)
        assertEquals("9419012345", regPhone)
        assertEquals("zoya07@ekashbuy.in", regEmail)
        assertEquals("Kashmir9", regPassword)
        assertEquals(KashmirDistrict.SRINAGAR, regDistrict)
    }

    @Test
    fun authScreens_doNotNavigateBeforeProfileSyncCompletes() {
        val sampleUser = com.example.data.auth.AuthUser(
            uid = "uid_sync_1",
            displayName = "Sana Mir",
            email = null,
            phoneNumber = "+919876543210"
        )
        var loginState by mutableStateOf(
            AuthUiState(currentUser = sampleUser, isLoading = false, isSyncingProfile = true)
        )
        var loginSuccessCount = 0

        composeTestRule.setContent {
            EkashbuyTheme {
                LoginScreen(
                    authState = loginState,
                    onSignInWithEmail = { _, _ -> },
                    onRequestPhoneOtp = { _, _, _ -> },
                    onVerifyOtp = {},
                    onResetOtpFlow = {},
                    onClearMessages = {},
                    onNavigateBack = {},
                    onNavigateToRegister = {},
                    onAuthSuccess = { loginSuccessCount++ }
                )
            }
        }

        composeTestRule.waitForIdle()
        assertEquals(0, loginSuccessCount)

        loginState = loginState.copy(isSyncingProfile = false)
        composeTestRule.waitForIdle()
        assertEquals(1, loginSuccessCount)
    }

    @OptIn(ExperimentalTestApi::class)
    @Test
    fun registrationScreen_hardwareKeyEvents_andBackspace_enterSingleCharacterPerKeypress() {
        val authState by mutableStateOf(AuthUiState())

        composeTestRule.setContent {
            EkashbuyTheme {
                RegistrationScreen(
                    authState = authState,
                    onRegisterWithEmail = { _, _, _, _, _ -> },
                    onRequestPhoneOtp = { _, _, _, _, _ -> },
                    onVerifyOtpWithProfile = { _, _, _ -> },
                    onResetOtpFlow = {},
                    onClearMessages = {},
                    onNavigateBack = {},
                    onNavigateToLogin = {},
                    onAuthSuccess = {}
                )
            }
        }

        // Name: each keypress adds 1 char, backspace removes 1 char
        val nameNode = composeTestRule.onNodeWithTag("register_name_input")
        nameNode.performClick()
        composeTestRule.waitForIdle()
        nameNode.performKeyInput {
            keyDown(Key.A)
            keyUp(Key.A)
            keyDown(Key.B)
            keyUp(Key.B)
            keyDown(Key.Backspace)
            keyUp(Key.Backspace)
        }
        composeTestRule.waitForIdle()
        nameNode.assertTextContains("a")

        // Phone: rejects letters, accepts numeric digits once per keypress, backspace removes 1 digit
        val phoneNode = composeTestRule.onNodeWithTag("register_phone_input")
        phoneNode.performClick()
        composeTestRule.waitForIdle()
        phoneNode.performKeyInput {
            keyDown(Key.Nine)
            keyUp(Key.Nine)
            keyDown(Key.A)
            keyUp(Key.A)
            keyDown(Key.Eight)
            keyUp(Key.Eight)
            keyDown(Key.Seven)
            keyUp(Key.Seven)
            keyDown(Key.Backspace)
            keyUp(Key.Backspace)
        }
        composeTestRule.waitForIdle()
        phoneNode.assertTextContains("98")
    }

    @OptIn(ExperimentalTestApi::class)
    @Test
    fun loginScreen_otpField_acceptsOnlySixDigits_andSupportsSingleBackspace() {
        val authState by mutableStateOf(
            AuthUiState(otpCodeSent = true, otpPhoneDisplay = "+919876543210")
        )
        var verifiedOtp: String? = null

        composeTestRule.setContent {
            EkashbuyTheme {
                LoginScreen(
                    authState = authState,
                    onSignInWithEmail = { _, _ -> },
                    onRequestPhoneOtp = { _, _, _ -> },
                    onVerifyOtp = { otp -> verifiedOtp = otp },
                    onResetOtpFlow = {},
                    onClearMessages = {},
                    onNavigateBack = {},
                    onNavigateToRegister = {},
                    onAuthSuccess = {}
                )
            }
        }

        val otpNode = composeTestRule.onNodeWithTag("login_otp_input")
        otpNode.performClick()
        "12a34#5678".forEach { ch ->
            otpNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()
        otpNode.assertTextContains("123456")

        otpNode.performKeyInput {
            keyDown(Key.Backspace)
            keyUp(Key.Backspace)
            keyDown(Key.Nine)
            keyUp(Key.Nine)
        }
        composeTestRule.waitForIdle()
        otpNode.assertTextContains("123459")

        composeTestRule.onNodeWithTag("login_verify_otp_button")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals("123459", verifiedOtp)
    }

    @Test
    fun searchBar_typingRapidlyDoesNotDuplicateOrDropCharacters() {
        var query by mutableStateOf("")

        composeTestRule.setContent {
            EkashbuyTheme {
                EkashbuySearchBar(
                    query = query,
                    onQueryChange = { query = it },
                    onSearchSubmit = {},
                    testTag = "test_search_input"
                )
            }
        }

        val searchNode = composeTestRule.onNodeWithTag("test_search_input")
        searchNode.performClick()
        "saffron".forEach { ch ->
            searchNode.performTextInput(ch.toString())
        }
        composeTestRule.waitForIdle()
        searchNode.assertTextContains("saffron")
        assertEquals("saffron", query)
    }

    @Test
    fun inputSanitizers_filterInvalidCharsAndPreserveCursor() {
        val otp = TextFieldInputSanitizers.sanitizeDigits(
            TextFieldValue("12a34567", TextRange(8)),
            maxLength = 6
        )
        assertEquals("123456", otp.text)
        assertEquals(TextRange(6), otp.selection)

        val phone = TextFieldInputSanitizers.sanitizePhone(
            TextFieldValue("+91a 987-65+4", TextRange(13))
        )
        assertEquals("+91987654", phone.text)
        assertEquals(TextRange(9), phone.selection)
    }
}
