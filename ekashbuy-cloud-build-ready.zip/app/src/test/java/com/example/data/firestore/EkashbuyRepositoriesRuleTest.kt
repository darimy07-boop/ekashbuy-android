package com.example.data.firestore

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.firestore.model.FirestoreNotification
import com.example.data.firestore.model.FirestoreNotificationType
import com.example.data.firestore.model.FirestoreUser
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class EkashbuyRepositoriesRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun userRepository_authenticatedOwnerCanSaveAndRead_otherUserRejected() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@ekashbuy.test")
        val aliceUserRepo = FirestoreUserRepository(firestore, auth)

        val saveResult = withTimeout(TIMEOUT_MS) {
            aliceUserRepo.saveUserProfile(
                FirestoreUser(
                    displayName = "Aamir Lone",
                    mobileNumber = "+919419000112",
                    district = KashmirDistrict.SRINAGAR.name,
                    locality = "Rajbagh"
                )
            )
        }
        assertTrue(saveResult.isSuccess)

        val loaded = withTimeout(TIMEOUT_MS) {
            aliceUserRepo.getUserProfile(aliceUid).getOrThrow()
        }
        assertNotNull(loaded)
        assertEquals("Aamir Lone", loaded?.displayName)

        // Sign in as Bob and verify Bob cannot read Alice's PII profile
        signInTestUser("bob_${UUID.randomUUID()}@ekashbuy.test")
        val bobUserRepo = FirestoreUserRepository(firestore, auth)
        val crossRead = withTimeout(TIMEOUT_MS) {
            bobUserRepo.getUserProfile(aliceUid)
        }
        assertTrue(crossRead.isFailure)
        val firestoreEx = crossRead.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }

    @Test
    fun listingsMessagesFavouritesNotifications_endToEndAndSecurityBoundaries() = runBlocking {
        val sellerUid = signInTestUser("seller_${UUID.randomUUID()}@ekashbuy.test")
        val sellerListingsRepo = FirestoreListingsRepository(firestore, auth)

        val listingId = withTimeout(TIMEOUT_MS) {
            sellerListingsRepo.createListing(
                FirestoreListing(
                    id = "ad_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                    sellerName = "Zainab Bhat",
                    sellerPhone = "+917006000319",
                    title = "MacBook Air M2 Humhama",
                    description = "Well maintained MacBook Air M2 in Humhama, Budgam.",
                    priceInr = 68500L,
                    negotiable = true,
                    category = AdCategory.ELECTRONICS.name,
                    district = KashmirDistrict.BUDGAM.name,
                    locality = "Humhama",
                    condition = AdCondition.LIKE_NEW.name,
                    specs = mapOf("RAM" to "16GB", "Storage" to "256GB")
                )
            ).getOrThrow()
        }

        val createdListing = withTimeout(TIMEOUT_MS) {
            sellerListingsRepo.getListingById(listingId).getOrThrow()
        }
        assertNotNull(createdListing)
        assertEquals(sellerUid, createdListing?.sellerId)

        // Buyer signs in, adds favourite, starts conversation, sends message
        val buyerUid = signInTestUser("buyer_${UUID.randomUUID()}@ekashbuy.test")
        val buyerFavRepo = FirestoreFavouritesRepository(firestore, auth)
        val buyerMsgRepo = FirestoreMessagesRepository(firestore, auth)
        val buyerNotifRepo = FirestoreNotificationsRepository(firestore, auth)

        val favResult = withTimeout(TIMEOUT_MS) {
            buyerFavRepo.addFavourite(createdListing!!)
        }
        assertTrue(favResult.isSuccess)

        val favs = withTimeout(FLOW_TIMEOUT_MS) {
            buyerFavRepo.observeUserFavourites(buyerUid).first { it.any { fav -> fav.listingId == listingId } }
        }
        assertEquals(1, favs.size)

        val convId = withTimeout(TIMEOUT_MS) {
            buyerMsgRepo.getOrCreateConversation(
                listing = createdListing!!,
                buyerName = "Irfan Mir",
                initialMessage = "Is the laptop available in Humhama?"
            ).getOrThrow()
        }

        val entries = withTimeout(FLOW_TIMEOUT_MS) {
            buyerMsgRepo.observeConversationMessages(convId).first { it.isNotEmpty() }
        }
        assertEquals("Is the laptop available in Humhama?", entries.first().text)

        // Seller can reply inside conversation
        signInTestUser("seller_reply_${UUID.randomUUID()}@ekashbuy.test")
        // Verify outsider cannot send a message in Alice/Buyer's conversation
        val outsiderMsgRepo = FirestoreMessagesRepository(firestore, auth)
        val outsiderAttempt = withTimeout(TIMEOUT_MS) {
            outsiderMsgRepo.sendMessage(convId, "Outsider", "Blocked message")
        }
        assertTrue(outsiderAttempt.isFailure)

        // Buyer notifications create + mark as read
        auth.signOut()
        signInTestUser("notif_${UUID.randomUUID()}@ekashbuy.test")
        val notifUid = auth.currentUser!!.uid
        val notifId = withTimeout(TIMEOUT_MS) {
            buyerNotifRepo.createNotification(
                FirestoreNotification(
                    type = FirestoreNotificationType.NEW_MESSAGE.name,
                    title = "New reply",
                    body = "Seller replied to your ad inquiry",
                    listingId = listingId,
                    conversationId = convId
                )
            ).getOrThrow()
        }
        val markRead = withTimeout(TIMEOUT_MS) {
            buyerNotifRepo.markAsRead(notifId)
        }
        assertTrue(markRead.isSuccess)
        val notifications = withTimeout(FLOW_TIMEOUT_MS) {
            buyerNotifRepo.observeUserNotifications(notifUid).first { it.any { n -> n.id == notifId && n.isRead } }
        }
        assertTrue(notifications.any { it.id == notifId && it.isRead })
    }

    @Test
    fun observeListings_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = FirestoreListingsRepository(firestore, auth)
        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeActiveListings().first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        val firestoreEx = caught?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException, got $caught", firestoreEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }

    @Test
    fun listingsCrud_onlyOwnerCanUpdateStatusAndDelete() = runBlocking {
        val sellerEmail = "owner_${UUID.randomUUID()}@ekashbuy.test"
        val sellerUid = signInTestUser(sellerEmail)
        val sellerRepo = FirestoreListingsRepository(firestore, auth)

        val listing = FirestoreListing(
            id = "ad_${UUID.randomUUID().toString().replace("-", "").take(12)}",
            sellerName = "Aamir Lone",
            sellerPhone = "+919419000112",
            title = "Kashmiri Silk Carpet 6x4",
            description = "Authentic hand-knotted pure silk carpet in Zainakadal, Srinagar.",
            priceInr = 45000L,
            negotiable = true,
            category = AdCategory.HANDICRAFTS.name,
            district = KashmirDistrict.SRINAGAR.name,
            locality = "Zainakadal",
            condition = AdCondition.BRAND_NEW.name
        )
        val createdId = withTimeout(TIMEOUT_MS) {
            sellerRepo.createListing(listing).getOrThrow()
        }

        // Another signed-in user tries to update, change status, or delete -> PERMISSION_DENIED
        signInTestUser("intruder_${UUID.randomUUID()}@ekashbuy.test")
        val intruderRepo = FirestoreListingsRepository(firestore, auth)

        val unauthorizedEdit = withTimeout(TIMEOUT_MS) {
            intruderRepo.updateListing(listing.copy(id = createdId, sellerId = sellerUid, priceInr = 100L))
        }
        assertTrue(unauthorizedEdit.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            unauthorizedEdit.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val unauthorizedStatus = withTimeout(TIMEOUT_MS) {
            intruderRepo.updateListingStatus(createdId, FirestoreListingStatus.SOLD)
        }
        assertTrue(unauthorizedStatus.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            unauthorizedStatus.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val unauthorizedDelete = withTimeout(TIMEOUT_MS) {
            intruderRepo.deleteListing(createdId)
        }
        assertTrue(unauthorizedDelete.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            unauthorizedDelete.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        // Original seller signs back in -> update, pause, and delete succeed
        signInTestUser(sellerEmail)
        val ownerEdit = withTimeout(TIMEOUT_MS) {
            sellerRepo.updateListing(
                listing.copy(
                    id = createdId,
                    sellerId = sellerUid,
                    title = "Kashmiri Silk Carpet 6x4 Updated",
                    priceInr = 42000L
                )
            )
        }
        assertTrue(ownerEdit.isSuccess)

        val ownerStatus = withTimeout(TIMEOUT_MS) {
            sellerRepo.updateListingStatus(createdId, FirestoreListingStatus.PAUSED)
        }
        assertTrue(ownerStatus.isSuccess)

        val updatedDoc = withTimeout(TIMEOUT_MS) {
            sellerRepo.getListingById(createdId).getOrThrow()
        }
        assertEquals("Kashmiri Silk Carpet 6x4 Updated", updatedDoc?.title)
        assertEquals(42000L, updatedDoc?.priceInr)
        assertEquals(FirestoreListingStatus.PAUSED.name, updatedDoc?.status)

        val ownerDelete = withTimeout(TIMEOUT_MS) {
            sellerRepo.deleteListing(createdId)
        }
        assertTrue(ownerDelete.isSuccess)
    }

    @Test
    fun favourites_duplicateAddIsIdempotent_andRestoresAfterSignOutAndSignIn() = runBlocking {
        signInTestUser("seller_fav_${UUID.randomUUID()}@ekashbuy.test")
        val listingsRepo = FirestoreListingsRepository(firestore, auth)
        val listingId = withTimeout(TIMEOUT_MS) {
            listingsRepo.createListing(
                FirestoreListing(
                    id = "ad_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                    sellerName = "Tariq Lone",
                    sellerPhone = "+919419000555",
                    title = "Kashmiri Copper Samovar",
                    description = "Handcrafted copper samovar in Zainakadal, Srinagar.",
                    priceInr = 6500L,
                    negotiable = true,
                    category = AdCategory.HANDICRAFTS.name,
                    district = KashmirDistrict.SRINAGAR.name,
                    locality = "Zainakadal",
                    condition = AdCondition.BRAND_NEW.name
                )
            ).getOrThrow()
        }
        val listing = withTimeout(TIMEOUT_MS) {
            listingsRepo.getListingById(listingId).getOrThrow()!!
        }

        val buyerEmail = "buyer_fav_${UUID.randomUUID()}@ekashbuy.test"
        val buyerUid = signInTestUser(buyerEmail)
        val favRepo = FirestoreFavouritesRepository(firestore, auth)

        // First and duplicate second addFavourite both succeed with a single Firestore document
        val firstSave = withTimeout(TIMEOUT_MS) { favRepo.addFavourite(listing) }
        val duplicateSave = withTimeout(TIMEOUT_MS) { favRepo.addFavourite(listing) }
        assertTrue(firstSave.isSuccess)
        assertTrue(duplicateSave.isSuccess)

        // Sign out and sign back in as the same buyer -> favourite restores
        auth.signOut()
        val restoredUid = signInTestUser(buyerEmail)
        assertEquals(buyerUid, restoredUid)

        val restoredFavs = withTimeout(FLOW_TIMEOUT_MS) {
            favRepo.observeUserFavourites(restoredUid).first { it.isNotEmpty() }
        }
        assertEquals(1, restoredFavs.size)
        assertEquals(listingId, restoredFavs.first().listingId)
    }

    private companion object {
        const val TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
