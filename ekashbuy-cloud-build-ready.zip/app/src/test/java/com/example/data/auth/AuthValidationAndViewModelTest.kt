package com.example.data.auth

import android.app.Activity
import com.example.model.KashmirDistrict
import com.example.ui.state.AuthViewModel
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@OptIn(ExperimentalCoroutinesApi::class)
class AuthValidationAndViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun phoneNormalization_handlesIndianAndE164Formats() {
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("9876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("09876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("919876543210"))
        assertEquals("+919876543210", AuthValidation.normalizePhoneToE164("+91 98765-43210"))
        assertEquals("+14155552671", AuthValidation.normalizePhoneToE164("+1 (415) 555-2671"))

        assertNull(AuthValidation.normalizePhoneToE164(""))
        assertNull(AuthValidation.normalizePhoneToE164("12345"))
        assertNull(AuthValidation.normalizePhoneToE164("5876543210"))
        assertNull(AuthValidation.normalizePhoneToE164("abcdefghij"))
    }

    @Test
    fun emailPasswordOtpValidation_enforcesRequiredConstraints() {
        assertTrue(AuthValidation.isValidEmail("aamir.lone@example.com"))
        assertFalse(AuthValidation.isValidEmail("invalid-email"))
        assertFalse(AuthValidation.isValidEmail(""))

        assertNotNull(AuthValidation.validatePassword(""))
        assertNotNull(AuthValidation.validatePassword("12345"))
        assertNull(AuthValidation.validatePassword("123456"))

        assertNotNull(AuthValidation.validateFullName("A"))
        assertNull(AuthValidation.validateFullName("Aamir Lone"))

        assertNotNull(AuthValidation.validateOtpCode("123"))
        assertNotNull(AuthValidation.validateOtpCode("12ab56"))
        assertNull(AuthValidation.validateOtpCode("123456"))
    }

    @Test
    fun errorMapper_returnsClearUserFriendlyMessages() {
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_INVALID_EMAIL").contains("valid email"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_EMAIL_ALREADY_IN_USE").contains("already exists"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_INVALID_VERIFICATION_CODE").contains("OTP"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_MISSING_VERIFICATION_CODE").contains("6-digit OTP"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_MISSING_VERIFICATION_ID").contains("expired"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_INTERNAL_ERROR", "BILLING_NOT_ENABLED").contains("Blaze"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_TOO_MANY_REQUESTS").contains("Too many"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_WEAK_PASSWORD").contains("6 characters"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_WEB_CONTEXT_CANCELED").contains("cancelled"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_WEB_INTERNAL_ERROR").contains("Chrome"))
        assertTrue(AuthErrorMapper.mapAuthCode("ERROR_WEB_STORAGE_UNSUPPORTED").contains("Chrome"))
    }

    @Test
    fun authViewModel_emailSignInRegisterAndLogout_updateStateCorrectly() = runTest(testDispatcher) {
        val fakeRepo = FakeAuthRepository()
        val viewModel = AuthViewModel(authRepository = fakeRepo, userProfileRepository = null)

        // Invalid email sets validation error without calling repository
        viewModel.signInWithEmail("bad-email", "secret123")
        assertNotNull(viewModel.uiState.value.errorMessage)
        assertNull(viewModel.uiState.value.currentUser)

        // Successful registration updates currentUser
        viewModel.registerWithEmail(
            fullName = "Zoya Mir",
            email = "zoya@ekashbuy.in",
            rawPhone = "9419012345",
            district = KashmirDistrict.SRINAGAR,
            password = "password123"
        )
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.errorMessage)
        assertEquals("Zoya Mir", viewModel.uiState.value.currentUser?.displayName)
        assertEquals("+919419012345", viewModel.uiState.value.currentUser?.phoneNumber)

        // Sign out clears session and sets info message
        viewModel.signOut()
        advanceUntilIdle()
        assertNull(viewModel.uiState.value.currentUser)
        assertNotNull(viewModel.uiState.value.infoMessage)

        // Failed email sign-in surfaces error message
        fakeRepo.nextSignInFailure = IllegalStateException("Incorrect credentials. Please check your details and try again.")
        viewModel.signInWithEmail("zoya@ekashbuy.in", "wrongpass")
        advanceUntilIdle()
        assertNull(viewModel.uiState.value.currentUser)
        assertEquals(
            "Incorrect credentials. Please check your details and try again.",
            viewModel.uiState.value.errorMessage
        )
    }

    @Test
    fun authViewModel_manualOtpVerification_createsAndFetchesProfileBeforeReleasingLoading() = runTest(testDispatcher) {
        val fakeAuth = FakeAuthRepository()
        val fakeProfileRepo = FakeUserProfileRepository()
        val viewModel = AuthViewModel(authRepository = fakeAuth, userProfileRepository = fakeProfileRepo)

        val dummyActivity = Robolectric.buildActivity(Activity::class.java).get()
        viewModel.requestPhoneOtp(
            activity = dummyActivity,
            rawPhone = "9419012345",
            fullName = "Bilal Ahmad",
            district = KashmirDistrict.BARAMULLA
        )
        assertTrue(viewModel.uiState.value.otpCodeSent)

        viewModel.verifyOtp("123456")
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertNotNull(state.currentUser)
        assertNotNull(state.userProfile)
        assertEquals("Bilal Ahmad", state.userProfile?.displayName)
        assertEquals("+919419012345", state.userProfile?.mobileNumber)
        assertEquals(KashmirDistrict.BARAMULLA.name, state.userProfile?.district)
        assertFalse(state.isLoading)
        assertFalse(state.isSyncingProfile)
        assertTrue(fakeProfileRepo.savedProfiles.containsKey("uid-phone-1"))
    }

    @Test
    fun authViewModel_autoVerificationCompleted_holdsNavigationUntilProfileSynced() = runTest(testDispatcher) {
        val fakeAuth = FakeAuthRepository(triggerAutoVerify = true)
        val fakeProfileRepo = FakeUserProfileRepository()
        val viewModel = AuthViewModel(authRepository = fakeAuth, userProfileRepository = fakeProfileRepo)

        val dummyActivity = Robolectric.buildActivity(Activity::class.java).get()
        viewModel.requestPhoneOtp(
            activity = dummyActivity,
            rawPhone = "9876543210",
            fullName = "Sana Mir",
            district = KashmirDistrict.ANANTNAG
        )

        // Auth state may already reflect signed-in user before VerificationCompleted coroutine finishes
        assertTrue(viewModel.uiState.value.isLoading || viewModel.uiState.value.isSyncingProfile)

        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertNotNull(state.currentUser)
        assertNotNull(state.userProfile)
        assertEquals("Sana Mir", state.userProfile?.displayName)
        assertEquals("+919876543210", state.userProfile?.mobileNumber)
        assertEquals(KashmirDistrict.ANANTNAG.name, state.userProfile?.district)
        assertFalse(state.isLoading)
        assertFalse(state.isSyncingProfile)
        assertTrue(fakeProfileRepo.savedProfiles.containsKey("uid-auto-phone-1"))
    }

    @Test
    fun authViewModel_resendOtp_and_autoRetrievalTimeout_stillAllowManualVerificationAndProfileCreation() = runTest(testDispatcher) {
        val fakeAuth = FakeAuthRepository(emitAutoRetrievalTimeout = true)
        val fakeProfileRepo = FakeUserProfileRepository()
        val viewModel = AuthViewModel(authRepository = fakeAuth, userProfileRepository = fakeProfileRepo)

        val dummyActivity = Robolectric.buildActivity(Activity::class.java).get()
        viewModel.requestPhoneOtp(
            activity = dummyActivity,
            rawPhone = "9419012345",
            isResend = false,
            fullName = "Tariq Lone",
            district = KashmirDistrict.BUDGAM
        )

        assertTrue(viewModel.uiState.value.otpCodeSent)
        assertTrue(viewModel.uiState.value.canResendOtp)

        // Resend OTP issues a new verificationId and clears previous error
        viewModel.requestPhoneOtp(
            activity = dummyActivity,
            rawPhone = "9419012345",
            isResend = true,
            fullName = "Tariq Lone",
            district = KashmirDistrict.BUDGAM
        )
        assertEquals(2, fakeAuth.sentOtpCount)
        assertTrue(viewModel.uiState.value.otpCodeSent)
        assertTrue(viewModel.uiState.value.infoMessage?.contains("New 6-digit OTP sent") == true)

        viewModel.verifyOtp("654321", fullName = "Tariq Lone", district = KashmirDistrict.BUDGAM)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertNotNull(state.currentUser)
        assertNotNull(state.userProfile)
        assertEquals("Tariq Lone", state.userProfile?.displayName)
        assertEquals(KashmirDistrict.BUDGAM.name, state.userProfile?.district)
        assertFalse(state.otpCodeSent)
        assertFalse(state.isLoading)
        assertFalse(state.isSyncingProfile)
    }

    @Test
    fun authViewModel_updateUserProfile_validatesFieldsAndSavesToFirestore() = runTest(testDispatcher) {
        val fakeAuth = FakeAuthRepository()
        val fakeProfileRepo = FakeUserProfileRepository()
        val viewModel = AuthViewModel(authRepository = fakeAuth, userProfileRepository = fakeProfileRepo)

        // Signed-out user cannot update profile
        viewModel.updateUserProfile(
            displayName = "Bilal Bhat",
            mobileNumber = "9876543210",
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh"
        )
        assertEquals("Please sign in to update your profile.", viewModel.uiState.value.errorMessage)

        // Register a user first
        viewModel.registerWithEmail(
            fullName = "Zoya Mir",
            email = "zoya@ekashbuy.in",
            rawPhone = "9419012345",
            district = KashmirDistrict.SRINAGAR,
            password = "password123"
        )
        advanceUntilIdle()

        // Validation rejects KashmirDistrict.ALL and short names
        var successCalls = 0
        viewModel.updateUserProfile(
            displayName = "Z",
            mobileNumber = "9876543210",
            district = KashmirDistrict.SRINAGAR,
            locality = "Rajbagh",
            onSuccess = { successCalls++ }
        )
        assertNotNull(viewModel.uiState.value.errorMessage)
        assertEquals(0, successCalls)

        viewModel.updateUserProfile(
            displayName = "Zoya Mir",
            mobileNumber = "9876543210",
            district = KashmirDistrict.ALL,
            locality = "Rajbagh",
            onSuccess = { successCalls++ }
        )
        assertTrue(viewModel.uiState.value.errorMessage?.contains("district") == true)
        assertEquals(0, successCalls)

        // Valid update normalizes phone and persists to repository
        viewModel.updateUserProfile(
            displayName = "Zoya Tariq",
            mobileNumber = "9876543210",
            district = KashmirDistrict.ANANTNAG,
            locality = "KP Road",
            onSuccess = { successCalls++ }
        )
        advanceUntilIdle()

        assertEquals(1, successCalls)
        assertFalse(viewModel.uiState.value.isUpdatingProfile)
        assertNull(viewModel.uiState.value.errorMessage)
        assertEquals("Profile details updated.", viewModel.uiState.value.infoMessage)
        val saved = fakeProfileRepo.savedProfiles["uid-reg-1"]
        assertNotNull(saved)
        assertEquals("Zoya Tariq", saved?.displayName)
        assertEquals("+919876543210", saved?.mobileNumber)
        assertEquals(KashmirDistrict.ANANTNAG.name, saved?.district)
        assertEquals("KP Road", saved?.locality)
    }

    private class FakeUserProfileRepository : com.example.data.firestore.UserProfileRepository {
        val savedProfiles = mutableMapOf<String, com.example.data.firestore.model.FirestoreUser>()
        private val flows = mutableMapOf<String, MutableStateFlow<com.example.data.firestore.model.FirestoreUser?>>()

        override fun observeUserProfile(userId: String): Flow<com.example.data.firestore.model.FirestoreUser?> {
            return flows.getOrPut(userId) { MutableStateFlow(savedProfiles[userId]) }.asStateFlow()
        }

        override suspend fun getUserProfile(userId: String): Result<com.example.data.firestore.model.FirestoreUser?> {
            return Result.success(savedProfiles[userId])
        }

        override suspend fun saveUserProfile(user: com.example.data.firestore.model.FirestoreUser): Result<Unit> {
            savedProfiles[user.userId] = user
            flows.getOrPut(user.userId) { MutableStateFlow(user) }.value = user
            return Result.success(Unit)
        }
    }

    private class FakeAuthRepository(
        private val triggerAutoVerify: Boolean = false,
        private val emitAutoRetrievalTimeout: Boolean = false
    ) : AuthRepository {
        private val state = MutableStateFlow<AuthUser?>(null)
        var nextSignInFailure: Throwable? = null
        var syncedPhoneUserCalls: Int = 0
        var sentOtpCount: Int = 0

        override fun observeAuthState(): Flow<AuthUser?> = state.asStateFlow()

        override fun currentUser(): AuthUser? = state.value

        override suspend fun signInWithEmail(email: String, password: String): Result<AuthUser> {
            nextSignInFailure?.let { failure ->
                nextSignInFailure = null
                return Result.failure(failure)
            }
            val user = AuthUser(
                uid = "uid-email-1",
                displayName = "Test Member",
                email = email,
                phoneNumber = null
            )
            state.value = user
            return Result.success(user)
        }

        override suspend fun registerWithEmail(
            fullName: String,
            email: String,
            phoneE164: String,
            district: KashmirDistrict,
            password: String
        ): Result<AuthUser> {
            val user = AuthUser(
                uid = "uid-reg-1",
                displayName = fullName,
                email = email,
                phoneNumber = phoneE164
            )
            state.value = user
            return Result.success(user)
        }

        override fun sendPhoneOtp(
            activity: Activity,
            phoneNumberE164: String,
            resendToken: PhoneAuthProvider.ForceResendingToken?,
            onEvent: (PhoneOtpEvent) -> Unit
        ) {
            sentOtpCount++
            if (triggerAutoVerify) {
                val user = AuthUser(
                    uid = "uid-auto-phone-1",
                    displayName = null,
                    email = null,
                    phoneNumber = phoneNumberE164
                )
                state.value = user
                onEvent(PhoneOtpEvent.VerificationCompleted(user))
            } else {
                val verifId = "verif-$sentOtpCount"
                onEvent(
                    PhoneOtpEvent.CodeSent(
                        verificationId = verifId,
                        resendToken = null
                    )
                )
                if (emitAutoRetrievalTimeout) {
                    onEvent(PhoneOtpEvent.AutoRetrievalTimedOut(verifId))
                }
            }
        }

        override suspend fun verifyPhoneOtp(
            verificationId: String,
            smsCode: String,
            fullName: String?,
            district: KashmirDistrict?
        ): Result<AuthUser> {
            val user = AuthUser(
                uid = "uid-phone-1",
                displayName = fullName,
                email = null,
                phoneNumber = "+919419012345"
            )
            state.value = user
            return Result.success(user)
        }

        override suspend fun syncPhoneUserProfile(
            user: AuthUser,
            fullName: String?,
            district: KashmirDistrict?,
            fallbackPhone: String?
        ): Result<AuthUser> {
            syncedPhoneUserCalls++
            return Result.success(
                user.copy(
                    displayName = fullName ?: user.displayName,
                    phoneNumber = user.phoneNumber ?: fallbackPhone
                )
            )
        }

        override fun signOut() {
            state.value = null
        }
    }
}
