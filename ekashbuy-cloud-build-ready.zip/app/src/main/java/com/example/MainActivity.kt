package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.EkashbuyApp
import com.example.ui.state.AuthViewModel
import com.example.ui.state.MarketplaceViewModel
import com.example.ui.theme.EkashbuyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EkashbuyTheme {
                val marketplaceViewModel: MarketplaceViewModel = viewModel(factory = MarketplaceViewModel.Factory)
                val authViewModel: AuthViewModel = viewModel(factory = AuthViewModel.Factory)
                EkashbuyApp(
                    viewModel = marketplaceViewModel,
                    authViewModel = authViewModel
                )
            }
        }
    }
}
