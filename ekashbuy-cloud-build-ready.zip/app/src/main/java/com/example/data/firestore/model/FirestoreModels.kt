package com.example.data.firestore.model

import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName

object FirestoreCollections {
    const val USERS = "users"
    const val LISTINGS = "listings"
    const val MESSAGES = "messages"
    const val MESSAGE_ENTRIES = "entries"
    const val FAVOURITES = "favourites"
    const val NOTIFICATIONS = "notifications"
}

enum class FirestoreListingStatus {
    ACTIVE,
    SOLD,
    PAUSED,
    ARCHIVED
}

enum class FirestoreAdTier {
    ORDINARY_FREE
}

enum class FirestoreNotificationType {
    NEW_MESSAGE,
    LISTING_STATUS,
    SYSTEM_INFO
}

@IgnoreExtraProperties
data class FirestoreUser(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val mobileNumber: String = "",
    val district: String = KashmirDistrict.SRINAGAR.name,
    val locality: String = "",
    val avatarUrl: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(authenticatedUid: String): Map<String, Any> {
        val base = mutableMapOf<String, Any?>(
            "userId" to authenticatedUid,
            "displayName" to displayName.trim(),
            "mobileNumber" to mobileNumber.trim(),
            "district" to district,
            "locality" to locality.trim(),
            "avatarUrl" to avatarUrl?.takeIf { it.isNotBlank() },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return base.filterValues { it != null } as Map<String, Any>
    }

    fun toUpdateMap(): Map<String, Any> {
        val base = mutableMapOf<String, Any?>(
            "userId" to userId,
            "displayName" to displayName.trim(),
            "mobileNumber" to mobileNumber.trim(),
            "district" to district,
            "locality" to locality.trim(),
            "avatarUrl" to avatarUrl?.takeIf { it.isNotBlank() },
            "createdAt" to (createdAt ?: FieldValue.serverTimestamp()),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return base.filterValues { it != null } as Map<String, Any>
    }
}

@IgnoreExtraProperties
data class FirestoreListing(
    @DocumentId val id: String = "",
    val sellerId: String = "",
    val sellerName: String = "",
    val sellerPhone: String = "",
    val title: String = "",
    val description: String = "",
    val priceInr: Long = 0L,
    @get:PropertyName("isMonthlyRent")
    @field:PropertyName("isMonthlyRent")
    val isMonthlyRent: Boolean = false,
    val negotiable: Boolean = true,
    val category: String = AdCategory.MOBILES.name,
    val district: String = KashmirDistrict.SRINAGAR.name,
    val locality: String = "",
    val condition: String = AdCondition.GOOD.name,
    val imageUrls: List<String> = emptyList(),
    val specs: Map<String, String> = emptyMap(),
    val adTier: String = FirestoreAdTier.ORDINARY_FREE.name,
    val status: String = FirestoreListingStatus.ACTIVE.name,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(authenticatedSellerId: String): Map<String, Any> {
        return mapOf(
            "sellerId" to authenticatedSellerId,
            "sellerName" to sellerName.trim(),
            "sellerPhone" to sellerPhone.trim(),
            "title" to title.trim(),
            "description" to description.trim(),
            "priceInr" to priceInr,
            "isMonthlyRent" to isMonthlyRent,
            "negotiable" to negotiable,
            "category" to category,
            "district" to district,
            "locality" to locality.trim(),
            "condition" to condition,
            "imageUrls" to imageUrls.take(6),
            "specs" to specs.entries.take(12).associate { it.key to it.value },
            "adTier" to FirestoreAdTier.ORDINARY_FREE.name,
            "status" to FirestoreListingStatus.ACTIVE.name,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun toEditMap(): Map<String, Any> {
        return mapOf(
            "sellerName" to sellerName.trim(),
            "sellerPhone" to sellerPhone.trim(),
            "title" to title.trim(),
            "description" to description.trim(),
            "priceInr" to priceInr,
            "isMonthlyRent" to isMonthlyRent,
            "negotiable" to negotiable,
            "category" to category,
            "district" to district,
            "locality" to locality.trim(),
            "condition" to condition,
            "imageUrls" to imageUrls.take(6),
            "specs" to specs.entries.take(12).associate { it.key to it.value },
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class FirestoreConversation(
    @DocumentId val id: String = "",
    val listingId: String = "",
    val listingTitle: String = "",
    val listingPriceInr: Long = 0L,
    val district: String = KashmirDistrict.SRINAGAR.name,
    val buyerId: String = "",
    val sellerId: String = "",
    val participantIds: List<String> = emptyList(),
    val buyerName: String = "",
    val sellerName: String = "",
    val lastMessageText: String = "",
    val lastSenderId: String = "",
    val lastMessageAt: Timestamp? = null,
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> {
        return mapOf(
            "listingId" to listingId,
            "listingTitle" to listingTitle.trim(),
            "listingPriceInr" to listingPriceInr,
            "district" to district,
            "buyerId" to buyerId,
            "sellerId" to sellerId,
            "participantIds" to listOf(buyerId, sellerId),
            "buyerName" to buyerName.trim(),
            "sellerName" to sellerName.trim(),
            "lastMessageText" to lastMessageText.trim(),
            "lastSenderId" to lastSenderId,
            "lastMessageAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class FirestoreMessageEntry(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val listingId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val participantIds: List<String> = emptyList(),
    val text: String = "",
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> {
        return mapOf(
            "conversationId" to conversationId,
            "listingId" to listingId,
            "senderId" to senderId,
            "senderName" to senderName.trim(),
            "participantIds" to participantIds,
            "text" to text.trim(),
            "createdAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class FirestoreFavourite(
    @DocumentId val id: String = "",
    val userId: String = "",
    val listingId: String = "",
    val listingTitle: String = "",
    val priceInr: Long = 0L,
    val district: String = KashmirDistrict.SRINAGAR.name,
    val thumbnailUrl: String? = null,
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(authenticatedUid: String): Map<String, Any> {
        val base = mutableMapOf<String, Any?>(
            "userId" to authenticatedUid,
            "listingId" to listingId,
            "listingTitle" to listingTitle.trim(),
            "priceInr" to priceInr,
            "district" to district,
            "thumbnailUrl" to thumbnailUrl?.takeIf { it.isNotBlank() },
            "createdAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return base.filterValues { it != null } as Map<String, Any>
    }
}

@IgnoreExtraProperties
data class FirestoreNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val type: String = FirestoreNotificationType.SYSTEM_INFO.name,
    val title: String = "",
    val body: String = "",
    val listingId: String? = null,
    val conversationId: String? = null,
    @get:PropertyName("isRead")
    @field:PropertyName("isRead")
    val isRead: Boolean = false,
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(authenticatedUid: String): Map<String, Any> {
        val base = mutableMapOf<String, Any?>(
            "userId" to authenticatedUid,
            "type" to type,
            "title" to title.trim(),
            "body" to body.trim(),
            "listingId" to listingId?.takeIf { it.isNotBlank() },
            "conversationId" to conversationId?.takeIf { it.isNotBlank() },
            "isRead" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return base.filterValues { it != null } as Map<String, Any>
    }
}
