package com.example.data

import com.example.R
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.ChatMessagePreview
import com.example.model.ConversationPreview
import com.example.model.KashmirDistrict
import com.example.model.MyAdItem
import com.example.model.MyAdStatus
import com.example.model.ProductListing
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.NumberFormat
import java.util.Locale

/**
 * Clean repository contract so a future FirebaseFirestoreRepository / FirebaseAuthRepository
 * can replace SampleMarketplaceRepository without changing ViewModel or Compose UI layers.
 */
interface MarketplaceRepository {
    fun observeListings(): Flow<List<ProductListing>>
    fun observeMyAds(): Flow<List<MyAdItem>>
    fun observeConversations(): Flow<List<ConversationPreview>>
    fun observeFavoriteIds(): Flow<Set<String>>
    suspend fun toggleFavorite(productId: String)
    fun getListingById(productId: String): ProductListing?
}

class SampleMarketplaceRepository : MarketplaceRepository {

    private val listingsFlow = MutableStateFlow(sampleKashmirListings)
    private val myAdsFlow = MutableStateFlow(sampleMyAds)
    private val conversationsFlow = MutableStateFlow(sampleConversations)
    private val favoriteIdsFlow = MutableStateFlow(setOf("ek_01", "ek_02", "ek_05"))

    override fun observeListings(): Flow<List<ProductListing>> = listingsFlow.asStateFlow()

    override fun observeMyAds(): Flow<List<MyAdItem>> = myAdsFlow.asStateFlow()

    override fun observeConversations(): Flow<List<ConversationPreview>> = conversationsFlow.asStateFlow()

    override fun observeFavoriteIds(): Flow<Set<String>> = favoriteIdsFlow.asStateFlow()

    override suspend fun toggleFavorite(productId: String) {
        favoriteIdsFlow.update { current ->
            if (productId in current) current - productId else current + productId
        }
    }

    override fun getListingById(productId: String): ProductListing? {
        return listingsFlow.value.firstOrNull { it.id == productId }
            ?: myAdsFlow.value.firstOrNull { it.listing.id == productId }?.listing
    }

    companion object {
        private val sampleKashmirListings = listOf(
            ProductListing(
                id = "ek_01",
                title = "Maruti Suzuki Swift VXi 2021 (JK01)",
                priceInr = 545000,
                negotiable = true,
                category = AdCategory.VEHICLES,
                district = KashmirDistrict.SRINAGAR,
                locality = "Rajbagh, Srinagar",
                description = "Single-owner JK01 registered Swift VXi in clean silver finish. Driven 34,200 km with complete service record from Jamkash Vehicleades. New winter-ready tyres installed last month. Available for inspection in Rajbagh.",
                condition = AdCondition.LIKE_NEW,
                postedAgo = "2 hours ago",
                sellerName = "Aamir Lone",
                sellerPhone = "+91 94190 00112",
                imageResId = R.drawable.img_prod_car,
                specs = mapOf(
                    "Year" to "2021",
                    "Kilometres" to "34,200 km",
                    "Fuel" to "Petrol",
                    "Transmission" to "Manual",
                    "Registration" to "JK01 (Srinagar)"
                )
            ),
            ProductListing(
                id = "ek_02",
                title = "Hand-Knotted Kashmiri Pure Silk Carpet (6x4 ft)",
                priceInr = 48000,
                negotiable = true,
                category = AdCategory.HANDICRAFTS,
                district = KashmirDistrict.SRINAGAR,
                locality = "Zainakadal, Srinagar",
                description = "Authentic hand-knotted Kashmiri silk rug crafted in Downtown Srinagar featuring traditional floral and paisley motifs in deep indigo, ivory, and terracotta tones. Ideal for living rooms or guest rooms. Direct sale from artisan family.",
                condition = AdCondition.BRAND_NEW,
                postedAgo = "4 hours ago",
                sellerName = "Farooq Shawl & Crafts",
                sellerPhone = "+91 99060 00248",
                imageResId = R.drawable.img_prod_carpet,
                specs = mapOf(
                    "Size" to "6 ft x 4 ft",
                    "Material" to "Pure Mulberry Silk",
                    "Weave" to "Hand-Knotted",
                    "Origin" to "Srinagar, Kashmir"
                )
            ),
            ProductListing(
                id = "ek_03",
                title = "Apple MacBook Air M2 (16GB RAM / 256GB SSD)",
                priceInr = 68500,
                negotiable = false,
                category = AdCategory.ELECTRONICS,
                district = KashmirDistrict.BUDGAM,
                locality = "Humhama, Budgam",
                description = "Silver MacBook Air M2 purchased 11 months ago. Battery health 97%, zero dents or screen marks. Includes original MagSafe cable, 35W dual USB-C adapter, and box. Meet near Humhama Airport Road.",
                condition = AdCondition.LIKE_NEW,
                postedAgo = "5 hours ago",
                sellerName = "Zainab Bhat",
                sellerPhone = "+91 70060 00319",
                imageResId = R.drawable.img_prod_laptop,
                specs = mapOf(
                    "Processor" to "Apple M2",
                    "Memory" to "16 GB Unified",
                    "Storage" to "256 GB SSD",
                    "Battery Health" to "97%"
                )
            ),
            ProductListing(
                id = "ek_04",
                title = "Samsung Galaxy S24 5G (256GB, Onyx Black)",
                priceInr = 44000,
                negotiable = true,
                category = AdCategory.MOBILES,
                district = KashmirDistrict.BARAMULLA,
                locality = "Sopore, Baramulla",
                description = "Indian retail unit with bill and original box. Used carefully with tempered glass and Spigen case from day one. No scratches. Ready for direct inspection in Sopore main market.",
                condition = AdCondition.LIKE_NEW,
                postedAgo = "Yesterday",
                sellerName = "Irfan Mir",
                sellerPhone = "+91 97970 00451",
                specs = mapOf(
                    "Storage" to "256 GB",
                    "RAM" to "8 GB",
                    "Network" to "5G Dual SIM",
                    "Accessories" to "Box & Original Cable"
                )
            ),
            ProductListing(
                id = "ek_05",
                title = "Carved Kashmiri Walnut Wood 6-Seater Dining Table",
                priceInr = 36000,
                negotiable = true,
                category = AdCategory.HOME_FURNITURE,
                district = KashmirDistrict.ANANTNAG,
                locality = "KP Road, Anantnag",
                description = "Solid seasoned Kashmiri walnut wood dining table with 6 matching carved chairs. Rich natural wax polish, sturdy joints, well cared for in a smoke-free home. Buyer arranges local pickup.",
                condition = AdCondition.GOOD,
                postedAgo = "Yesterday",
                sellerName = "Tariq Wani",
                sellerPhone = "+91 96220 00588",
                specs = mapOf(
                    "Wood" to "Seasoned Kashmiri Walnut",
                    "Seating" to "6 Chairs + Table",
                    "Finish" to "Hand-Carved Chinar Motif"
                )
            ),
            ProductListing(
                id = "ek_06",
                title = "Royal Enfield Classic 350 Halcyon (2022)",
                priceInr = 158000,
                negotiable = true,
                category = AdCategory.VEHICLES,
                district = KashmirDistrict.SRINAGAR,
                locality = "Bemina, Srinagar",
                description = "2022 Dual-channel ABS model, 11,800 km done. Timely serviced, smooth engine, includes leg guard and touring seat. Clear RC & valid insurance until next year.",
                condition = AdCondition.GOOD,
                postedAgo = "2 days ago",
                sellerName = "Bilal Dar",
                sellerPhone = "+91 95960 00614",
                specs = mapOf(
                    "Year" to "2022",
                    "Kilometres" to "11,800 km",
                    "ABS" to "Dual Channel",
                    "Ownership" to "1st Owner"
                )
            ),
            ProductListing(
                id = "ek_07",
                title = "2 BHK Ground Floor Portion for Family Rent",
                priceInr = 18000,
                isMonthlyRent = true,
                negotiable = false,
                category = AdCategory.PROPERTIES,
                district = KashmirDistrict.BUDGAM,
                locality = "Chadoora, Budgam",
                description = "Sunlit 2 BHK independent ground-floor residential portion with spacious kitchen, 24x7 water supply, inverter backup wiring, and dedicated car parking inside gated compound.",
                condition = AdCondition.LIKE_NEW,
                postedAgo = "2 days ago",
                sellerName = "Ghulam Nabi",
                sellerPhone = "+91 94194 00723",
                specs = mapOf(
                    "Type" to "2 BHK Portion",
                    "Floor" to "Ground Floor",
                    "Parking" to "1 Car + Bike",
                    "Furnishing" to "Semi-Furnished"
                )
            ),
            ProductListing(
                id = "ek_08",
                title = "Handwoven Pure Pashmina Kani Shawl (Ivory)",
                priceInr = 22500,
                negotiable = true,
                category = AdCategory.FASHION,
                district = KashmirDistrict.BARAMULLA,
                locality = "Pattan, Baramulla",
                description = "Soft hand-spun winter Pashmina shawl with traditional Kani border weave. Lightweight yet exceptionally warm for Kashmir winters. Direct deal with weaver household in Pattan.",
                condition = AdCondition.BRAND_NEW,
                postedAgo = "3 days ago",
                sellerName = "Shazia Akhtar",
                sellerPhone = "+91 88990 00832",
                specs = mapOf(
                    "Fabric" to "Pure Cashmere Pashmina",
                    "Weave" to "Traditional Kani",
                    "Dimensions" to "200 cm x 100 cm"
                )
            ),
            ProductListing(
                id = "ek_09",
                title = "LG 320L Frost-Free Double Door Refrigerator",
                priceInr = 19500,
                negotiable = true,
                category = AdCategory.ELECTRONICS,
                district = KashmirDistrict.ANANTNAG,
                locality = "Bijbehara, Anantnag",
                description = "Inverter compressor double-door fridge in shiny steel finish. Used for 2 years, cools rapidly, spotless shelves and gasket. Selling due to house relocation.",
                condition = AdCondition.GOOD,
                postedAgo = "3 days ago",
                sellerName = "Muzaffar Sheikh",
                sellerPhone = "+91 91490 00915",
                specs = mapOf(
                    "Capacity" to "320 Litres",
                    "Energy Rating" to "3 Star Smart Inverter",
                    "Age" to "2 Years"
                )
            ),
            ProductListing(
                id = "ek_10",
                title = "Sony Alpha A6400 Mirrorless + 16-50mm Lens",
                priceInr = 56000,
                negotiable = true,
                category = AdCategory.ELECTRONICS,
                district = KashmirDistrict.SRINAGAR,
                locality = "Hazratbal, Srinagar",
                description = "Low shutter count (~6,400 clicks) Sony A6400 kit ideal for wedding, travel, and Dal Lake landscape photography. Includes 2 batteries, charger, and padded camera bag.",
                condition = AdCondition.LIKE_NEW,
                postedAgo = "4 days ago",
                sellerName = "Danish Sofi",
                sellerPhone = "+91 90860 01044",
                specs = mapOf(
                    "Sensor" to "24.2MP APS-C",
                    "Shutter Count" to "6,400",
                    "Lens" to "16-50mm OSS Kit"
                )
            ),
            ProductListing(
                id = "ek_11",
                title = "Engraved Kashmiri Copper Samovar (2.5 Litres)",
                priceInr = 6800,
                negotiable = false,
                category = AdCategory.HANDICRAFTS,
                district = KashmirDistrict.ANANTNAG,
                locality = "Mattan Road, Anantnag",
                description = "Heavy-gauge hand-engraved traditional copper Samovar with inner brass tinning (kalai) freshly done. Perfect for authentic Kahwa and Noon Chai gatherings.",
                condition = AdCondition.BRAND_NEW,
                postedAgo = "4 days ago",
                sellerName = "Aslam Zargar",
                sellerPhone = "+91 97960 01170",
                specs = mapOf(
                    "Capacity" to "2.5 Litres",
                    "Material" to "Pure Copper (Tin-Lined)",
                    "Craft" to "Hand Naqashi Engraving"
                )
            ),
            ProductListing(
                id = "ek_12",
                title = "HP Victus Gaming Laptop (Ryzen 5 / RTX 3050)",
                priceInr = 49500,
                negotiable = true,
                category = AdCategory.ELECTRONICS,
                district = KashmirDistrict.BARAMULLA,
                locality = "Ushkara, Baramulla",
                description = "15.6-inch 144Hz FHD display, 16GB DDR4 RAM, 512GB NVMe SSD, NVIDIA RTX 3050 4GB graphics. Clean thermals, ideal for engineering CAD, video editing, and gaming.",
                condition = AdCondition.GOOD,
                postedAgo = "5 days ago",
                sellerName = "Saqib Khan",
                sellerPhone = "+91 78890 01239",
                imageResId = R.drawable.img_prod_laptop,
                specs = mapOf(
                    "CPU" to "AMD Ryzen 5 5600H",
                    "GPU" to "RTX 3050 4GB",
                    "Display" to "15.6\" 144Hz IPS"
                )
            ),
            ProductListing(
                id = "ek_13",
                title = "Home Appliances & Inverter Repair Specialist",
                priceInr = 400,
                negotiable = false,
                category = AdCategory.SERVICES,
                district = KashmirDistrict.SRINAGAR,
                locality = "Lal Chowk & Citywide, Srinagar",
                description = "On-site servicing for geysers, washing machines, microwaves, and home inverters across Srinagar and nearby Budgam areas. Transparent visit charge, direct payment after work.",
                condition = AdCondition.BRAND_NEW,
                postedAgo = "6 days ago",
                sellerName = "Kashmir Care Technicians",
                sellerPhone = "+91 94191 01305",
                specs = mapOf(
                    "Visit Charge" to "₹400 Inspection",
                    "Coverage" to "Srinagar & Humhama",
                    "Hours" to "9:00 AM – 7:00 PM"
                )
            ),
            ProductListing(
                id = "ek_14",
                title = "10 Marla Residential Plot Near Airport Road",
                priceInr = 4200000,
                negotiable = true,
                category = AdCategory.PROPERTIES,
                district = KashmirDistrict.BUDGAM,
                locality = "Beerwah Road, Budgam",
                description = "Clear-title 10 Marla rectangular plot with 20 ft macadamized road access, electricity pole adjacent, and peaceful residential neighborhood. Direct owner transfer without middleman fees.",
                condition = AdCondition.BRAND_NEW,
                postedAgo = "1 week ago",
                sellerName = "Haji Abdul Rashid",
                sellerPhone = "+91 99064 01490",
                specs = mapOf(
                    "Area" to "10 Marla",
                    "Road Width" to "20 Feet",
                    "Title" to "Clear Mutation Ready"
                )
            )
        )

        private val sampleMyAds = listOf(
            MyAdItem(
                listing = sampleKashmirListings[2],
                status = MyAdStatus.ACTIVE,
                viewCount = 148,
                inquiryCount = 4
            ),
            MyAdItem(
                listing = sampleKashmirListings[1],
                status = MyAdStatus.ACTIVE,
                viewCount = 215,
                inquiryCount = 6
            ),
            MyAdItem(
                listing = sampleKashmirListings[10].copy(
                    id = "my_draft_01",
                    title = "Kashmiri Kangri & Willow Basket Pair (Draft)",
                    priceInr = 1850
                ),
                status = MyAdStatus.DRAFT,
                viewCount = 0,
                inquiryCount = 0
            )
        )

        private val sampleConversations = listOf(
            ConversationPreview(
                id = "chat_01",
                participantName = "Aamir Lone",
                district = KashmirDistrict.SRINAGAR,
                productId = "ek_01",
                productTitle = "Maruti Suzuki Swift VXi 2021",
                productPriceInr = 545000,
                lastMessage = "Yes, you can inspect the car at Rajbagh tomorrow around 11 AM.",
                timestamp = "10:42 AM",
                isBuyingInquiry = true,
                unreadCount = 1,
                messages = listOf(
                    ChatMessagePreview(
                        id = "m1",
                        senderName = "You",
                        text = "Assalamu Alaikum, is the Swift VXi still available for inspection in Rajbagh?",
                        timeLabel = "10:15 AM",
                        isFromBuyer = true
                    ),
                    ChatMessagePreview(
                        id = "m2",
                        senderName = "Aamir Lone",
                        text = "Wa Alaikum Assalam! Yes, you can inspect the car at Rajbagh tomorrow around 11 AM.",
                        timeLabel = "10:42 AM",
                        isFromBuyer = false
                    )
                )
            ),
            ConversationPreview(
                id = "chat_02",
                participantName = "Suhail Ahmad",
                district = KashmirDistrict.BUDGAM,
                productId = "ek_03",
                productTitle = "Apple MacBook Air M2 (16GB)",
                productPriceInr = 68500,
                lastMessage = "Is the price slightly negotiable if I pick it up from Humhama today?",
                timestamp = "Yesterday",
                isBuyingInquiry = false,
                unreadCount = 2,
                messages = listOf(
                    ChatMessagePreview(
                        id = "m3",
                        senderName = "Suhail Ahmad",
                        text = "Hello! Is the MacBook Air M2 Indian bill unit?",
                        timeLabel = "Yesterday, 4:10 PM",
                        isFromBuyer = true
                    ),
                    ChatMessagePreview(
                        id = "m4",
                        senderName = "Suhail Ahmad",
                        text = "Is the price slightly negotiable if I pick it up from Humhama today?",
                        timeLabel = "Yesterday, 4:12 PM",
                        isFromBuyer = true
                    )
                )
            ),
            ConversationPreview(
                id = "chat_03",
                participantName = "Irfan Mir",
                district = KashmirDistrict.BARAMULLA,
                productId = "ek_04",
                productTitle = "Samsung Galaxy S24 5G (256GB)",
                productPriceInr = 44000,
                lastMessage = "Sure, call me before coming to Sopore main market.",
                timestamp = "2d ago",
                isBuyingInquiry = true,
                unreadCount = 0,
                messages = listOf(
                    ChatMessagePreview(
                        id = "m5",
                        senderName = "You",
                        text = "Can we check the phone battery and IMEI in Sopore?",
                        timeLabel = "2d ago",
                        isFromBuyer = true
                    ),
                    ChatMessagePreview(
                        id = "m6",
                        senderName = "Irfan Mir",
                        text = "Sure, call me before coming to Sopore main market.",
                        timeLabel = "2d ago",
                        isFromBuyer = false
                    )
                )
            ),
            ConversationPreview(
                id = "chat_04",
                participantName = "Tariq Wani",
                district = KashmirDistrict.ANANTNAG,
                productId = "ek_05",
                productTitle = "Carved Walnut Wood Dining Set",
                productPriceInr = 36000,
                lastMessage = "All 6 chairs are solid walnut, no repairs done.",
                timestamp = "4d ago",
                isBuyingInquiry = true,
                unreadCount = 0,
                messages = listOf(
                    ChatMessagePreview(
                        id = "m7",
                        senderName = "Tariq Wani",
                        text = "All 6 chairs are solid walnut, no repairs done.",
                        timeLabel = "4d ago",
                        isFromBuyer = false
                    )
                )
            )
        )
    }
}

fun formatInr(amount: Int, isMonthlyRent: Boolean = false): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    formatter.maximumFractionDigits = 0
    val formatted = formatter.format(amount)
    return if (isMonthlyRent) "$formatted / mo" else formatted
}
