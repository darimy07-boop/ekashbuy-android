package com.example.data.firestore

import com.example.data.firestore.model.FirestoreCollections
import com.example.data.firestore.model.FirestoreUser
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface UserProfileRepository {
    fun observeUserProfile(userId: String): Flow<FirestoreUser?>
    suspend fun getUserProfile(userId: String): Result<FirestoreUser?>
    suspend fun saveUserProfile(user: FirestoreUser): Result<Unit>
}

class FirestoreUserRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : UserProfileRepository {

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing user profile.")
    }

    override fun observeUserProfile(userId: String): Flow<FirestoreUser?> = flow {
        val docRef = db.collection(FirestoreCollections.USERS).document(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        FirestoreUser::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(firestoreError ?: error, OperationType.GET, docRef.path, auth)
                    }
                    throw error
                }
        )
    }

    override suspend fun getUserProfile(userId: String): Result<FirestoreUser?> {
        val docRef = db.collection(FirestoreCollections.USERS).document(userId)
        return try {
            val snapshot = docRef.get().await()
            Result.success(
                snapshot.toObject(
                    FirestoreUser::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun saveUserProfile(user: FirestoreUser): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }

        val docRef = db.collection(FirestoreCollections.USERS).document(uid)
        return try {
            val existingSnapshot = docRef.get().await()
            if (existingSnapshot.exists()) {
                val existingUser = existingSnapshot.toObject(FirestoreUser::class.java)
                val merged = user.copy(
                    userId = uid,
                    createdAt = existingUser?.createdAt ?: user.createdAt
                )
                docRef.update(
                    mapOf(
                        "displayName" to merged.displayName.trim(),
                        "mobileNumber" to merged.mobileNumber.trim(),
                        "district" to merged.district,
                        "locality" to merged.locality.trim(),
                        "avatarUrl" to merged.avatarUrl?.takeIf { it.isNotBlank() },
                        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                ).await()
            } else {
                docRef.set(user.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }
}
