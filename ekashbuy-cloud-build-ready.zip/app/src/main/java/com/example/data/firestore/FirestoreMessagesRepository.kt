package com.example.data.firestore

import com.example.data.firestore.model.FirestoreCollections
import com.example.data.firestore.model.FirestoreConversation
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreMessageEntry
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface MessagesRepository {
    fun observeUserConversations(userId: String): Flow<List<FirestoreConversation>>
    fun observeConversationMessages(conversationId: String): Flow<List<FirestoreMessageEntry>>
    suspend fun getOrCreateConversation(
        listing: FirestoreListing,
        buyerName: String,
        initialMessage: String
    ): Result<String>

    suspend fun sendMessage(
        conversationId: String,
        senderName: String,
        text: String
    ): Result<String>
}

class FirestoreMessagesRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : MessagesRepository {

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before messaging.")
    }

    override fun observeUserConversations(userId: String): Flow<List<FirestoreConversation>> = flow {
        val query = db.collection(FirestoreCollections.MESSAGES)
            .whereArrayContains("participantIds", userId)

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreConversation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.lastMessageAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            FirestoreCollections.MESSAGES,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override fun observeConversationMessages(conversationId: String): Flow<List<FirestoreMessageEntry>> = flow {
        val entriesPath = "${FirestoreCollections.MESSAGES}/$conversationId/${FirestoreCollections.MESSAGE_ENTRIES}"
        val uid = auth.currentUser?.uid
        val query = db.collection(FirestoreCollections.MESSAGES)
            .document(conversationId)
            .collection(FirestoreCollections.MESSAGE_ENTRIES)
            .let { ref ->
                if (uid != null) ref.whereArrayContains("participantIds", uid) else ref
            }

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreMessageEntry::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            entriesPath,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override suspend fun getOrCreateConversation(
        listing: FirestoreListing,
        buyerName: String,
        initialMessage: String
    ): Result<String> {
        val buyerId = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        if (listing.id.isBlank() || listing.sellerId.isBlank() || listing.sellerId == buyerId) {
            return Result.failure(
                IllegalArgumentException("You cannot message yourself on your own advertisement.")
            )
        }

        val resolvedBuyerName = buyerName.trim().ifBlank { "eKashbuy Buyer" }.take(60)
        val resolvedSellerName = listing.sellerName.trim().ifBlank { "Seller" }.take(60)
        val trimmedInitial = initialMessage.trim().take(1000)

        val conversationId = "${listing.id}_$buyerId"
        val convRef = db.collection(FirestoreCollections.MESSAGES).document(conversationId)

        return try {
            val existing = convRef.get().await()
            if (!existing.exists()) {
                val conversation = FirestoreConversation(
                    listingId = listing.id,
                    listingTitle = listing.title.trim().ifBlank { "Advertisement" }.take(120),
                    listingPriceInr = listing.priceInr.coerceIn(0L, 500_000_000L),
                    district = listing.district,
                    buyerId = buyerId,
                    sellerId = listing.sellerId,
                    participantIds = listOf(buyerId, listing.sellerId),
                    buyerName = resolvedBuyerName,
                    sellerName = resolvedSellerName,
                    lastMessageText = trimmedInitial,
                    lastSenderId = buyerId
                )
                convRef.set(conversation.toCreateMap()).await()

                if (trimmedInitial.isNotEmpty()) {
                    val entryRef = convRef.collection(FirestoreCollections.MESSAGE_ENTRIES).document()
                    val entry = FirestoreMessageEntry(
                        conversationId = conversationId,
                        listingId = listing.id,
                        senderId = buyerId,
                        senderName = resolvedBuyerName,
                        participantIds = listOf(buyerId, listing.sellerId),
                        text = trimmedInitial
                    )
                    entryRef.set(entry.toCreateMap()).await()
                }
            } else if (trimmedInitial.isNotEmpty()) {
                val sendResult = sendMessage(
                    conversationId = conversationId,
                    senderName = resolvedBuyerName,
                    text = trimmedInitial
                )
                if (sendResult.isFailure) {
                    return Result.failure(
                        sendResult.exceptionOrNull()
                            ?: IllegalStateException("Unable to send message.")
                    )
                }
            }
            Result.success(conversationId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, convRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun sendMessage(
        conversationId: String,
        senderName: String,
        text: String
    ): Result<String> {
        val senderId = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val trimmedText = text.trim()
        if (trimmedText.isEmpty() || trimmedText.length > 1000) {
            return Result.failure(
                IllegalArgumentException("Message must be between 1 and 1000 characters.")
            )
        }
        val resolvedSenderName = senderName.trim().ifBlank { "eKashbuy User" }.take(60)

        val convRef = db.collection(FirestoreCollections.MESSAGES).document(conversationId)
        val entryRef = convRef.collection(FirestoreCollections.MESSAGE_ENTRIES).document()

        return try {
            val convSnapshot = convRef.get().await()
            val conversation = convSnapshot.toObject(FirestoreConversation::class.java)
                ?: return Result.failure(IllegalStateException("Conversation $conversationId not found."))

            val entry = FirestoreMessageEntry(
                conversationId = conversationId,
                listingId = conversation.listingId,
                senderId = senderId,
                senderName = resolvedSenderName,
                participantIds = conversation.participantIds,
                text = trimmedText
            )

            val batch = db.batch()
            batch.set(entryRef, entry.toCreateMap())
            batch.update(
                convRef,
                mapOf(
                    "lastMessageText" to trimmedText,
                    "lastSenderId" to senderId,
                    "lastMessageAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(entryRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, entryRef.path, auth)
            Result.failure(e)
        }
    }
}
