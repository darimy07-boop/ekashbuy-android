package com.example.data.firestore

import com.example.data.firestore.model.FirestoreCollections
import com.example.data.firestore.model.FirestoreFavourite
import com.example.data.firestore.model.FirestoreListing
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface FavouritesRepository {
    fun observeUserFavourites(userId: String): Flow<List<FirestoreFavourite>>
    suspend fun addFavourite(listing: FirestoreListing): Result<String>
    suspend fun removeFavourite(listingId: String): Result<Unit>
}

class FirestoreFavouritesRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : FavouritesRepository {

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before managing favourites.")
    }

    override fun observeUserFavourites(userId: String): Flow<List<FirestoreFavourite>> = flow {
        val query = db.collection(FirestoreCollections.FAVOURITES)
            .whereEqualTo("userId", userId)

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreFavourite::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            FirestoreCollections.FAVOURITES,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override suspend fun addFavourite(listing: FirestoreListing): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        require(listing.id.isNotBlank()) { "Listing ID cannot be blank." }

        val favId = "${uid}_${listing.id}"
        val docRef = db.collection(FirestoreCollections.FAVOURITES).document(favId)
        val favourite = FirestoreFavourite(
            userId = uid,
            listingId = listing.id,
            listingTitle = listing.title,
            priceInr = listing.priceInr,
            district = listing.district,
            thumbnailUrl = listing.imageUrls.firstOrNull()
        )
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                return Result.success(favId)
            }
            docRef.set(favourite.toCreateMap(uid)).await()
            Result.success(favId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun removeFavourite(listingId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val favId = "${uid}_$listingId"
        val docRef = db.collection(FirestoreCollections.FAVOURITES).document(favId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }
}
