package com.example.data.media

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.SelectedAdPhoto
import java.util.UUID

const val MAX_AD_PHOTOS = 6
const val MAX_PHOTO_SIZE_BYTES = 15L * 1024L * 1024L

data class PhotoCandidate(
    val uriString: String,
    val displayName: String = "",
    val mimeType: String? = null,
    val sizeBytes: Long? = null,
    val isReadable: Boolean = true
)

data class ValidatedPhotoBatch(
    val photos: List<SelectedAdPhoto>,
    val errorMessage: String? = null
)

object AdPhotoValidator {

    fun inspectPickedUris(context: Context, uris: List<Uri>): List<PhotoCandidate> {
        val resolver = context.contentResolver
        return uris.map { uri -> inspectSingleUri(resolver, uri) }
    }

    private fun inspectSingleUri(resolver: ContentResolver, uri: Uri): PhotoCandidate {
        try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Photo Picker temporary grants or custom providers may not support persistable permission.
        }

        val scheme = uri.scheme?.lowercase()
        val isSupportedScheme = scheme == ContentResolver.SCHEME_CONTENT ||
            scheme == ContentResolver.SCHEME_FILE ||
            scheme == ContentResolver.SCHEME_ANDROID_RESOURCE

        if (!isSupportedScheme) {
            return PhotoCandidate(
                uriString = uri.toString(),
                isReadable = false
            )
        }

        val mimeType = try {
            resolver.getType(uri)
        } catch (_: Exception) {
            null
        }

        var displayName = ""
        var sizeBytes: Long? = null
        try {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0 && !cursor.isNull(nameIdx)) {
                        displayName = cursor.getString(nameIdx).orEmpty()
                    }
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }
        } catch (_: Exception) {
            // Metadata query may not be supported by all URI providers or unit test shadows.
        }

        return PhotoCandidate(
            uriString = uri.toString(),
            displayName = displayName.ifBlank { uri.lastPathSegment.orEmpty() },
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            isReadable = true
        )
    }

    fun mergeSelectedPhotos(
        existing: List<SelectedAdPhoto>,
        candidates: List<PhotoCandidate>,
        maxPhotos: Int = MAX_AD_PHOTOS
    ): ValidatedPhotoBatch {
        if (candidates.isEmpty()) {
            return ValidatedPhotoBatch(photos = existing, errorMessage = null)
        }

        val result = existing.toMutableList()
        val seenUris = existing.map { it.uriString }.toMutableSet()

        var invalidTypeCount = 0
        var invalidSizeOrUnreadableCount = 0
        var duplicateCount = 0
        var overflowCount = 0

        for (candidate in candidates) {
            val cleanUri = candidate.uriString.trim()
            if (cleanUri.isEmpty() || !candidate.isReadable) {
                invalidSizeOrUnreadableCount++
                continue
            }

            val mime = candidate.mimeType?.trim()?.lowercase()
            if (mime != null && !mime.startsWith("image/")) {
                invalidTypeCount++
                continue
            }

            val bytes = candidate.sizeBytes
            if (bytes != null && (bytes <= 0L || bytes > MAX_PHOTO_SIZE_BYTES)) {
                invalidSizeOrUnreadableCount++
                continue
            }

            if (!seenUris.add(cleanUri)) {
                duplicateCount++
                continue
            }

            if (result.size >= maxPhotos) {
                overflowCount++
                continue
            }

            result += SelectedAdPhoto(
                id = UUID.randomUUID().toString(),
                uriString = cleanUri,
                displayName = candidate.displayName
            )
        }

        val issues = buildList {
            if (overflowCount > 0) {
                add("Maximum $maxPhotos photos allowed per ad ($overflowCount extra skipped).")
            }
            if (duplicateCount > 0) {
                add(
                    if (duplicateCount == 1) "1 duplicate photo was skipped."
                    else "$duplicateCount duplicate photos were skipped."
                )
            }
            if (invalidTypeCount > 0) {
                add("Only image files (JPG, PNG, WebP) can be selected.")
            }
            if (invalidSizeOrUnreadableCount > 0) {
                add("Unreadable, empty, or oversized (>15 MB) images were skipped.")
            }
        }

        return ValidatedPhotoBatch(
            photos = result,
            errorMessage = issues.joinToString(" ").ifBlank { null }
        )
    }

    fun removePhotoAt(photos: List<SelectedAdPhoto>, index: Int): List<SelectedAdPhoto> {
        if (index !in photos.indices) return photos
        return photos.toMutableList().apply { removeAt(index) }
    }

    fun movePhoto(photos: List<SelectedAdPhoto>, fromIndex: Int, toIndex: Int): List<SelectedAdPhoto> {
        if (fromIndex !in photos.indices || toIndex !in photos.indices || fromIndex == toIndex) {
            return photos
        }
        return photos.toMutableList().apply {
            val item = removeAt(fromIndex)
            add(toIndex, item)
        }
    }

    fun setMainPhoto(photos: List<SelectedAdPhoto>, index: Int): List<SelectedAdPhoto> {
        return movePhoto(photos = photos, fromIndex = index, toIndex = 0)
    }
}
