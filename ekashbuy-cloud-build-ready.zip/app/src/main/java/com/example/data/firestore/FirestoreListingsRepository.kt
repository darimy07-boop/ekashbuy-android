package com.example.data.firestore

import com.example.data.firestore.model.FirestoreCollections
import com.example.data.firestore.model.FirestoreListing
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.model.AdCategory
import com.example.model.KashmirDistrict
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface ListingsRepository {
    fun observeActiveListings(
        district: KashmirDistrict? = null,
        category: AdCategory? = null
    ): Flow<List<FirestoreListing>>

    fun observeSellerListings(sellerId: String): Flow<List<FirestoreListing>>
    suspend fun getListingById(listingId: String): Result<FirestoreListing?>
    suspend fun createListing(listing: FirestoreListing): Result<String>
    suspend fun updateListing(listing: FirestoreListing): Result<Unit>
    suspend fun updateListingStatus(listingId: String, status: FirestoreListingStatus): Result<Unit>
    suspend fun deleteListing(listingId: String): Result<Unit>
}

class FirestoreListingsRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : ListingsRepository {

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before modifying listings.")
    }

    override fun observeActiveListings(
        district: KashmirDistrict?,
        category: AdCategory?
    ): Flow<List<FirestoreListing>> = flow {
        // Always include status == ACTIVE so query aligns with security rules
        var query: Query = db.collection(FirestoreCollections.LISTINGS)
            .whereEqualTo("status", FirestoreListingStatus.ACTIVE.name)

        if (district != null && district != KashmirDistrict.ALL) {
            query = query.whereEqualTo("district", district.name)
        }
        if (category != null) {
            query = query.whereEqualTo("category", category.name)
        }

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreListing::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            FirestoreCollections.LISTINGS,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override fun observeSellerListings(sellerId: String): Flow<List<FirestoreListing>> = flow {
        val query = db.collection(FirestoreCollections.LISTINGS)
            .whereEqualTo("sellerId", sellerId)

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreListing::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == sellerId) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            FirestoreCollections.LISTINGS,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override suspend fun getListingById(listingId: String): Result<FirestoreListing?> {
        val docRef = db.collection(FirestoreCollections.LISTINGS).document(listingId)
        return try {
            val snapshot = docRef.get().await()
            Result.success(
                snapshot.toObject(
                    FirestoreListing::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun createListing(listing: FirestoreListing): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }

        val docRef = if (listing.id.isNotBlank()) {
            db.collection(FirestoreCollections.LISTINGS).document(listing.id)
        } else {
            db.collection(FirestoreCollections.LISTINGS).document()
        }

        return try {
            docRef.set(listing.toCreateMap(uid)).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun updateListing(listing: FirestoreListing): Result<Unit> {
        try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        require(listing.id.isNotBlank()) { "Listing ID must not be blank for update" }

        val docRef = db.collection(FirestoreCollections.LISTINGS).document(listing.id)
        return try {
            docRef.update(listing.toEditMap()).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun updateListingStatus(
        listingId: String,
        status: FirestoreListingStatus
    ): Result<Unit> {
        try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        require(listingId.isNotBlank()) { "Listing ID must not be blank" }

        val docRef = db.collection(FirestoreCollections.LISTINGS).document(listingId)
        return try {
            docRef.update(
                mapOf(
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun deleteListing(listingId: String): Result<Unit> {
        try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val docRef = db.collection(FirestoreCollections.LISTINGS).document(listingId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }
}
