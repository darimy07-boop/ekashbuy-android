package com.example.data.auth

import android.app.Activity
import android.util.Log
import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreUser
import com.example.model.KashmirDistrict
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthMissingActivityForRecaptchaException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.userProfileChangeRequest
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class AuthUser(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val phoneNumber: String?,
    val providerIds: List<String> = emptyList()
)

sealed class PhoneOtpEvent {
    data class CodeSent(
        val verificationId: String,
        val resendToken: PhoneAuthProvider.ForceResendingToken? = null
    ) : PhoneOtpEvent()

    data class AutoRetrievalTimedOut(val verificationId: String) : PhoneOtpEvent()

    data class VerificationCompleted(val user: AuthUser) : PhoneOtpEvent()

    data class VerificationFailed(val message: String) : PhoneOtpEvent()
}

object AuthValidation {
    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val E164_REGEX = Regex("^\\+[1-9]\\d{7,14}$")
    private val INDIAN_10_DIGIT_REGEX = Regex("^[6-9]\\d{9}$")

    fun isValidEmail(email: String): Boolean {
        val trimmed = email.trim()
        return trimmed.isNotEmpty() && EMAIL_REGEX.matches(trimmed)
    }

    fun validatePassword(password: String): String? {
        return when {
            password.isBlank() -> "Please enter a password."
            password.length < 6 -> "Password must be at least 6 characters."
            else -> null
        }
    }

    fun validateFullName(name: String): String? {
        val trimmed = name.trim()
        return when {
            trimmed.length < 2 -> "Please enter your full name (at least 2 characters)."
            trimmed.length > 60 -> "Full name must be 60 characters or fewer."
            else -> null
        }
    }

    fun validateOtpCode(code: String): String? {
        val digitsOnly = code.trim()
        return when {
            digitsOnly.length != 6 || !digitsOnly.all { it.isDigit() } ->
                "Please enter the 6-digit OTP sent to your phone."
            else -> null
        }
    }

    /**
     * Normalizes Indian mobile numbers and E.164 phone numbers to E.164 format.
     * Examples:
     * - "9876543210" -> "+919876543210"
     * - "09876543210" -> "+919876543210"
     * - "919876543210" -> "+919876543210"
     * - "+91 98765-43210" -> "+919876543210"
     */
    fun normalizePhoneToE164(raw: String): String? {
        val cleaned = raw.trim()
            .replace(" ", "")
            .replace("-", "")
            .replace("(", "")
            .replace(")", "")

        if (cleaned.isEmpty()) return null

        if (cleaned.startsWith("+")) {
            return if (E164_REGEX.matches(cleaned)) cleaned else null
        }

        if (!cleaned.all { it.isDigit() }) return null

        return when {
            INDIAN_10_DIGIT_REGEX.matches(cleaned) -> "+91$cleaned"
            cleaned.length == 11 && cleaned.startsWith("0") &&
                INDIAN_10_DIGIT_REGEX.matches(cleaned.drop(1)) -> "+91${cleaned.drop(1)}"
            cleaned.length == 12 && cleaned.startsWith("91") &&
                INDIAN_10_DIGIT_REGEX.matches(cleaned.drop(2)) -> "+$cleaned"
            else -> null
        }
    }
}

object AuthErrorMapper {
    fun toUserMessage(error: Throwable): String {
        if (error is FirebaseNetworkException) {
            return "Network error. Please check your internet connection and try again."
        }
        if (error is FirebaseTooManyRequestsException) {
            return "Too many attempts right now. Please wait a few minutes before trying again."
        }
        if (error is FirebaseAuthWeakPasswordException) {
            return "Password is too weak. Please use at least 6 characters."
        }
        if (error is FirebaseAuthUserCollisionException) {
            return "An account already exists with this email address. Try signing in instead."
        }
        if (error is FirebaseAuthInvalidUserException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseAuthInvalidCredentialsException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseAuthMissingActivityForRecaptchaException) {
            return "Unable to launch verification in the browser from this screen. Please reopen Sign In and try again."
        }
        if (error is FirebaseAuthException) {
            return mapAuthCode(error.errorCode, error.message)
        }
        if (error is FirebaseException) {
            return mapRawMessage(error.message)
        }
        return mapRawMessage(error.message)
    }

    fun mapAuthCode(errorCode: String, rawMessage: String? = null): String {
        return when (errorCode) {
            "ERROR_INVALID_EMAIL" -> "Please enter a valid email address."
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" ->
                "Incorrect credentials. Please check your details and try again."
            "ERROR_USER_NOT_FOUND" -> "No account found with these details. Please create an account first."
            "ERROR_USER_DISABLED" -> "This account has been disabled. Please contact support."
            "ERROR_EMAIL_ALREADY_IN_USE", "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" ->
                "An account already exists with this email address."
            "ERROR_WEAK_PASSWORD" -> "Password is too weak. Please use at least 6 characters."
            "ERROR_INVALID_PHONE_NUMBER" ->
                "Please enter a valid mobile number with country code (e.g. +91 9XXXXXXXXX)."
            "ERROR_MISSING_PHONE_NUMBER" -> "Please enter your mobile number."
            "ERROR_INVALID_VERIFICATION_CODE" ->
                "The OTP code you entered is incorrect. Please check and try again."
            "ERROR_MISSING_VERIFICATION_CODE" ->
                "Please enter the 6-digit OTP sent to your phone."
            "ERROR_INVALID_VERIFICATION_ID", "ERROR_MISSING_VERIFICATION_ID", "ERROR_SESSION_EXPIRED" ->
                "Your OTP session expired. Please request a new OTP."
            "ERROR_QUOTA_EXCEEDED", "ERROR_TOO_MANY_REQUESTS" ->
                "Too many verification attempts. Please wait a bit and try again."
            "ERROR_OPERATION_NOT_ALLOWED" ->
                "This sign-in method is not enabled in Firebase Console yet."
            "ERROR_APP_NOT_AUTHORIZED", "ERROR_MISSING_CLIENT_IDENTIFIER", "ERROR_INVALID_APP_CREDENTIAL" ->
                "Phone verification setup issue: confirm SHA-1/SHA-256 and Phone Auth are enabled in Firebase Console."
            "ERROR_CAPTCHA_CHECK_FAILED", "ERROR_WEB_CONTEXT_CANCELED", "ERROR_WEB_CONTEXT_ALREADY_PRESENTED" ->
                "Verification challenge was cancelled or failed. Please try again."
            "ERROR_WEB_INTERNAL_ERROR", "ERROR_WEB_STORAGE_UNSUPPORTED" ->
                "Browser verification could not complete. Ensure Chrome is enabled and updated, then try again."
            else -> mapRawMessage(rawMessage)
        }
    }

    private fun mapRawMessage(rawMessage: String?): String {
        val msg = rawMessage?.trim().orEmpty()
        if (msg.isEmpty()) return "Authentication failed. Please try again."
        val lower = msg.lowercase()
        return when {
            "billing_not_enabled" in lower || "sms unable to be sent" in lower ->
                "Firebase Phone Auth SMS requires Blaze billing or a configured Test Phone Number in Firebase Console."
            "network" in lower || "unable to resolve host" in lower ->
                "Network error. Please check your internet connection and try again."
            "play_integrity" in lower || "recaptcha" in lower || "app is not authorized" in lower || "sha" in lower ->
                "Phone Auth verification could not complete. Ensure SHA-1/SHA-256 fingerprints are added in Firebase Console."
            "blocked all requests" in lower || "too many" in lower ->
                "Too many attempts right now. Please try again shortly."
            "sms" in lower && "quota" in lower ->
                "SMS verification quota reached. Please try again later."
            else -> msg
        }
    }
}

interface AuthRepository {
    fun observeAuthState(): Flow<AuthUser?>
    fun currentUser(): AuthUser?
    suspend fun signInWithEmail(email: String, password: String): Result<AuthUser>
    suspend fun registerWithEmail(
        fullName: String,
        email: String,
        phoneE164: String,
        district: KashmirDistrict,
        password: String
    ): Result<AuthUser>

    fun sendPhoneOtp(
        activity: Activity,
        phoneNumberE164: String,
        resendToken: PhoneAuthProvider.ForceResendingToken?,
        onEvent: (PhoneOtpEvent) -> Unit
    )

    suspend fun verifyPhoneOtp(
        verificationId: String,
        smsCode: String,
        fullName: String? = null,
        district: KashmirDistrict? = null
    ): Result<AuthUser>

    suspend fun syncPhoneUserProfile(
        user: AuthUser,
        fullName: String? = null,
        district: KashmirDistrict? = null,
        fallbackPhone: String? = null
    ): Result<AuthUser> = Result.success(user)

    fun signOut()
}

class FirebaseAuthRepository(
    private val auth: FirebaseAuth,
    private val userProfileRepository: UserProfileRepository? = null
) : AuthRepository {

    override fun observeAuthState(): Flow<AuthUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser?.toDomainUser())
        }
        auth.addAuthStateListener(listener)
        trySend(auth.currentUser?.toDomainUser())
        awaitClose {
            auth.removeAuthStateListener(listener)
        }
    }

    override fun currentUser(): AuthUser? = auth.currentUser?.toDomainUser()

    override suspend fun signInWithEmail(email: String, password: String): Result<AuthUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = result.user?.toDomainUser()
                ?: return Result.failure(IllegalStateException("Signed-in user was not returned by Firebase."))
            Result.success(user)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Email sign-in failed", e)
            Result.failure(IllegalStateException(AuthErrorMapper.toUserMessage(e), e))
        }
    }

    override suspend fun registerWithEmail(
        fullName: String,
        email: String,
        phoneE164: String,
        district: KashmirDistrict,
        password: String
    ): Result<AuthUser> {
        return try {
            val cleanName = fullName.trim()
            val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val firebaseUser = result.user
                ?: return Result.failure(IllegalStateException("Registered user was not returned by Firebase."))

            val profileUpdates = userProfileChangeRequest {
                displayName = cleanName
            }
            try {
                firebaseUser.updateProfile(profileUpdates).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Display name update failed after registration", e)
            }

            syncUserProfileBestEffort(
                firebaseUser = firebaseUser,
                fullName = cleanName,
                mobileNumber = phoneE164,
                district = district
            )

            Result.success(
                firebaseUser.toDomainUser().copy(
                    displayName = cleanName,
                    phoneNumber = firebaseUser.phoneNumber ?: phoneE164
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Email registration failed", e)
            Result.failure(IllegalStateException(AuthErrorMapper.toUserMessage(e), e))
        }
    }

    override fun sendPhoneOtp(
        activity: Activity,
        phoneNumberE164: String,
        resendToken: PhoneAuthProvider.ForceResendingToken?,
        onEvent: (PhoneOtpEvent) -> Unit
    ) {
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                Log.i(TAG, "Phone OTP auto-verification completed; signing in with credential")
                auth.signInWithCredential(credential)
                    .addOnSuccessListener { result ->
                        val firebaseUser = result.user
                        if (firebaseUser != null) {
                            Log.i(TAG, "Auto sign-in with phone credential succeeded: uid=${firebaseUser.uid}")
                            onEvent(PhoneOtpEvent.VerificationCompleted(firebaseUser.toDomainUser()))
                        } else {
                            Log.w(TAG, "Auto sign-in succeeded without user session")
                            onEvent(PhoneOtpEvent.VerificationFailed("Phone verification completed, but user session is missing."))
                        }
                    }
                    .addOnFailureListener { error ->
                        val code = (error as? FirebaseAuthException)?.errorCode ?: error.javaClass.simpleName
                        Log.w(TAG, "Auto sign-in with phone credential failed (code=$code)", error)
                        onEvent(PhoneOtpEvent.VerificationFailed(AuthErrorMapper.toUserMessage(error)))
                    }
            }

            override fun onVerificationFailed(exception: FirebaseException) {
                val code = (exception as? FirebaseAuthException)?.errorCode ?: exception.javaClass.simpleName
                Log.w(TAG, "Phone verification failed (code=$code)", exception)
                onEvent(PhoneOtpEvent.VerificationFailed(AuthErrorMapper.toUserMessage(exception)))
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                Log.i(TAG, "Phone OTP code sent (verificationIdLength=${verificationId.length}, isResend=${resendToken != null})")
                onEvent(PhoneOtpEvent.CodeSent(verificationId = verificationId, resendToken = token))
            }

            override fun onCodeAutoRetrievalTimeOut(verificationId: String) {
                Log.i(TAG, "Phone OTP auto-retrieval timed out; manual entry remains valid")
                onEvent(PhoneOtpEvent.AutoRetrievalTimedOut(verificationId))
            }
        }

        Log.i(TAG, "Starting PhoneAuthProvider.verifyPhoneNumber (isResend=${resendToken != null})")
        val optionsBuilder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumberE164)
            .setTimeout(120L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)

        if (resendToken != null) {
            optionsBuilder.setForceResendingToken(resendToken)
        }

        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    override suspend fun verifyPhoneOtp(
        verificationId: String,
        smsCode: String,
        fullName: String?,
        district: KashmirDistrict?
    ): Result<AuthUser> {
        return try {
            Log.i(TAG, "Submitting manual PhoneAuthCredential (codeLength=${smsCode.trim().length})")
            val credential = PhoneAuthProvider.getCredential(verificationId, smsCode.trim())
            val result = auth.signInWithCredential(credential).await()
            val firebaseUser = result.user
                ?: return Result.failure(IllegalStateException("Phone sign-in succeeded without a user session."))

            Log.i(TAG, "Manual OTP sign-in succeeded: uid=${firebaseUser.uid}")
            val syncedUser = finalizePhoneUserProfile(
                firebaseUser = firebaseUser,
                fullName = fullName,
                district = district,
                fallbackPhone = null
            )
            Result.success(syncedUser)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val code = (e as? FirebaseAuthException)?.errorCode ?: e.javaClass.simpleName
            Log.w(TAG, "OTP verification failed (code=$code)", e)
            Result.failure(IllegalStateException(AuthErrorMapper.toUserMessage(e), e))
        }
    }

    override suspend fun syncPhoneUserProfile(
        user: AuthUser,
        fullName: String?,
        district: KashmirDistrict?,
        fallbackPhone: String?
    ): Result<AuthUser> {
        return try {
            val firebaseUser = auth.currentUser
            if (firebaseUser != null && firebaseUser.uid == user.uid) {
                Result.success(
                    finalizePhoneUserProfile(
                        firebaseUser = firebaseUser,
                        fullName = fullName,
                        district = district,
                        fallbackPhone = fallbackPhone ?: user.phoneNumber
                    )
                )
            } else {
                Result.success(user)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Phone user profile synchronization failed", e)
            Result.success(user)
        }
    }

    private suspend fun finalizePhoneUserProfile(
        firebaseUser: FirebaseUser,
        fullName: String?,
        district: KashmirDistrict?,
        fallbackPhone: String?
    ): AuthUser {
        val cleanName = fullName?.trim()?.takeIf { it.length >= 2 }
        if (cleanName != null) {
            try {
                firebaseUser.updateProfile(
                    userProfileChangeRequest { displayName = cleanName }
                ).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Could not update display name after OTP verification", e)
            }
        }

        val resolvedName = cleanName ?: firebaseUser.displayName?.trim()?.takeIf { it.length >= 2 }
        val explicitDistrict = district?.takeIf { it != KashmirDistrict.ALL }
        val phone = firebaseUser.phoneNumber?.trim()?.takeIf { it.length >= 7 }
            ?: fallbackPhone?.trim()?.takeIf { it.length >= 7 }

        if (phone != null) {
            val existingProfile = userProfileRepository?.getUserProfile(firebaseUser.uid)?.getOrNull()
            if (existingProfile == null || cleanName != null || explicitDistrict != null) {
                syncUserProfileBestEffort(
                    firebaseUser = firebaseUser,
                    fullName = resolvedName ?: existingProfile?.displayName?.takeIf { it.length >= 2 } ?: "eKashbuy Member",
                    mobileNumber = phone,
                    district = explicitDistrict
                        ?: KashmirDistrict.entries.firstOrNull { it.name == existingProfile?.district }
                        ?: KashmirDistrict.SRINAGAR
                )
            }
        }

        return firebaseUser.toDomainUser().copy(
            displayName = resolvedName ?: firebaseUser.displayName,
            phoneNumber = firebaseUser.phoneNumber ?: phone
        )
    }

    override fun signOut() {
        auth.signOut()
    }

    private suspend fun syncUserProfileBestEffort(
        firebaseUser: FirebaseUser,
        fullName: String,
        mobileNumber: String,
        district: KashmirDistrict
    ) {
        val repo = userProfileRepository ?: return
        val safeDistrict = if (district == KashmirDistrict.ALL) KashmirDistrict.SRINAGAR else district
        val safeName = fullName.trim().take(60)
        val safePhone = mobileNumber.trim().take(20)
        if (safeName.length < 2 || safePhone.length < 7) return

        try {
            repo.saveUserProfile(
                FirestoreUser(
                    id = firebaseUser.uid,
                    userId = firebaseUser.uid,
                    displayName = safeName,
                    mobileNumber = safePhone,
                    district = safeDistrict.name,
                    locality = ""
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Best-effort Firestore user profile sync failed", e)
        }
    }

    private fun FirebaseUser.toDomainUser(): AuthUser {
        return AuthUser(
            uid = uid,
            displayName = displayName,
            email = email,
            phoneNumber = phoneNumber,
            providerIds = providerData.map { it.providerId }.filter { it != "firebase" }
        )
    }

    private companion object {
        const val TAG = "FirebaseAuthRepository"
    }
}
