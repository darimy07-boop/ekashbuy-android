package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

interface MarketplaceLocalStore {
    fun observeSearchHistory(userId: String): Flow<List<String>>
    fun recordSearchQuery(userId: String, query: String)
    fun removeSearchQuery(userId: String, query: String)
    fun clearSearchHistory(userId: String)

    fun observeConversationLastReadMillis(userId: String): Flow<Map<String, Long>>
    fun markConversationRead(userId: String, conversationId: String, timestampMillis: Long)
}

class InMemoryMarketplaceLocalStore(
    private val maxHistoryItems: Int = 8
) : MarketplaceLocalStore {
    private val historyByUser = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    private val readMillisByUser = MutableStateFlow<Map<String, Map<String, Long>>>(emptyMap())

    override fun observeSearchHistory(userId: String): Flow<List<String>> {
        val key = normalizeUserKey(userId)
        return historyByUser.map { it[key].orEmpty() }
    }

    override fun recordSearchQuery(userId: String, query: String) {
        val clean = query.trim()
        if (clean.length < 2) return
        val key = normalizeUserKey(userId)
        historyByUser.update { map ->
            val current = map[key].orEmpty()
            val updated = (listOf(clean) + current.filterNot { it.equals(clean, ignoreCase = true) })
                .take(maxHistoryItems)
            map + (key to updated)
        }
    }

    override fun removeSearchQuery(userId: String, query: String) {
        val clean = query.trim()
        val key = normalizeUserKey(userId)
        historyByUser.update { map ->
            val current = map[key].orEmpty()
            map + (key to current.filterNot { it.equals(clean, ignoreCase = true) })
        }
    }

    override fun clearSearchHistory(userId: String) {
        val key = normalizeUserKey(userId)
        historyByUser.update { map -> map - key }
    }

    override fun observeConversationLastReadMillis(userId: String): Flow<Map<String, Long>> {
        val key = normalizeUserKey(userId)
        return readMillisByUser.map { it[key].orEmpty() }
    }

    override fun markConversationRead(userId: String, conversationId: String, timestampMillis: Long) {
        if (conversationId.isBlank()) return
        val key = normalizeUserKey(userId)
        val safeMillis = maxOf(1L, timestampMillis)
        readMillisByUser.update { map ->
            val current = map[key].orEmpty()
            val prev = current[conversationId] ?: 0L
            if (safeMillis <= prev) map else map + (key to (current + (conversationId to safeMillis)))
        }
    }

    private fun normalizeUserKey(userId: String): String = userId.ifBlank { GUEST_KEY }

    private companion object {
        const val GUEST_KEY = "_guest_"
    }
}

class SharedPreferencesMarketplaceLocalStore(
    context: Context,
    private val maxHistoryItems: Int = 8
) : MarketplaceLocalStore {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val historyByUser = MutableStateFlow<Map<String, List<String>>>(loadAllSearchHistories())
    private val readMillisByUser = MutableStateFlow<Map<String, Map<String, Long>>>(loadAllReadTimestamps())

    override fun observeSearchHistory(userId: String): Flow<List<String>> {
        val key = normalizeUserKey(userId)
        return historyByUser.map { it[key].orEmpty() }
    }

    override fun recordSearchQuery(userId: String, query: String) {
        val clean = query.trim()
        if (clean.length < 2) return
        val key = normalizeUserKey(userId)
        historyByUser.update { map ->
            val current = map[key].orEmpty()
            val updated = (listOf(clean) + current.filterNot { it.equals(clean, ignoreCase = true) })
                .take(maxHistoryItems)
            persistSearchHistory(key, updated)
            map + (key to updated)
        }
    }

    override fun removeSearchQuery(userId: String, query: String) {
        val clean = query.trim()
        val key = normalizeUserKey(userId)
        historyByUser.update { map ->
            val updated = map[key].orEmpty().filterNot { it.equals(clean, ignoreCase = true) }
            persistSearchHistory(key, updated)
            map + (key to updated)
        }
    }

    override fun clearSearchHistory(userId: String) {
        val key = normalizeUserKey(userId)
        historyByUser.update { map ->
            prefs.edit().remove(HISTORY_PREFIX + key).apply()
            map - key
        }
    }

    override fun observeConversationLastReadMillis(userId: String): Flow<Map<String, Long>> {
        val key = normalizeUserKey(userId)
        return readMillisByUser.map { it[key].orEmpty() }
    }

    override fun markConversationRead(userId: String, conversationId: String, timestampMillis: Long) {
        if (conversationId.isBlank()) return
        val key = normalizeUserKey(userId)
        val safeMillis = maxOf(1L, timestampMillis)
        readMillisByUser.update { map ->
            val current = map[key].orEmpty()
            val prev = current[conversationId] ?: 0L
            if (safeMillis <= prev) {
                map
            } else {
                val updated = current + (conversationId to safeMillis)
                persistReadMap(key, updated)
                map + (key to updated)
            }
        }
    }

    private fun persistSearchHistory(userKey: String, items: List<String>) {
        val array = JSONArray()
        items.forEach { array.put(it) }
        prefs.edit().putString(HISTORY_PREFIX + userKey, array.toString()).apply()
    }

    private fun persistReadMap(userKey: String, values: Map<String, Long>) {
        val obj = JSONObject()
        values.forEach { (convId, ts) -> obj.put(convId, ts) }
        prefs.edit().putString(READ_PREFIX + userKey, obj.toString()).apply()
    }

    private fun loadAllSearchHistories(): Map<String, List<String>> {
        val result = mutableMapOf<String, List<String>>()
        prefs.all.forEach { (prefKey, value) ->
            if (prefKey.startsWith(HISTORY_PREFIX) && value is String) {
                val userKey = prefKey.removePrefix(HISTORY_PREFIX)
                val list = runCatching {
                    val arr = JSONArray(value)
                    buildList {
                        for (i in 0 until arr.length()) {
                            arr.optString(i).takeIf { it.isNotBlank() }?.let { add(it) }
                        }
                    }
                }.getOrDefault(emptyList())
                result[userKey] = list
            }
        }
        return result
    }

    private fun loadAllReadTimestamps(): Map<String, Map<String, Long>> {
        val result = mutableMapOf<String, Map<String, Long>>()
        prefs.all.forEach { (prefKey, value) ->
            if (prefKey.startsWith(READ_PREFIX) && value is String) {
                val userKey = prefKey.removePrefix(READ_PREFIX)
                val map = runCatching {
                    val obj = JSONObject(value)
                    buildMap {
                        val keys = obj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            put(k, obj.optLong(k, 0L))
                        }
                    }
                }.getOrDefault(emptyMap())
                result[userKey] = map
            }
        }
        return result
    }

    private fun normalizeUserKey(userId: String): String = userId.ifBlank { GUEST_KEY }

    private companion object {
        const val PREFS_NAME = "ekashbuy_local_prefs"
        const val HISTORY_PREFIX = "search_history_"
        const val READ_PREFIX = "conv_read_"
        const val GUEST_KEY = "_guest_"
    }
}
