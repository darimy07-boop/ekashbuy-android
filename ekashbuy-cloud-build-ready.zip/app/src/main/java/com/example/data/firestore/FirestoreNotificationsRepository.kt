package com.example.data.firestore

import com.example.data.firestore.model.FirestoreCollections
import com.example.data.firestore.model.FirestoreNotification
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface NotificationsRepository {
    fun observeUserNotifications(userId: String): Flow<List<FirestoreNotification>>
    suspend fun createNotification(notification: FirestoreNotification): Result<String>
    suspend fun markAsRead(notificationId: String): Result<Unit>
    suspend fun deleteNotification(notificationId: String): Result<Unit>
}

class FirestoreNotificationsRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : NotificationsRepository {

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing notifications.")
    }

    override fun observeUserNotifications(userId: String): Flow<List<FirestoreNotification>> = flow {
        val query = db.collection(FirestoreCollections.NOTIFICATIONS)
            .whereEqualTo("userId", userId)

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreNotification::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(
                            firestoreError ?: error,
                            OperationType.LIST,
                            FirestoreCollections.NOTIFICATIONS,
                            auth
                        )
                    }
                    throw error
                }
        )
    }

    override suspend fun createNotification(notification: FirestoreNotification): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val docRef = db.collection(FirestoreCollections.NOTIFICATIONS).document()
        return try {
            docRef.set(notification.toCreateMap(uid)).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun markAsRead(notificationId: String): Result<Unit> {
        try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val docRef = db.collection(FirestoreCollections.NOTIFICATIONS).document(notificationId)
        return try {
            docRef.update(mapOf("isRead" to true)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun deleteNotification(notificationId: String): Result<Unit> {
        try {
            requireUserId()
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        val docRef = db.collection(FirestoreCollections.NOTIFICATIONS).document(notificationId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }
}
