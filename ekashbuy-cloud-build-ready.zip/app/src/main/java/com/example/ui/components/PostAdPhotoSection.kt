package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.media.MAX_AD_PHOTOS
import com.example.model.SelectedAdPhoto
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange

@Composable
fun PostAdPhotoSection(
    selectedPhotos: List<SelectedAdPhoto>,
    photoError: String?,
    enabled: Boolean,
    onAddPhotosClick: () -> Unit,
    onRemovePhoto: (Int) -> Unit,
    onMovePhoto: (fromIndex: Int, toIndex: Int) -> Unit,
    onSetMainPhoto: (Int) -> Unit,
    onDismissPhotoError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val count = selectedPhotos.size
    val isFull = count >= MAX_AD_PHOTOS

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Section Header + Image Count Indicator (e.g. 3/6)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Product Photos",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (selectedPhotos.isEmpty()) {
                        "Add up to $MAX_AD_PHOTOS images using Android Photo Picker"
                    } else {
                        "Photo #1 is the main cover photo • Use arrows or ★ to reorder"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = when {
                    isFull -> EmeraldContainer
                    count > 0 -> RoyalBlueContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                border = BorderStroke(
                    1.dp,
                    when {
                        isFull -> EmeraldBadge.copy(alpha = 0.45f)
                        count > 0 -> RoyalBlue.copy(alpha = 0.35f)
                        else -> MaterialTheme.colorScheme.outline
                    }
                ),
                modifier = Modifier
                    .semantics(mergeDescendants = true) {}
                    .testTag("post_ad_photo_count_indicator")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.PhotoLibrary,
                        contentDescription = null,
                        tint = when {
                            isFull -> EmeraldBadge
                            count > 0 -> RoyalBlue
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "$count/$MAX_AD_PHOTOS",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = when {
                            isFull -> EmeraldBadge
                            count > 0 -> RoyalBlue
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }
        }

        // Validation / Selection Error Banner
        AnimatedVisibility(visible = photoError != null) {
            photoError?.let { message ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_ad_photo_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ErrorOutline,
                            contentDescription = "Photo selection warning",
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onDismissPhotoError,
                            modifier = Modifier.testTag("post_ad_photo_error_dismiss")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Dismiss photo warning",
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        if (selectedPhotos.isEmpty()) {
            // Empty Photo Picker Dropzone Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .clickable(enabled = enabled, onClick = onAddPhotosClick)
                    .testTag("post_ad_photo_picker"),
                shape = MaterialTheme.shapes.medium,
                color = RoyalBlueContainer.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = RoyalBlue
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AddPhotoAlternate,
                            contentDescription = "Select photos",
                            tint = Color.White,
                            modifier = Modifier
                                .padding(12.dp)
                                .size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Add Photos (Up to $MAX_AD_PHOTOS)",
                            style = MaterialTheme.typography.titleSmall,
                            color = RoyalBlue
                        )
                        Text(
                            text = "Select images from your gallery • Local preview only (cloud uploads coming later)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // 3-Column Preview Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_ad_photo_grid"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val rows = selectedPhotos.chunked(3)
                rows.forEachIndexed { rowIndex, rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEachIndexed { colIndex, photo ->
                            val globalIndex = rowIndex * 3 + colIndex
                            PhotoPreviewTile(
                                photo = photo,
                                index = globalIndex,
                                totalCount = selectedPhotos.size,
                                enabled = enabled,
                                onRemove = { onRemovePhoto(globalIndex) },
                                onMoveLeft = { onMovePhoto(globalIndex, globalIndex - 1) },
                                onMoveRight = { onMovePhoto(globalIndex, globalIndex + 1) },
                                onSetMain = { onSetMainPhoto(globalIndex) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(3 - rowItems.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Add More / Max Status Button + Local Preview Info
            OutlinedButton(
                onClick = onAddPhotosClick,
                enabled = enabled && !isFull,
                border = BorderStroke(
                    1.dp,
                    if (isFull) MaterialTheme.colorScheme.outline else RoyalBlue
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("post_ad_add_more_photos_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.AddPhotoAlternate,
                    contentDescription = null,
                    tint = if (isFull) MaterialTheme.colorScheme.onSurfaceVariant else RoyalBlue,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isFull) {
                        "Maximum $MAX_AD_PHOTOS/$MAX_AD_PHOTOS Photos Selected"
                    } else {
                        "Add More Photos (${MAX_AD_PHOTOS - count} remaining)"
                    },
                    color = if (isFull) MaterialTheme.colorScheme.onSurfaceVariant else RoyalBlue
                )
            }

            Text(
                text = if (isFull) {
                    "Limit reached ($MAX_AD_PHOTOS/$MAX_AD_PHOTOS). Remove a photo to select another. Previews stay local."
                } else {
                    "Local preview only • Selected photos are not uploaded to Firebase Storage yet."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PhotoPreviewTile(
    photo: SelectedAdPhoto,
    index: Int,
    totalCount: Int,
    enabled: Boolean,
    onRemove: () -> Unit,
    onMoveLeft: () -> Unit,
    onMoveRight: () -> Unit,
    onSetMain: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isMain = index == 0
    var loadFailed by remember(photo.uriString) { mutableStateOf(false) }

    Surface(
        modifier = modifier.testTag("post_ad_photo_item_$index"),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isMain) 2.dp else 1.dp,
            color = if (isMain) RoyalBlue else MaterialTheme.colorScheme.outline
        ),
        tonalElevation = if (isMain) 2.dp else 0.dp
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(RoyalBlueContainer.copy(alpha = 0.35f))
            ) {
                if (!loadFailed) {
                    AsyncImage(
                        model = Uri.parse(photo.uriString),
                        contentDescription = if (isMain) {
                            "Main product photo ${photo.displayName}".trim()
                        } else {
                            "Product photo ${index + 1} ${photo.displayName}".trim()
                        },
                        contentScale = ContentScale.Crop,
                        onError = { loadFailed = true },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BrokenImage,
                            contentDescription = "Image preview unavailable",
                            tint = RoyalBlue,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = photo.displayName.ifBlank { "Photo #${index + 1}" },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Main Photo or Index Pill Badge
                if (isMain) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = VibrantOrange,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .testTag("post_ad_main_photo_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = "Main image",
                                tint = Color.White,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "MAIN",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.68f),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .testTag("post_ad_photo_index_badge_$index")
                    ) {
                        Text(
                            text = "#${index + 1}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Remove Button with 48dp touch target
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .minimumInteractiveComponentSize()
                        .clickable(enabled = enabled, onClick = onRemove)
                        .testTag("post_ad_photo_remove_$index"),
                    contentAlignment = Alignment.TopEnd
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.72f),
                        modifier = Modifier
                            .padding(5.dp)
                            .size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Remove photo ${index + 1}",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            // Reorder & Set-Main Toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isMain) RoyalBlueContainer.copy(alpha = 0.7f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onMoveLeft,
                    enabled = enabled && index > 0,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("post_ad_photo_move_left_$index")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Move photo ${index + 1} earlier",
                        tint = if (enabled && index > 0) RoyalBlue else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onSetMain,
                    enabled = enabled && !isMain,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("post_ad_photo_set_main_$index")
                ) {
                    Icon(
                        imageVector = if (isMain) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = if (isMain) "Main listing photo" else "Make photo ${index + 1} main",
                        tint = if (isMain) VibrantOrange else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = onMoveRight,
                    enabled = enabled && index < totalCount - 1,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("post_ad_photo_move_right_$index")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Move photo ${index + 1} later",
                        tint = if (enabled && index < totalCount - 1) RoyalBlue else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
