package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.MyAdsScreen
import com.example.ui.screens.PostAdScreen
import com.example.ui.screens.ProductDetailsScreen
import com.example.ui.screens.ProductListingsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RegistrationScreen
import com.example.ui.state.AuthViewModel
import com.example.ui.state.MarketplaceViewModel
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange

object EkashbuyRoutes {
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val SELL = "sell"
    const val MESSAGES = "messages"
    const val PROFILE = "profile"
    const val LISTINGS = "listings"
    const val PRODUCT_DETAILS = "product_details/{productId}"
    const val MY_ADS = "my_ads"
    const val MY_ADS_ROUTE = "my_ads?tab={tab}"
    const val LOGIN = "login"
    const val REGISTER = "register"

    fun productDetailsRoute(productId: String): String = "product_details/$productId"
    fun myAdsRoute(tab: Int = 0): String = "my_ads?tab=$tab"
}

private data class BottomNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val isSellTab: Boolean = false
)

private val bottomNavTabs = listOf(
    BottomNavTab(
        route = EkashbuyRoutes.HOME,
        label = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    ),
    BottomNavTab(
        route = EkashbuyRoutes.CATEGORIES,
        label = "Categories",
        selectedIcon = Icons.Filled.GridView,
        unselectedIcon = Icons.Outlined.GridView
    ),
    BottomNavTab(
        route = EkashbuyRoutes.SELL,
        label = "Sell",
        selectedIcon = Icons.Filled.AddCircle,
        unselectedIcon = Icons.Outlined.AddCircleOutline,
        isSellTab = true
    ),
    BottomNavTab(
        route = EkashbuyRoutes.MESSAGES,
        label = "Messages",
        selectedIcon = Icons.Filled.ChatBubble,
        unselectedIcon = Icons.Outlined.ChatBubbleOutline
    ),
    BottomNavTab(
        route = EkashbuyRoutes.PROFILE,
        label = "Profile",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.PersonOutline
    )
)

@Composable
fun EkashbuyApp(
    viewModel: MarketplaceViewModel,
    authViewModel: AuthViewModel,
    navController: NavHostController = rememberNavController()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val authState by authViewModel.uiState.collectAsStateWithLifecycle()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val topLevelRoutes = bottomNavTabs.map { it.route }.toSet()
    val showBottomBar = currentDestination?.route in topLevelRoutes

    val navigateToTopTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (showBottomBar && !useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 3.dp
                    ) {
                        bottomNavTabs.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTopTab(tab.route) },
                                modifier = Modifier.testTag("bottom_nav_${tab.route}"),
                                icon = {
                                    val iconContent: @Composable () -> Unit = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label,
                                            tint = when {
                                                tab.isSellTab -> VibrantOrange
                                                selected -> RoyalBlue
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                    if (tab.route == EkashbuyRoutes.MESSAGES && uiState.unreadConversationsCount > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge(
                                                    containerColor = VibrantOrange,
                                                    modifier = Modifier.testTag("messages_unread_badge")
                                                ) {
                                                    Text(
                                                        text = uiState.unreadConversationsCount.toString(),
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        ) {
                                            iconContent()
                                        }
                                    } else {
                                        iconContent()
                                    }
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontWeight = if (selected || tab.isSellTab) FontWeight.SemiBold else FontWeight.Normal,
                                        color = when {
                                            tab.isSellTab -> VibrantOrange
                                            selected -> RoyalBlue
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = if (tab.isSellTab) VibrantOrange.copy(alpha = 0.14f) else RoyalBlueContainer
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showBottomBar && useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        bottomNavTabs.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTopTab(tab.route) },
                                icon = {
                                    val iconContent: @Composable () -> Unit = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label,
                                            tint = if (tab.isSellTab) VibrantOrange else if (selected) RoyalBlue else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (tab.route == EkashbuyRoutes.MESSAGES && uiState.unreadConversationsCount > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge(
                                                    containerColor = VibrantOrange,
                                                    modifier = Modifier.testTag("messages_unread_badge")
                                                ) {
                                                    Text(
                                                        text = uiState.unreadConversationsCount.toString(),
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        ) {
                                            iconContent()
                                        }
                                    } else {
                                        iconContent()
                                    }
                                },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    indicatorColor = if (tab.isSellTab) VibrantOrange.copy(alpha = 0.14f) else RoyalBlueContainer
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = EkashbuyRoutes.HOME
                    ) {
                        composable(EkashbuyRoutes.HOME) {
                            HomeScreen(
                                uiState = uiState,
                                onSelectHomeDistrict = viewModel::setHomeDistrict,
                                onHomeSearchChange = viewModel::setHomeSearchQuery,
                                onSubmitSearchToListings = { query ->
                                    viewModel.recordSearchQuery(query)
                                    viewModel.applyListingShortcut(query = query)
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                },
                                onOpenCategories = { navigateToTopTab(EkashbuyRoutes.CATEGORIES) },
                                onCategoryClick = { category ->
                                    viewModel.applyListingShortcut(category = category)
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                },
                                onOpenAllListings = {
                                    viewModel.applyListingShortcut(query = uiState.homeSearchQuery)
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                },
                                onProductClick = { productId ->
                                    navController.navigate(EkashbuyRoutes.productDetailsRoute(productId))
                                },
                                onToggleFavorite = viewModel::toggleFavorite,
                                onOpenMyAds = { navController.navigate(EkashbuyRoutes.myAdsRoute(0)) },
                                onOpenSell = { navigateToTopTab(EkashbuyRoutes.SELL) },
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                },
                                onRetryListings = viewModel::retryListings,
                                onClearMessages = viewModel::clearAdMessages,
                                onSelectSearchHistory = { query ->
                                    viewModel.recordSearchQuery(query)
                                    viewModel.applyListingShortcut(query = query)
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                },
                                onRemoveSearchHistory = viewModel::removeSearchHistoryItem,
                                onClearSearchHistory = viewModel::clearSearchHistory
                            )
                        }

                        composable(EkashbuyRoutes.CATEGORIES) {
                            CategoriesScreen(
                                uiState = uiState,
                                onCategorySelected = { category ->
                                    viewModel.applyListingShortcut(category = category)
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                },
                                onBrowseAllAds = {
                                    viewModel.resetFilters()
                                    navController.navigate(EkashbuyRoutes.LISTINGS)
                                }
                            )
                        }

                        composable(EkashbuyRoutes.SELL) {
                            PostAdScreen(
                                uiState = uiState,
                                onUpdateDraft = viewModel::updatePostAdDraft,
                                onResetDraft = viewModel::resetPostAdDraft,
                                onSubmitListing = { title, priceText, isMonthlyRent, negotiable, category, district, locality, condition, description, sellerName, sellerPhone ->
                                    viewModel.submitListing(
                                        title = title,
                                        priceText = priceText,
                                        isMonthlyRent = isMonthlyRent,
                                        negotiable = negotiable,
                                        category = category,
                                        district = district,
                                        locality = locality,
                                        condition = condition,
                                        description = description,
                                        sellerName = sellerName,
                                        sellerPhone = sellerPhone,
                                        onSuccess = {
                                            navController.navigate(EkashbuyRoutes.myAdsRoute(0)) {
                                                launchSingleTop = true
                                            }
                                        }
                                    )
                                },
                                onAddPhotoCandidates = viewModel::addSelectedPhotoCandidates,
                                onRemovePhoto = viewModel::removeSelectedPhoto,
                                onMovePhoto = viewModel::moveSelectedPhoto,
                                onSetMainPhoto = viewModel::setMainSelectedPhoto,
                                onPhotoError = viewModel::setPhotoSelectionError,
                                onClearMessages = viewModel::clearAdMessages,
                                onOpenMyAds = { navController.navigate(EkashbuyRoutes.myAdsRoute(0)) },
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                }
                            )
                        }

                        composable(EkashbuyRoutes.MESSAGES) {
                            MessagesScreen(
                                uiState = uiState,
                                onOpenProductDetails = { productId ->
                                    navController.navigate(EkashbuyRoutes.productDetailsRoute(productId))
                                },
                                onSelectConversation = viewModel::selectConversation,
                                onSendMessage = viewModel::sendChatMessage,
                                onRetryConversations = viewModel::retryConversations,
                                onClearMessageErrors = viewModel::clearMessageErrors,
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                }
                            )
                        }

                        composable(EkashbuyRoutes.PROFILE) {
                            ProfileScreen(
                                uiState = uiState,
                                authState = authState,
                                onSelectHomeDistrict = viewModel::setHomeDistrict,
                                onOpenMyAds = { navController.navigate(EkashbuyRoutes.myAdsRoute(0)) },
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                },
                                onSignOut = authViewModel::signOut,
                                onOpenSavedFavorites = { navController.navigate(EkashbuyRoutes.myAdsRoute(2)) },
                                onUpdateProfile = { displayName, mobileNumber, district, locality, onSuccess ->
                                    authViewModel.updateUserProfile(
                                        displayName = displayName,
                                        mobileNumber = mobileNumber,
                                        district = district,
                                        locality = locality,
                                        onSuccess = onSuccess
                                    )
                                },
                                onClearAuthMessages = authViewModel::clearMessages
                            )
                        }

                        composable(EkashbuyRoutes.LISTINGS) {
                            ProductListingsScreen(
                                uiState = uiState,
                                onUpdateFilters = viewModel::updateFilters,
                                onResetFilters = viewModel::resetFilters,
                                onProductClick = { productId ->
                                    navController.navigate(EkashbuyRoutes.productDetailsRoute(productId))
                                },
                                onToggleFavorite = viewModel::toggleFavorite,
                                onNavigateBack = { navController.popBackStack() },
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                },
                                onRetryListings = viewModel::retryListings,
                                onOpenSell = { navigateToTopTab(EkashbuyRoutes.SELL) },
                                onClearMessages = viewModel::clearAdMessages,
                                onRecordSearchQuery = viewModel::recordSearchQuery,
                                onRemoveSearchHistory = viewModel::removeSearchHistoryItem,
                                onClearSearchHistory = viewModel::clearSearchHistory
                            )
                        }

                        composable(
                            route = EkashbuyRoutes.PRODUCT_DETAILS,
                            arguments = listOf(navArgument("productId") { type = NavType.StringType })
                        ) { entry ->
                            val productId = entry.arguments?.getString("productId") ?: ""
                            val listing = uiState.allListings.firstOrNull { it.id == productId }
                                ?: uiState.myListings.firstOrNull { it.id == productId }
                            val isOwnListing = listing != null &&
                                uiState.currentUserId != null &&
                                listing.sellerId == uiState.currentUserId
                            ProductDetailsScreen(
                                listing = listing,
                                isLoading = uiState.isListingsLoading,
                                isOwnListing = isOwnListing,
                                isDeleting = uiState.deletingListingId == productId,
                                isFavorite = productId in uiState.favoriteIds,
                                onToggleFavorite = { viewModel.toggleFavorite(productId) },
                                onNavigateBack = { navController.popBackStack() },
                                onOpenMessagesPreview = {
                                    navigateToTopTab(EkashbuyRoutes.MESSAGES)
                                },
                                onEditListing = { item ->
                                    viewModel.startEditingListing(item)
                                    navigateToTopTab(EkashbuyRoutes.SELL)
                                },
                                onDeleteListing = { id ->
                                    viewModel.deleteListing(id) {
                                        navController.popBackStack()
                                    }
                                },
                                isAuthenticated = uiState.isAuthenticated,
                                actionError = uiState.adActionError,
                                actionSuccess = uiState.adActionSuccessMessage,
                                onClearMessages = viewModel::clearAdMessages,
                                onUpdateStatus = viewModel::updateListingStatus,
                                isUpdatingStatus = uiState.updatingStatusListingId == productId,
                                onStartConversation = { item, messageText ->
                                    viewModel.startConversation(item, messageText) {
                                        navigateToTopTab(EkashbuyRoutes.MESSAGES)
                                    }
                                },
                                isStartingConversation = uiState.isStartingConversation,
                                messageActionError = uiState.messageActionError,
                                onClearMessageErrors = viewModel::clearMessageErrors,
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                }
                            )
                        }

                        composable(
                            route = EkashbuyRoutes.MY_ADS_ROUTE,
                            arguments = listOf(
                                navArgument("tab") {
                                    type = NavType.IntType
                                    defaultValue = 0
                                }
                            )
                        ) { entry ->
                            val initialTab = entry.arguments?.getInt("tab") ?: 0
                            MyAdsScreen(
                                uiState = uiState,
                                onNavigateBack = { navController.popBackStack() },
                                onOpenSell = {
                                    viewModel.resetPostAdDraft()
                                    navigateToTopTab(EkashbuyRoutes.SELL)
                                },
                                onProductClick = { productId ->
                                    navController.navigate(EkashbuyRoutes.productDetailsRoute(productId))
                                },
                                onEditListing = { item ->
                                    viewModel.startEditingListing(item)
                                    navigateToTopTab(EkashbuyRoutes.SELL)
                                },
                                onUpdateStatus = viewModel::updateListingStatus,
                                onDeleteListing = { id -> viewModel.deleteListing(id) },
                                onToggleFavorite = viewModel::toggleFavorite,
                                onRetryMyAds = viewModel::retryListings,
                                onClearMessages = viewModel::clearAdMessages,
                                onOpenLogin = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.LOGIN)
                                },
                                onOpenRegister = {
                                    authViewModel.clearMessages()
                                    navController.navigate(EkashbuyRoutes.REGISTER)
                                },
                                initialTab = initialTab
                            )
                        }

                        composable(EkashbuyRoutes.LOGIN) {
                            LoginScreen(
                                authState = authState,
                                onSignInWithEmail = authViewModel::signInWithEmail,
                                onRequestPhoneOtp = { activity, phone, isResend ->
                                    authViewModel.requestPhoneOtp(
                                        activity = activity,
                                        rawPhone = phone,
                                        isResend = isResend
                                    )
                                },
                                onVerifyOtp = { code -> authViewModel.verifyOtp(otpCode = code) },
                                onResetOtpFlow = authViewModel::resetOtpFlow,
                                onClearMessages = authViewModel::clearMessages,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToRegister = {
                                    navController.navigate(EkashbuyRoutes.REGISTER) {
                                        popUpTo(EkashbuyRoutes.LOGIN) { inclusive = true }
                                    }
                                },
                                onAuthSuccess = { navController.popBackStack() }
                            )
                        }

                        composable(EkashbuyRoutes.REGISTER) {
                            RegistrationScreen(
                                authState = authState,
                                onRegisterWithEmail = authViewModel::registerWithEmail,
                                onRequestPhoneOtp = { activity, phone, isResend, fullName, district ->
                                    authViewModel.requestPhoneOtp(
                                        activity = activity,
                                        rawPhone = phone,
                                        isResend = isResend,
                                        fullName = fullName,
                                        district = district
                                    )
                                },
                                onVerifyOtpWithProfile = { code, fullName, district ->
                                    authViewModel.verifyOtp(
                                        otpCode = code,
                                        fullName = fullName,
                                        district = district
                                    )
                                },
                                onResetOtpFlow = authViewModel::resetOtpFlow,
                                onClearMessages = authViewModel::clearMessages,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToLogin = {
                                    navController.navigate(EkashbuyRoutes.LOGIN) {
                                        popUpTo(EkashbuyRoutes.REGISTER) { inclusive = true }
                                    }
                                },
                                onAuthSuccess = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
