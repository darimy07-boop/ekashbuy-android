package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.model.KashmirDistrict
import com.example.ui.components.EkashbuyBrandMark
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.AuthUiState
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange
import kotlinx.coroutines.flow.drop

private enum class AuthMethodTab {
    PHONE_OTP,
    EMAIL_PASSWORD
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    authState: AuthUiState,
    onSignInWithEmail: (email: String, password: String) -> Unit,
    onRequestPhoneOtp: (activity: Activity?, phone: String, isResend: Boolean) -> Unit,
    onVerifyOtp: (otpCode: String) -> Unit,
    onResetOtpFlow: () -> Unit,
    onClearMessages: () -> Unit,
    onNavigateBack: () -> Unit,
    onNavigateToRegister: () -> Unit,
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    var selectedTab by rememberSaveable { mutableStateOf(AuthMethodTab.PHONE_OTP) }
    var phoneValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var otpValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var emailValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var passwordValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(authState.currentUser, authState.isLoading, authState.isSyncingProfile) {
        if (authState.currentUser != null && !authState.isLoading && !authState.isSyncingProfile) {
            onAuthSuccess()
        }
    }

    // Clear error/info banners asynchronously when user edits any field instead of inside onValueChange
    LaunchedEffect(Unit) {
        snapshotFlow {
            listOf(
                phoneValue.text,
                otpValue.text,
                emailValue.text,
                passwordValue.text
            )
        }
            .drop(1)
            .collect {
                onClearMessages()
            }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Sign In") },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            onClearMessages()
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("login_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            EkashbuyBrandMark()

            Column {
                Text(
                    text = "Welcome back to eKashbuy",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Sign in with your mobile OTP or email to manage your Kashmir listings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AuthMethodSwitcher(
                selectedTab = selectedTab,
                onSelectTab = { tab ->
                    if (selectedTab != tab) {
                        selectedTab = tab
                        onClearMessages()
                        if (tab != AuthMethodTab.PHONE_OTP) {
                            otpValue = TextFieldValue("")
                            onResetOtpFlow()
                        }
                    }
                }
            )

            if (!(selectedTab == AuthMethodTab.PHONE_OTP && authState.otpCodeSent)) {
                authState.errorMessage?.let { error ->
                    AuthStatusBanner(
                        message = error,
                        isError = true,
                        testTag = "login_error_banner"
                    )
                }

                authState.infoMessage?.let { info ->
                    AuthStatusBanner(
                        message = info,
                        isError = false,
                        testTag = "login_info_banner"
                    )
                }
            }

            if (selectedTab == AuthMethodTab.PHONE_OTP) {
                EkashbuyOutlinedTextField(
                    value = phoneValue,
                    onValueChange = { incoming ->
                        phoneValue = TextFieldInputSanitizers.sanitizePhone(incoming)
                    },
                    label = "Mobile Number",
                    placeholder = "+91 9XXXXXXXXX or 10-digit mobile",
                    leadingIcon = {
                        Icon(imageVector = Icons.Outlined.Phone, contentDescription = null)
                    },
                    enabled = !authState.isLoading && !authState.otpCodeSent,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Done
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_phone_input")
                )

                if (authState.otpCodeSent) {
                    authState.errorMessage?.let { error ->
                        AuthStatusBanner(
                            message = error,
                            isError = true,
                            testTag = "login_error_banner"
                        )
                    }

                    authState.infoMessage?.let { info ->
                        AuthStatusBanner(
                            message = info,
                            isError = false,
                            testTag = "login_info_banner"
                        )
                    }

                    EkashbuyOutlinedTextField(
                        value = otpValue,
                        onValueChange = { incoming ->
                            otpValue = TextFieldInputSanitizers.sanitizeDigits(incoming, maxLength = 6)
                        },
                        label = "6-Digit OTP",
                        placeholder = "Enter OTP sent to ${authState.otpPhoneDisplay}",
                        leadingIcon = {
                            Icon(imageVector = Icons.Outlined.Sms, contentDescription = null)
                        },
                        enabled = !authState.isLoading && !authState.isSyncingProfile,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.None,
                            autoCorrectEnabled = false,
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (!authState.isLoading && !authState.isSyncingProfile) {
                                    onVerifyOtp(otpValue.text)
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_otp_input")
                    )

                    Button(
                        onClick = { onVerifyOtp(otpValue.text) },
                        enabled = !authState.isLoading && !authState.isSyncingProfile,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalBlue,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_verify_otp_button")
                    ) {
                        if (authState.isLoading || authState.isSyncingProfile) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (authState.isSyncingProfile && !authState.isLoading) "Signing In…" else "Verifying OTP…")
                        } else {
                            Text("Verify & Sign In")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                otpValue = TextFieldValue("")
                                onRequestPhoneOtp(activity, phoneValue.text, true)
                            },
                            enabled = !authState.isLoading && !authState.isSyncingProfile && authState.canResendOtp,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("login_resend_otp_button")
                        ) {
                            Text("Resend OTP")
                        }
                        TextButton(
                            onClick = {
                                otpValue = TextFieldValue("")
                                onResetOtpFlow()
                            },
                            enabled = !authState.isLoading,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("login_change_number_button")
                        ) {
                            Text("Change Number", color = VibrantOrange)
                        }
                    }
                } else {
                    Button(
                        onClick = { onRequestPhoneOtp(activity, phoneValue.text, false) },
                        enabled = !authState.isLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalBlue,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_send_otp_button")
                    ) {
                        if (authState.isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sending OTP…")
                        } else {
                            Text("Send OTP")
                        }
                    }
                }
            } else {
                EkashbuyOutlinedTextField(
                    value = emailValue,
                    onValueChange = { emailValue = it },
                    label = "Email Address",
                    placeholder = "email@example.com",
                    leadingIcon = {
                        Icon(imageVector = Icons.Outlined.Email, contentDescription = null)
                    },
                    enabled = !authState.isLoading,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email_input")
                )

                AuthPasswordOutlinedTextField(
                    value = passwordValue,
                    onValueChange = { passwordValue = it },
                    label = "Password",
                    placeholder = null,
                    passwordVisible = passwordVisible,
                    onTogglePasswordVisibility = { passwordVisible = !passwordVisible },
                    enabled = !authState.isLoading,
                    imeAction = ImeAction.Done,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input")
                )

                Button(
                    onClick = {
                        onSignInWithEmail(emailValue.text, passwordValue.text)
                    },
                    enabled = !authState.isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RoyalBlue,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_submit_button")
                ) {
                    if (authState.isLoading) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Signing In…")
                    } else {
                        Text("Sign In")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "New to eKashbuy?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(
                    onClick = {
                        onClearMessages()
                        onResetOtpFlow()
                        onNavigateToRegister()
                    },
                    modifier = Modifier.testTag("login_to_register_button")
                ) {
                    Text("Create Account", color = VibrantOrange, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RegistrationScreen(
    authState: AuthUiState,
    onRegisterWithEmail: (
        fullName: String,
        email: String,
        phone: String,
        district: KashmirDistrict,
        password: String
    ) -> Unit,
    onRequestPhoneOtp: (
        activity: Activity?,
        phone: String,
        isResend: Boolean,
        fullName: String,
        district: KashmirDistrict
    ) -> Unit,
    onVerifyOtpWithProfile: (otpCode: String, fullName: String, district: KashmirDistrict) -> Unit,
    onResetOtpFlow: () -> Unit,
    onClearMessages: () -> Unit,
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    var selectedTab by rememberSaveable { mutableStateOf(AuthMethodTab.EMAIL_PASSWORD) }
    var fullNameValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var emailValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var phoneValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var selectedDistrictName by rememberSaveable { mutableStateOf(KashmirDistrict.SRINAGAR.name) }
    val selectedDistrict = remember(selectedDistrictName) {
        KashmirDistrict.entries.firstOrNull { it.name == selectedDistrictName } ?: KashmirDistrict.SRINAGAR
    }
    var passwordValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var otpValue by rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }

    LaunchedEffect(authState.currentUser, authState.isLoading, authState.isSyncingProfile) {
        if (authState.currentUser != null && !authState.isLoading && !authState.isSyncingProfile) {
            onAuthSuccess()
        }
    }

    // Clear error/info banners asynchronously when user edits any field instead of inside onValueChange
    LaunchedEffect(Unit) {
        snapshotFlow {
            listOf(
                fullNameValue.text,
                emailValue.text,
                phoneValue.text,
                passwordValue.text,
                otpValue.text
            )
        }
            .drop(1)
            .collect {
                onClearMessages()
            }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Create Account") },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            onClearMessages()
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("register_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            EkashbuyBrandMark()

            Column {
                Text(
                    text = "Join eKashbuy Kashmir",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Post ordinary ads free with 0% commission across Kashmir.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AuthMethodSwitcher(
                selectedTab = selectedTab,
                onSelectTab = { tab ->
                    if (selectedTab != tab) {
                        selectedTab = tab
                        onClearMessages()
                        if (tab != AuthMethodTab.PHONE_OTP) {
                            otpValue = TextFieldValue("")
                            onResetOtpFlow()
                        }
                    }
                }
            )

            if (!(selectedTab == AuthMethodTab.PHONE_OTP && authState.otpCodeSent)) {
                authState.errorMessage?.let { error ->
                    AuthStatusBanner(
                        message = error,
                        isError = true,
                        testTag = "register_error_banner"
                    )
                }

                authState.infoMessage?.let { info ->
                    AuthStatusBanner(
                        message = info,
                        isError = false,
                        testTag = "register_info_banner"
                    )
                }
            }

            EkashbuyOutlinedTextField(
                value = fullNameValue,
                onValueChange = { fullNameValue = it },
                label = "Full Name",
                placeholder = null,
                leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null) },
                enabled = !authState.isLoading,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    autoCorrectEnabled = false,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("register_name_input")
            )

            EkashbuyOutlinedTextField(
                value = phoneValue,
                onValueChange = { incoming ->
                    phoneValue = TextFieldInputSanitizers.sanitizePhone(incoming)
                },
                label = "Mobile Number",
                placeholder = "+91 9XXXXXXXXX",
                leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = null) },
                enabled = !authState.isLoading && !(selectedTab == AuthMethodTab.PHONE_OTP && authState.otpCodeSent),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    autoCorrectEnabled = false,
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("register_phone_input")
            )

            Column {
                Text("Your District", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KashmirDistrict.entries.filter { it != KashmirDistrict.ALL }.forEach { dist ->
                        FilterChip(
                            selected = selectedDistrict == dist,
                            onClick = { selectedDistrictName = dist.name },
                            label = { Text(dist.displayName) },
                            modifier = Modifier.testTag("register_district_${dist.name.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            if (selectedTab == AuthMethodTab.EMAIL_PASSWORD) {
                EkashbuyOutlinedTextField(
                    value = emailValue,
                    onValueChange = { emailValue = it },
                    label = "Email Address",
                    placeholder = "email@example.com",
                    leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null) },
                    enabled = !authState.isLoading,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("register_email_input")
                )

                AuthPasswordOutlinedTextField(
                    value = passwordValue,
                    onValueChange = { passwordValue = it },
                    label = "Create Password",
                    placeholder = "Minimum 6 characters",
                    passwordVisible = passwordVisible,
                    onTogglePasswordVisibility = { passwordVisible = !passwordVisible },
                    enabled = !authState.isLoading,
                    imeAction = ImeAction.Done,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("register_password_input")
                )

                Button(
                    onClick = {
                        onRegisterWithEmail(
                            fullNameValue.text,
                            emailValue.text,
                            phoneValue.text,
                            selectedDistrict,
                            passwordValue.text
                        )
                    },
                    enabled = !authState.isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VibrantOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("register_submit_button")
                ) {
                    if (authState.isLoading) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Creating Account…")
                    } else {
                        Text("Create Account")
                    }
                }
            } else {
                if (authState.otpCodeSent) {
                    authState.errorMessage?.let { error ->
                        AuthStatusBanner(
                            message = error,
                            isError = true,
                            testTag = "register_error_banner"
                        )
                    }

                    authState.infoMessage?.let { info ->
                        AuthStatusBanner(
                            message = info,
                            isError = false,
                            testTag = "register_info_banner"
                        )
                    }

                    EkashbuyOutlinedTextField(
                        value = otpValue,
                        onValueChange = { incoming ->
                            otpValue = TextFieldInputSanitizers.sanitizeDigits(incoming, maxLength = 6)
                        },
                        label = "6-Digit OTP",
                        placeholder = "Enter OTP sent to ${authState.otpPhoneDisplay}",
                        leadingIcon = { Icon(Icons.Outlined.Sms, contentDescription = null) },
                        enabled = !authState.isLoading && !authState.isSyncingProfile,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.None,
                            autoCorrectEnabled = false,
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (!authState.isLoading && !authState.isSyncingProfile) {
                                    onVerifyOtpWithProfile(
                                        otpValue.text,
                                        fullNameValue.text,
                                        selectedDistrict
                                    )
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_otp_input")
                    )

                    Button(
                        onClick = {
                            onVerifyOtpWithProfile(
                                otpValue.text,
                                fullNameValue.text,
                                selectedDistrict
                            )
                        },
                        enabled = !authState.isLoading && !authState.isSyncingProfile,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VibrantOrange,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("register_verify_otp_button")
                    ) {
                        if (authState.isLoading || authState.isSyncingProfile) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (authState.isSyncingProfile && !authState.isLoading) "Creating Account…" else "Verifying OTP…")
                        } else {
                            Text("Verify OTP & Create Account")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                otpValue = TextFieldValue("")
                                onRequestPhoneOtp(
                                    activity,
                                    phoneValue.text,
                                    true,
                                    fullNameValue.text,
                                    selectedDistrict
                                )
                            },
                            enabled = !authState.isLoading && !authState.isSyncingProfile && authState.canResendOtp,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("register_resend_otp_button")
                        ) {
                            Text("Resend OTP")
                        }
                        TextButton(
                            onClick = {
                                otpValue = TextFieldValue("")
                                onResetOtpFlow()
                            },
                            enabled = !authState.isLoading,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("register_change_number_button")
                        ) {
                            Text("Change Number", color = RoyalBlue)
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            onRequestPhoneOtp(
                                activity,
                                phoneValue.text,
                                false,
                                fullNameValue.text,
                                selectedDistrict
                            )
                        },
                        enabled = !authState.isLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VibrantOrange,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("register_send_otp_button")
                    ) {
                        if (authState.isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sending OTP…")
                        } else {
                            Text("Send OTP to Register")
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Already registered?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(
                    onClick = {
                        onClearMessages()
                        onResetOtpFlow()
                        onNavigateToLogin()
                    },
                    modifier = Modifier.testTag("register_to_login_button")
                ) {
                    Text("Sign In", color = RoyalBlue, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AuthPasswordOutlinedTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    label: String,
    placeholder: String?,
    passwordVisible: Boolean,
    onTogglePasswordVisibility: () -> Unit,
    enabled: Boolean = true,
    imeAction: ImeAction = ImeAction.Done,
    modifier: Modifier = Modifier
) {
    EkashbuyOutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        placeholder = placeholder,
        leadingIcon = {
            Icon(imageVector = Icons.Outlined.Lock, contentDescription = null)
        },
        trailingIcon = {
            IconButton(onClick = onTogglePasswordVisibility) {
                Icon(
                    imageVector = if (passwordVisible) {
                        Icons.Outlined.VisibilityOff
                    } else {
                        Icons.Outlined.Visibility
                    },
                    contentDescription = if (passwordVisible) {
                        "Hide password"
                    } else {
                        "Show password"
                    }
                )
            }
        },
        enabled = enabled,
        visualTransformation = if (passwordVisible) {
            VisualTransformation.None
        } else {
            PasswordVisualTransformation()
        },
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None,
            autoCorrectEnabled = false,
            keyboardType = KeyboardType.Password,
            imeAction = imeAction
        ),
        modifier = modifier
    )
}

@Composable
private fun AuthMethodSwitcher(
    selectedTab: AuthMethodTab,
    onSelectTab: (AuthMethodTab) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = RoyalBlueContainer,
        border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            AuthMethodTabButton(
                label = "Phone OTP",
                selected = selectedTab == AuthMethodTab.PHONE_OTP,
                onClick = { onSelectTab(AuthMethodTab.PHONE_OTP) },
                testTag = "auth_tab_phone_otp",
                modifier = Modifier.weight(1f)
            )
            AuthMethodTabButton(
                label = "Email & Password",
                selected = selectedTab == AuthMethodTab.EMAIL_PASSWORD,
                onClick = { onSelectTab(AuthMethodTab.EMAIL_PASSWORD) },
                testTag = "auth_tab_email_password",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun AuthMethodTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) RoyalBlue else Color.Transparent,
            contentColor = if (selected) Color.White else RoyalBlue
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp
        ),
        modifier = modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun AuthStatusBanner(
    message: String,
    isError: Boolean,
    testTag: String
) {
    val containerColor = if (isError) MaterialTheme.colorScheme.errorContainer else EmeraldContainer
    val contentColor = if (isError) MaterialTheme.colorScheme.onErrorContainer else EmeraldBadge
    val borderColor = if (isError) MaterialTheme.colorScheme.error.copy(alpha = 0.4f) else EmeraldBadge.copy(alpha = 0.35f)
    val icon = if (isError) Icons.Outlined.ErrorOutline else Icons.Outlined.CheckCircle

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = if (isError) "Authentication error" else "Status update",
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = contentColor
            )
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
