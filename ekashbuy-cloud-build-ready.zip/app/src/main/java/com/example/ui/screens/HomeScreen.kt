package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AdCategory
import com.example.model.KashmirDistrict
import com.example.ui.components.AuthRequiredCard
import com.example.ui.components.BusinessRulesBanner
import com.example.ui.components.DistrictFilterChipRow
import com.example.ui.components.DistrictPickerBottomSheet
import com.example.ui.components.DistrictSelectorPill
import com.example.ui.components.EkashbuyBrandMark
import com.example.ui.components.EkashbuySearchBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.ProductListingCard
import com.example.ui.components.SearchHistoryStrip
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.VibrantOrange

@Composable
fun HomeScreen(
    uiState: MarketplaceUiState,
    onSelectHomeDistrict: (KashmirDistrict) -> Unit,
    onHomeSearchChange: (String) -> Unit,
    onSubmitSearchToListings: (String) -> Unit,
    onOpenCategories: () -> Unit,
    onCategoryClick: (AdCategory) -> Unit,
    onOpenAllListings: () -> Unit,
    onProductClick: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onOpenMyAds: () -> Unit,
    onOpenSell: () -> Unit,
    onOpenLogin: () -> Unit,
    onOpenRegister: () -> Unit,
    onRetryListings: () -> Unit,
    onClearMessages: () -> Unit = {},
    onSelectSearchHistory: (String) -> Unit = { onSubmitSearchToListings(it) },
    onRemoveSearchHistory: (String) -> Unit = {},
    onClearSearchHistory: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showDistrictSheet by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.adActionError, uiState.adActionSuccessMessage) {
        val message = uiState.adActionError ?: uiState.adActionSuccessMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
            onClearMessages()
        }
    }

    if (showDistrictSheet) {
        DistrictPickerBottomSheet(
            selectedDistrict = uiState.selectedHomeDistrict,
            districtCounts = uiState.districtCounts,
            onSelectDistrict = onSelectHomeDistrict,
            onDismiss = { showDistrictSheet = false }
        )
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val columns = if (maxWidth >= 840.dp) 3 else 2

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_lazy_column"),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Top Brand & Location Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EkashbuyBrandMark()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onOpenMyAds,
                            modifier = Modifier.testTag("home_my_ads_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Inventory2,
                                contentDescription = "My Ads",
                                tint = RoyalBlue
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        DistrictSelectorPill(
                            selectedDistrict = uiState.selectedHomeDistrict,
                            onClick = { showDistrictSheet = true }
                        )
                    }
                }
            }

            // Search Bar + Quick Filter Button
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EkashbuySearchBar(
                        query = uiState.homeSearchQuery,
                        onQueryChange = onHomeSearchChange,
                        onSearchSubmit = { onSubmitSearchToListings(uiState.homeSearchQuery) },
                        modifier = Modifier.weight(1f),
                        testTag = "home_search_input"
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = onOpenAllListings)
                            .testTag("home_filter_button"),
                        shape = RoundedCornerShape(14.dp),
                        color = RoyalBlue
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.Tune,
                                contentDescription = "Open all filters",
                                tint = Color.White
                            )
                        }
                    }
                }
                if (uiState.isAuthenticated && uiState.searchHistory.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    SearchHistoryStrip(
                        history = uiState.searchHistory,
                        onSelectQuery = { term ->
                            onHomeSearchChange(term)
                            onSelectSearchHistory(term)
                        },
                        onRemoveQuery = onRemoveSearchHistory,
                        onClearAll = onClearSearchHistory,
                        tagPrefix = "home_search_history"
                    )
                }
            }

            // Hero Kashmir Marketplace Banner
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .height(152.dp)
                        .clip(MaterialTheme.shapes.large)
                        .clickable(onClick = onOpenSell)
                        .testTag("home_hero_banner")
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_kashmir_banner),
                        contentDescription = "eKashbuy Kashmir marketplace banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        RoyalBlue.copy(alpha = 0.92f),
                                        RoyalBlue.copy(alpha = 0.72f),
                                        RoyalBlue.copy(alpha = 0.25f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = VibrantOrange
                            ) {
                                Text(
                                    text = "0% COMMISSION • DIRECT DEALS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Buy & Sell Across Kashmir",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Post ordinary ads for free in seconds",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                        Button(
                            onClick = onOpenSell,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VibrantOrange,
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("hero_post_ad_button")
                        ) {
                            Text(
                                text = "Post Free Ad",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // Categories Section
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Browse Categories",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(
                        onClick = onOpenCategories,
                        modifier = Modifier.testTag("home_see_all_categories")
                    ) {
                        Text("See all", color = RoyalBlue)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = RoyalBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(AdCategory.entries) { category ->
                        Surface(
                            modifier = Modifier
                                .width(92.dp)
                                .clip(MaterialTheme.shapes.medium)
                                .clickable { onCategoryClick(category) }
                                .testTag("home_category_${category.name.lowercase()}"),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = category.containerColor
                                ) {
                                    Icon(
                                        imageVector = category.icon,
                                        contentDescription = category.title,
                                        tint = category.tintColor,
                                        modifier = Modifier
                                            .padding(10.dp)
                                            .size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = category.shortTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // District Quick Filter Row
            item {
                Spacer(modifier = Modifier.height(16.dp))
                DistrictFilterChipRow(
                    selectedDistrict = uiState.selectedHomeDistrict,
                    onDistrictSelected = onSelectHomeDistrict
                )
            }

            // Fresh Recommendations Header
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (uiState.selectedHomeDistrict == KashmirDistrict.ALL) {
                                "Fresh Recommendations"
                            } else {
                                "Listings in ${uiState.selectedHomeDistrict.displayName}"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = when {
                                !uiState.isAuthenticated -> "Sign in to browse live Kashmir ads"
                                uiState.isListingsLoading -> "Loading ads from Firestore…"
                                uiState.homeListings.size == 1 -> "1 active local ad"
                                else -> "${uiState.homeListings.size} active local ads"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = onOpenAllListings,
                        modifier = Modifier.testTag("home_explore_all_listings")
                    ) {
                        Text("Filter & Sort", color = VibrantOrange)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Product Grid Rows / States
            when {
                !uiState.isAuthenticated -> {
                    item {
                        AuthRequiredCard(
                            title = "Sign in to browse live listings",
                            subtitle = "View active Kashmir classifieds, save favourites, and contact sellers directly.",
                            onOpenLogin = onOpenLogin,
                            onOpenRegister = onOpenRegister,
                            testTag = "home_signin_prompt"
                        )
                    }
                }

                uiState.isListingsLoading -> {
                    item {
                        LoadingStateView(
                            message = "Loading Kashmir marketplace ads…",
                            testTag = "home_loading_indicator"
                        )
                    }
                }

                uiState.listingsError != null -> {
                    item {
                        ErrorStateView(
                            message = uiState.listingsError,
                            onRetry = onRetryListings,
                            testTag = "home_error_state",
                            retryButtonTestTag = "home_retry_button"
                        )
                    }
                }

                uiState.homeListings.isEmpty() -> {
                    val hasSearchOrDistrict = uiState.homeSearchQuery.isNotBlank() ||
                        uiState.selectedHomeDistrict != KashmirDistrict.ALL
                    item {
                        EmptyStateView(
                            title = if (hasSearchOrDistrict) "No matching local ads" else "No local ads yet",
                            subtitle = if (hasSearchOrDistrict) {
                                "Try clearing your search or switching to All Kashmir."
                            } else {
                                "Be the first to post a free ordinary ad across Srinagar, Budgam, Baramulla or Anantnag."
                            },
                            actionLabel = if (hasSearchOrDistrict) "Reset Search" else "Post Free Ad",
                            onActionClick = {
                                if (hasSearchOrDistrict) {
                                    onHomeSearchChange("")
                                    onSelectHomeDistrict(KashmirDistrict.ALL)
                                } else {
                                    onOpenSell()
                                }
                            }
                        )
                    }
                }

                else -> {
                    val rows = uiState.homeListings.chunked(columns)
                    items(rows, key = { row -> row.joinToString("_") { it.id } }) { rowItems ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowItems.forEach { listing ->
                                ProductListingCard(
                                    listing = listing,
                                    isFavorite = listing.id in uiState.favoriteIds,
                                    onToggleFavorite = { onToggleFavorite(listing.id) },
                                    onClick = { onProductClick(listing.id) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(columns - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            // Business rules footer note
            item {
                Spacer(modifier = Modifier.height(14.dp))
                BusinessRulesBanner(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    compact = false
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
        )
    }
}
