package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.PauseCircleOutline
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.firestore.model.FirestoreFavourite
import com.example.data.firestore.model.FirestoreListingStatus
import com.example.data.formatInr
import com.example.model.KashmirDistrict
import com.example.model.ProductListing
import com.example.ui.components.AuthRequiredCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.ProductListingCard
import com.example.ui.components.ProductVisualArtwork
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.EmeraldBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.VibrantOrange
import com.example.ui.theme.VibrantOrangeContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAdsScreen(
    uiState: MarketplaceUiState,
    onNavigateBack: () -> Unit,
    onOpenSell: () -> Unit,
    onProductClick: (String) -> Unit,
    onEditListing: (ProductListing) -> Unit,
    onUpdateStatus: (String, FirestoreListingStatus) -> Unit,
    onDeleteListing: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onRetryMyAds: () -> Unit,
    onClearMessages: () -> Unit,
    onOpenLogin: () -> Unit,
    onOpenRegister: () -> Unit,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 2)) }
    var showFeaturedInfo by remember { mutableStateOf(false) }
    var listingPendingDelete by remember { mutableStateOf<ProductListing?>(null) }
    var listingPendingMarkSold by remember { mutableStateOf<ProductListing?>(null) }

    if (showFeaturedInfo) {
        AlertDialog(
            onDismissRequest = { showFeaturedInfo = false },
            title = { Text("Featured Ads (Future Paid Feature)") },
            text = {
                Text(
                    "All ordinary ads on eKashbuy are completely free with 0% commission. " +
                        "Optional Featured Ad boosts are planned for a future update."
                )
            },
            confirmButton = {
                Button(
                    onClick = { showFeaturedInfo = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("Close")
                }
            }
        )
    }

    listingPendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { listingPendingDelete = null },
            title = { Text("Delete Advertisement") },
            text = {
                Text("Delete \"${target.title}\" permanently? Buyers will no longer see this listing.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        listingPendingDelete = null
                        onDeleteListing(target.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("my_ads_confirm_delete_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { listingPendingDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    listingPendingMarkSold?.let { target ->
        AlertDialog(
            onDismissRequest = { listingPendingMarkSold = null },
            title = { Text("Mark Advertisement as Sold") },
            text = {
                Text("Mark \"${target.title}\" as sold? It will be moved to Paused / Sold and hidden from buyers.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        listingPendingMarkSold = null
                        onUpdateStatus(target.id, FirestoreListingStatus.SOLD)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VibrantOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("my_ads_confirm_sold_button")
                ) {
                    Text("Mark Sold")
                }
            },
            dismissButton = {
                TextButton(onClick = { listingPendingMarkSold = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    val activeAds = uiState.myListings.filter { it.status == FirestoreListingStatus.ACTIVE.name }
    val inactiveAds = uiState.myListings.filter {
        it.status == FirestoreListingStatus.PAUSED.name ||
            it.status == FirestoreListingStatus.SOLD.name
    }
    val liveListingsById = (uiState.allListings + uiState.myListings).associateBy { it.id }
    val savedActiveListings = uiState.allListings.filter { it.id in uiState.favoriteIds }
    val savedUnavailableFavourites = uiState.savedFavourites.filter { fav ->
        fav.listingId !in liveListingsById.keys
    }
    val totalSavedCount = maxOf(
        uiState.favoriteIds.size,
        savedActiveListings.size + savedUnavailableFavourites.size
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("My Ads & Saved", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("my_ads_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            if (uiState.isAuthenticated) {
                FloatingActionButton(
                    onClick = onOpenSell,
                    containerColor = VibrantOrange,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("my_ads_fab_post")
                ) {
                    Icon(imageVector = Icons.Outlined.Add, contentDescription = "Post new ad")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            uiState.adActionSuccessMessage?.let { success ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, EmeraldBadge.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("my_ads_success_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldBadge,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = success,
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldBadge,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onClearMessages,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Dismiss message",
                                tint = EmeraldBadge,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            uiState.adActionError?.let { error ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("my_ads_action_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onClearMessages,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Dismiss error",
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            if (!uiState.isAuthenticated) {
                AuthRequiredCard(
                    title = "Sign in to view your advertisements",
                    subtitle = "Manage your posted Kashmir ads, edit prices, or view your saved items.",
                    onOpenLogin = onOpenLogin,
                    onOpenRegister = onOpenRegister,
                    testTag = "my_ads_signin_prompt",
                    modifier = Modifier.padding(top = 12.dp)
                )
                return@Column
            }

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = RoyalBlue,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = RoyalBlue
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Active (${activeAds.size})") },
                    modifier = Modifier.testTag("my_ads_tab_active")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Paused / Sold (${inactiveAds.size})") },
                    modifier = Modifier.testTag("my_ads_tab_inactive")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Saved ($totalSavedCount)") },
                    modifier = Modifier.testTag("my_ads_tab_saved")
                )
            }

            when {
                selectedTab in 0..1 && uiState.isMyAdsLoading -> {
                    LoadingStateView(
                        message = "Loading your advertisements…",
                        testTag = "my_ads_loading_indicator"
                    )
                }

                selectedTab in 0..1 && uiState.myAdsError != null -> {
                    ErrorStateView(
                        message = uiState.myAdsError,
                        onRetry = onRetryMyAds,
                        testTag = "my_ads_error_state",
                        retryButtonTestTag = "my_ads_retry_button"
                    )
                }

                selectedTab == 0 -> {
                    if (activeAds.isEmpty()) {
                        EmptyStateView(
                            title = "No active ads yet",
                            subtitle = "Publish a free ordinary advertisement in seconds — 0% commission.",
                            actionLabel = "Post Free Ad",
                            onActionClick = onOpenSell
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(activeAds, key = { it.id }) { listing ->
                                MyAdRowCard(
                                    listing = listing,
                                    isDeleting = uiState.deletingListingId == listing.id,
                                    isUpdatingStatus = uiState.updatingStatusListingId == listing.id,
                                    onClick = { onProductClick(listing.id) },
                                    onEditClick = { onEditListing(listing) },
                                    onPauseOrResumeClick = {
                                        onUpdateStatus(listing.id, FirestoreListingStatus.PAUSED)
                                    },
                                    onMarkSoldClick = {
                                        listingPendingMarkSold = listing
                                    },
                                    onDeleteClick = { listingPendingDelete = listing },
                                    onBoostClick = { showFeaturedInfo = true }
                                )
                            }
                        }
                    }
                }

                selectedTab == 1 -> {
                    if (inactiveAds.isEmpty()) {
                        EmptyStateView(
                            title = "No paused or sold ads",
                            subtitle = "Paused or sold advertisements from your account will appear here.",
                            actionLabel = "Post Free Ad",
                            onActionClick = onOpenSell
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(inactiveAds, key = { it.id }) { listing ->
                                MyAdRowCard(
                                    listing = listing,
                                    isDeleting = uiState.deletingListingId == listing.id,
                                    isUpdatingStatus = uiState.updatingStatusListingId == listing.id,
                                    onClick = { onProductClick(listing.id) },
                                    onEditClick = { onEditListing(listing) },
                                    onPauseOrResumeClick = {
                                        onUpdateStatus(listing.id, FirestoreListingStatus.ACTIVE)
                                    },
                                    onMarkSoldClick = if (listing.status == FirestoreListingStatus.PAUSED.name) {
                                        { listingPendingMarkSold = listing }
                                    } else null,
                                    onDeleteClick = { listingPendingDelete = listing },
                                    onBoostClick = { showFeaturedInfo = true }
                                )
                            }
                        }
                    }
                }

                else -> {
                    if (savedActiveListings.isEmpty() && savedUnavailableFavourites.isEmpty()) {
                        EmptyStateView(
                            title = "No saved listings yet",
                            subtitle = "Tap the heart icon on any product to save it here for quick comparison."
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(savedActiveListings, key = { it.id }) { listing ->
                                ProductListingCard(
                                    listing = listing,
                                    isFavorite = true,
                                    onToggleFavorite = { onToggleFavorite(listing.id) },
                                    onClick = { onProductClick(listing.id) }
                                )
                            }
                            items(savedUnavailableFavourites, key = { "stale_${it.listingId}" }) { fav ->
                                UnavailableSavedAdCard(
                                    favourite = fav,
                                    onRemove = { onToggleFavorite(fav.listingId) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MyAdRowCard(
    listing: ProductListing,
    isDeleting: Boolean,
    isUpdatingStatus: Boolean,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onPauseOrResumeClick: () -> Unit,
    onMarkSoldClick: (() -> Unit)?,
    onDeleteClick: () -> Unit,
    onBoostClick: () -> Unit
) {
    val isBusy = isDeleting || isUpdatingStatus
    val isActive = listing.status == FirestoreListingStatus.ACTIVE.name
    val statusLabel = when (listing.status) {
        FirestoreListingStatus.ACTIVE.name -> "Active • Free"
        FirestoreListingStatus.PAUSED.name -> "Paused"
        FirestoreListingStatus.SOLD.name -> "Sold"
        else -> listing.status
    }
    val statusContainer = if (isActive) EmeraldContainer else VibrantOrangeContainer
    val statusColor = if (isActive) EmeraldBadge else VibrantOrange

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("my_ad_card_${listing.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(84.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    ProductVisualArtwork(listing = listing, modifier = Modifier.fillMaxSize())
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = statusContainer
                        ) {
                            Text(
                                text = statusLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = listing.postedAgo,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = listing.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = formatInr(listing.priceInr, listing.isMonthlyRent),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = RoyalBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = null,
                    tint = VibrantOrange,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${listing.locality}, ${listing.district.displayName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = onBoostClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = null,
                        tint = VibrantOrange,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Featured (Soon)",
                        style = MaterialTheme.typography.labelSmall,
                        color = RoyalBlue
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onEditClick,
                    enabled = !isBusy,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("my_ad_edit_${listing.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = onPauseOrResumeClick,
                    enabled = !isBusy,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("my_ad_status_${listing.id}")
                ) {
                    if (isUpdatingStatus) {
                        CircularProgressIndicator(
                            color = RoyalBlue,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(14.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isActive) Icons.Outlined.PauseCircleOutline else Icons.Outlined.PlayCircleOutline,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isActive) "Pause" else "Activate",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                if (onMarkSoldClick != null) {
                    OutlinedButton(
                        onClick = onMarkSoldClick,
                        enabled = !isBusy,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("my_ad_sold_${listing.id}")
                    ) {
                        Text("Sold", style = MaterialTheme.typography.labelMedium)
                    }
                }

                OutlinedButton(
                    onClick = onDeleteClick,
                    enabled = !isBusy,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(40.dp)
                        .testTag("my_ad_delete_${listing.id}")
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.error,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(15.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.DeleteOutline,
                            contentDescription = "Delete ad",
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UnavailableSavedAdCard(
    favourite: FirestoreFavourite,
    onRemove: () -> Unit
) {
    val districtName = KashmirDistrict.entries.firstOrNull {
        it.name == favourite.district && it != KashmirDistrict.ALL
    }?.displayName ?: favourite.district

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_unavailable_card_${favourite.listingId}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = VibrantOrangeContainer
                ) {
                    Text(
                        text = "Ad paused, sold, or removed",
                        style = MaterialTheme.typography.labelSmall,
                        color = VibrantOrange,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = favourite.listingTitle,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${formatInr(favourite.priceInr.toInt())} • $districtName",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onRemove,
                modifier = Modifier
                    .height(40.dp)
                    .testTag("saved_remove_button_${favourite.listingId}")
            ) {
                Text("Remove", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
