package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.model.AdCategory
import com.example.model.AdCondition
import com.example.model.KashmirDistrict
import com.example.model.MarketplaceFilters
import com.example.model.SortOption
import com.example.ui.components.AuthRequiredCard
import com.example.ui.components.DistrictFilterChipRow
import com.example.ui.components.EkashbuyOutlinedTextField
import com.example.ui.components.EkashbuySearchBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.ProductListingCard
import com.example.ui.components.SearchHistoryStrip
import com.example.ui.components.TextFieldInputSanitizers
import com.example.ui.state.MarketplaceUiState
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.VibrantOrange

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProductListingsScreen(
    uiState: MarketplaceUiState,
    onUpdateFilters: ((MarketplaceFilters) -> MarketplaceFilters) -> Unit,
    onResetFilters: () -> Unit,
    onProductClick: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onNavigateBack: () -> Unit,
    onOpenLogin: () -> Unit,
    onOpenRegister: () -> Unit,
    onRetryListings: () -> Unit,
    onOpenSell: () -> Unit,
    onClearMessages: () -> Unit = {},
    onRecordSearchQuery: (String) -> Unit = {},
    onRemoveSearchHistory: (String) -> Unit = {},
    onClearSearchHistory: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showFilterSheet by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val filters = uiState.filters

    LaunchedEffect(uiState.adActionError, uiState.adActionSuccessMessage) {
        val message = uiState.adActionError ?: uiState.adActionSuccessMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
            onClearMessages()
        }
    }

    val activeFilterCount = listOfNotNull(
        filters.category,
        filters.condition,
        filters.minPriceInr,
        filters.maxPriceInr,
        if (filters.district != KashmirDistrict.ALL) filters.district else null
    ).size

    if (showFilterSheet) {
        FilterOptionsBottomSheet(
            filters = filters,
            onApply = { updated ->
                onUpdateFilters { updated }
                if (updated.query.isNotBlank()) {
                    onRecordSearchQuery(updated.query)
                }
                showFilterSheet = false
            },
            onReset = {
                onResetFilters()
                showFilterSheet = false
            },
            onDismiss = { showFilterSheet = false }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = filters.category?.title ?: "Browse Listings",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("listings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showFilterSheet = true },
                        modifier = Modifier.testTag("listings_open_filters_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (activeFilterCount > 0) {
                                    Badge(containerColor = VibrantOrange) {
                                        Text("$activeFilterCount", color = Color.White)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.FilterList,
                                contentDescription = "Filter listings",
                                tint = RoyalBlue
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            EkashbuySearchBar(
                query = filters.query,
                onQueryChange = { q -> onUpdateFilters { it.copy(query = q) } },
                onSearchSubmit = { onRecordSearchQuery(filters.query) },
                modifier = Modifier.padding(horizontal = 16.dp),
                testTag = "listings_search_input"
            )

            if (uiState.isAuthenticated && uiState.searchHistory.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                SearchHistoryStrip(
                    history = uiState.searchHistory,
                    onSelectQuery = { term ->
                        onUpdateFilters { it.copy(query = term) }
                        onRecordSearchQuery(term)
                    },
                    onRemoveQuery = onRemoveSearchHistory,
                    onClearAll = onClearSearchHistory,
                    tagPrefix = "listings_search_history"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            DistrictFilterChipRow(
                selectedDistrict = filters.district,
                onDistrictSelected = { dist -> onUpdateFilters { it.copy(district = dist) } }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Category & Sort Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier
                            .clickable { showFilterSheet = true }
                            .testTag("listings_sort_pill"),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.SwapVert,
                                contentDescription = "Sort",
                                tint = RoyalBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = filters.sortOption.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                items(AdCategory.entries) { cat ->
                    val selected = filters.category == cat
                    FilterChip(
                        selected = selected,
                        onClick = {
                            onUpdateFilters {
                                it.copy(category = if (selected) null else cat)
                            }
                        },
                        modifier = Modifier.testTag("listings_cat_chip_${cat.name.lowercase()}"),
                        label = { Text(cat.shortTitle, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VibrantOrange,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when {
                        !uiState.isAuthenticated -> "Sign in to view results"
                        uiState.isListingsLoading -> "Loading listings…"
                        uiState.listingsError != null -> "Unable to load results"
                        else -> "${uiState.filteredListings.size} results found"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (activeFilterCount > 0 || filters.query.isNotBlank()) {
                    TextButton(
                        onClick = onResetFilters,
                        modifier = Modifier.testTag("listings_clear_all_button")
                    ) {
                        Text("Clear all", color = RoyalBlue)
                    }
                }
            }

            when {
                !uiState.isAuthenticated -> {
                    AuthRequiredCard(
                        title = "Sign in to view Kashmir listings",
                        subtitle = "Sign in with Phone OTP or Email to browse active ads and contact sellers.",
                        onOpenLogin = onOpenLogin,
                        onOpenRegister = onOpenRegister,
                        testTag = "listings_signin_prompt",
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                uiState.isListingsLoading -> {
                    LoadingStateView(
                        message = "Loading active listings…",
                        testTag = "listings_loading_indicator",
                        modifier = Modifier.weight(1f)
                    )
                }

                uiState.listingsError != null -> {
                    ErrorStateView(
                        message = uiState.listingsError,
                        onRetry = onRetryListings,
                        testTag = "listings_error_state",
                        retryButtonTestTag = "listings_retry_button"
                    )
                }

                uiState.filteredListings.isEmpty() -> {
                    val hasFilters = activeFilterCount > 0 || filters.query.isNotBlank()
                    EmptyStateView(
                        title = if (hasFilters) "No listings match your filters" else "No active listings yet",
                        subtitle = if (hasFilters) {
                            "Try widening your budget, condition, or district selection."
                        } else {
                            "Be the first to post a free ordinary ad on eKashbuy."
                        },
                        actionLabel = if (hasFilters) "Reset Filters" else "Post Free Ad",
                        onActionClick = if (hasFilters) onResetFilters else onOpenSell,
                        modifier = Modifier.weight(1f)
                    )
                }

                else -> {
                    BoxWithConstraints(modifier = Modifier.weight(1f)) {
                        val columns = if (maxWidth >= 840.dp) 3 else 2
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(columns),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.filteredListings, key = { it.id }) { listing ->
                                ProductListingCard(
                                    listing = listing,
                                    isFavorite = listing.id in uiState.favoriteIds,
                                    onToggleFavorite = { onToggleFavorite(listing.id) },
                                    onClick = { onProductClick(listing.id) }
                                )
                            }
                            item(span = { GridItemSpan(columns) }) {
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FilterOptionsBottomSheet(
    filters: MarketplaceFilters,
    onApply: (MarketplaceFilters) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    var draft by remember(filters) { mutableStateOf(filters) }
    val initialMinText = filters.minPriceInr?.toString().orEmpty()
    val initialMaxText = filters.maxPriceInr?.toString().orEmpty()
    var minPriceText by remember(filters) {
        mutableStateOf(TextFieldValue(initialMinText, TextRange(initialMinText.length)))
    }
    var maxPriceText by remember(filters) {
        mutableStateOf(TextFieldValue(initialMaxText, TextRange(initialMaxText.length)))
    }
    val parsedMin = minPriceText.text.toIntOrNull()
    val parsedMax = maxPriceText.text.toIntOrNull()
    val priceRangeError = if (parsedMin != null && parsedMax != null && parsedMin > parsedMax) {
        "Minimum price cannot exceed maximum price."
    } else {
        null
    }

    val priceCaps = listOf(
        null to "Any Budget",
        10_000 to "Under ₹10,000",
        30_000 to "Under ₹30,000",
        75_000 to "Under ₹75,000",
        600_000 to "Under ₹6 Lakh"
    )

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Text(
                text = "Filter & Sort Listings",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(modifier = Modifier.height(16.dp))

            Text("Sort By", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SortOption.entries.forEach { option ->
                    FilterChip(
                        selected = draft.sortOption == option,
                        onClick = { draft = draft.copy(sortOption = option) },
                        label = { Text(option.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("District", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                KashmirDistrict.entries.forEach { dist ->
                    FilterChip(
                        selected = draft.district == dist,
                        onClick = { draft = draft.copy(district = dist) },
                        label = { Text(dist.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Category", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = draft.category == null,
                    onClick = { draft = draft.copy(category = null) },
                    label = { Text("All Categories") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantOrange,
                        selectedLabelColor = Color.White
                    )
                )
                AdCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = draft.category == cat,
                        onClick = { draft = draft.copy(category = if (draft.category == cat) null else cat) },
                        label = { Text(cat.shortTitle) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VibrantOrange,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Condition", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = draft.condition == null,
                    onClick = { draft = draft.copy(condition = null) },
                    label = { Text("Any") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantOrange,
                        selectedLabelColor = Color.White
                    )
                )
                AdCondition.entries.forEach { cond ->
                    FilterChip(
                        selected = draft.condition == cond,
                        onClick = { draft = draft.copy(condition = cond) },
                        label = { Text(cond.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VibrantOrange,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Price Range (₹)", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EkashbuyOutlinedTextField(
                    value = minPriceText,
                    onValueChange = { incoming ->
                        val sanitized = TextFieldInputSanitizers.sanitizeDigits(incoming, 9)
                        minPriceText = sanitized
                        draft = draft.copy(minPriceInr = sanitized.text.toIntOrNull())
                    },
                    label = "Min (₹)",
                    placeholder = "0",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next,
                        autoCorrectEnabled = false
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("filter_min_price_input")
                )
                EkashbuyOutlinedTextField(
                    value = maxPriceText,
                    onValueChange = { incoming ->
                        val sanitized = TextFieldInputSanitizers.sanitizeDigits(incoming, 9)
                        maxPriceText = sanitized
                        draft = draft.copy(maxPriceInr = sanitized.text.toIntOrNull())
                    },
                    label = "Max (₹)",
                    placeholder = "Any",
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done,
                        autoCorrectEnabled = false
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("filter_max_price_input")
                )
            }
            if (priceRangeError != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = priceRangeError,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.testTag("filter_price_error")
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                priceCaps.forEach { (cap, label) ->
                    FilterChip(
                        selected = draft.minPriceInr == null && draft.maxPriceInr == cap,
                        onClick = {
                            minPriceText = TextFieldValue("")
                            val capStr = cap?.toString().orEmpty()
                            maxPriceText = TextFieldValue(capStr, TextRange(capStr.length))
                            draft = draft.copy(minPriceInr = null, maxPriceInr = cap)
                        },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        minPriceText = TextFieldValue("")
                        maxPriceText = TextFieldValue("")
                        onReset()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("filter_sheet_reset_button")
                ) {
                    Text("Reset")
                }
                Button(
                    onClick = {
                        onApply(
                            draft.copy(
                                minPriceInr = parsedMin,
                                maxPriceInr = parsedMax
                            )
                        )
                    },
                    enabled = priceRangeError == null,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("filter_sheet_apply_button")
                ) {
                    Text("Apply Filters")
                }
            }
        }
    }
}
