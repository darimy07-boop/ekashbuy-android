package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val EkashbuyLightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = PureWhite,
    primaryContainer = RoyalBlueContainer,
    onPrimaryContainer = OnRoyalBlueContainer,
    secondary = VibrantOrange,
    onSecondary = PureWhite,
    secondaryContainer = VibrantOrangeContainer,
    onSecondaryContainer = OnVibrantOrangeContainer,
    tertiary = EmeraldBadge,
    onTertiary = PureWhite,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = Color(0xFF002116),
    background = PureWhite,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SoftCanvas,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = PureWhite,
    surfaceContainerLow = SoftCanvas,
    surfaceContainer = SurfaceMuted,
    outline = OutlineSubtle,
    outlineVariant = OutlineStrong,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorContainerLight
)

private val EkashbuyDarkColorScheme = darkColorScheme(
    primary = RoyalBlueLight,
    onPrimary = PureWhite,
    primaryContainer = RoyalBlueDark,
    onPrimaryContainer = RoyalBlueContainer,
    secondary = VibrantOrange,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFF5C2800),
    onSecondaryContainer = VibrantOrangeContainer,
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155)
)

val EkashbuyShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun EkashbuyTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) EkashbuyDarkColorScheme else EkashbuyLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = EkashbuyTypography,
        shapes = EkashbuyShapes,
        content = content
    )
}
