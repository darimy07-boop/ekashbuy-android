package com.example.ui.state

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.auth.AuthValidation
import com.example.data.auth.FirebaseAuthRepository
import com.example.data.auth.PhoneOtpEvent
import com.example.data.firestore.FirestoreClientProvider
import com.example.data.firestore.FirestoreUserRepository
import com.example.data.firestore.UserProfileRepository
import com.example.data.firestore.model.FirestoreUser
import com.example.model.KashmirDistrict
import com.google.firebase.Firebase
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val currentUser: AuthUser? = null,
    val userProfile: FirestoreUser? = null,
    val isLoading: Boolean = false,
    val isSyncingProfile: Boolean = false,
    val isUpdatingProfile: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val otpCodeSent: Boolean = false,
    val otpPhoneDisplay: String = "",
    val canResendOtp: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class AuthViewModel(
    private val authRepository: AuthRepository,
    private val userProfileRepository: UserProfileRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AuthUiState(currentUser = authRepository.currentUser())
    )
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var activeVerificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var pendingOtpFullName: String? = null
    private var pendingOtpDistrict: KashmirDistrict? = null
    private var pendingOtpPhone: String? = null
    private var isPhoneOtpPending: Boolean = false

    init {
        val authFlow = authRepository.observeAuthState()

        authFlow
            .onEach { user ->
                _uiState.update { state ->
                    val shouldHoldForOtpSync = user != null &&
                        state.currentUser == null &&
                        isPhoneOtpPending
                    state.copy(
                        currentUser = user,
                        userProfile = if (user == null) null else state.userProfile,
                        isSyncingProfile = when {
                            user == null -> false
                            shouldHoldForOtpSync -> true
                            else -> state.isSyncingProfile
                        }
                    )
                }
            }
            .launchIn(viewModelScope)

        if (userProfileRepository != null) {
            authFlow
                .flatMapLatest { user ->
                    if (user == null) {
                        flowOf(null)
                    } else {
                        userProfileRepository.observeUserProfile(user.uid)
                            .catch { emit(null) }
                    }
                }
                .onEach { profile ->
                    _uiState.update { it.copy(userProfile = profile) }
                }
                .launchIn(viewModelScope)
        }
    }

    fun signInWithEmail(email: String, password: String) {
        val trimmedEmail = email.trim()
        if (!AuthValidation.isValidEmail(trimmedEmail)) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address.", infoMessage = null) }
            return
        }
        val passwordError = AuthValidation.validatePassword(password)
        if (passwordError != null) {
            _uiState.update { it.copy(errorMessage = passwordError, infoMessage = null) }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    isSyncingProfile = true,
                    errorMessage = null,
                    infoMessage = null
                )
            }
            val result = authRepository.signInWithEmail(trimmedEmail, password)
            result.fold(
                onSuccess = { user ->
                    val profile = fetchOrEnsureUserProfile(user = user)
                    _uiState.update {
                        it.copy(
                            currentUser = user,
                            userProfile = profile ?: it.userProfile,
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = null,
                            infoMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = error.message ?: "Sign in failed. Please try again."
                        )
                    }
                }
            )
        }
    }

    fun registerWithEmail(
        fullName: String,
        email: String,
        rawPhone: String,
        district: KashmirDistrict,
        password: String
    ) {
        val nameError = AuthValidation.validateFullName(fullName)
        if (nameError != null) {
            _uiState.update { it.copy(errorMessage = nameError, infoMessage = null) }
            return
        }
        val trimmedEmail = email.trim()
        if (!AuthValidation.isValidEmail(trimmedEmail)) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address.", infoMessage = null) }
            return
        }
        val normalizedPhone = AuthValidation.normalizePhoneToE164(rawPhone)
        if (normalizedPhone == null) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please enter a valid 10-digit Indian mobile number or +91 number.",
                    infoMessage = null
                )
            }
            return
        }
        val passwordError = AuthValidation.validatePassword(password)
        if (passwordError != null) {
            _uiState.update { it.copy(errorMessage = passwordError, infoMessage = null) }
            return
        }

        viewModelScope.launch {
            val cleanName = fullName.trim()
            _uiState.update {
                it.copy(
                    isLoading = true,
                    isSyncingProfile = true,
                    errorMessage = null,
                    infoMessage = null
                )
            }
            val result = authRepository.registerWithEmail(
                fullName = cleanName,
                email = trimmedEmail,
                phoneE164 = normalizedPhone,
                district = district,
                password = password
            )
            result.fold(
                onSuccess = { user ->
                    val profile = fetchOrEnsureUserProfile(
                        user = user,
                        fullName = cleanName,
                        district = district,
                        fallbackPhone = normalizedPhone
                    )
                    _uiState.update {
                        it.copy(
                            currentUser = user,
                            userProfile = profile ?: it.userProfile,
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = null,
                            infoMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = error.message ?: "Registration failed. Please try again."
                        )
                    }
                }
            )
        }
    }

    fun requestPhoneOtp(
        activity: Activity?,
        rawPhone: String,
        isResend: Boolean = false,
        fullName: String? = null,
        district: KashmirDistrict? = null
    ) {
        if (_uiState.value.isLoading || _uiState.value.isSyncingProfile) return

        if (fullName != null) {
            val nameError = AuthValidation.validateFullName(fullName)
            if (nameError != null) {
                _uiState.update { it.copy(errorMessage = nameError, infoMessage = null) }
                return
            }
        }

        val normalizedPhone = AuthValidation.normalizePhoneToE164(rawPhone)
        if (normalizedPhone == null) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please enter a valid mobile number (e.g. 9876543210 or +91 9876543210).",
                    infoMessage = null
                )
            }
            return
        }

        if (activity == null) {
            _uiState.update {
                it.copy(
                    errorMessage = "Unable to start phone verification from this screen. Please reopen the page and try again.",
                    infoMessage = null
                )
            }
            return
        }

        pendingOtpFullName = fullName?.trim()?.takeIf { it.length >= 2 }
        pendingOtpDistrict = district?.takeIf { it != KashmirDistrict.ALL }
        pendingOtpPhone = normalizedPhone
        isPhoneOtpPending = true

        _uiState.update {
            it.copy(
                isLoading = true,
                errorMessage = null,
                infoMessage = null,
                otpPhoneDisplay = normalizedPhone
            )
        }

        authRepository.sendPhoneOtp(
            activity = activity,
            phoneNumberE164 = normalizedPhone,
            resendToken = if (isResend) resendToken else null
        ) { event ->
            when (event) {
                is PhoneOtpEvent.CodeSent -> {
                    activeVerificationId = event.verificationId
                    resendToken = event.resendToken
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            otpCodeSent = true,
                            otpPhoneDisplay = normalizedPhone,
                            canResendOtp = true,
                            errorMessage = null,
                            infoMessage = if (isResend) {
                                "New 6-digit OTP sent to $normalizedPhone."
                            } else {
                                "6-digit OTP sent to $normalizedPhone."
                            }
                        )
                    }
                }

                is PhoneOtpEvent.AutoRetrievalTimedOut -> {
                    if (activeVerificationId.isNullOrBlank()) {
                        activeVerificationId = event.verificationId
                    }
                    _uiState.update { state ->
                        if (state.currentUser == null && state.otpCodeSent && !state.isLoading) {
                            state.copy(
                                canResendOtp = true,
                                infoMessage = state.infoMessage
                                    ?: "Enter the 6-digit OTP manually or tap Resend OTP."
                            )
                        } else {
                            state
                        }
                    }
                }

                is PhoneOtpEvent.VerificationCompleted -> {
                    val capturedName = pendingOtpFullName
                    val capturedDistrict = pendingOtpDistrict
                    val capturedPhone = pendingOtpPhone
                        ?: _uiState.value.otpPhoneDisplay.takeIf { it.isNotBlank() }
                        ?: event.user.phoneNumber
                    isPhoneOtpPending = false
                    clearOtpTokens()

                    _uiState.update {
                        it.copy(
                            currentUser = event.user,
                            isLoading = true,
                            isSyncingProfile = true,
                            errorMessage = null,
                            infoMessage = null
                        )
                    }

                    viewModelScope.launch {
                        val syncedUser = authRepository.syncPhoneUserProfile(
                            user = event.user,
                            fullName = capturedName,
                            district = capturedDistrict,
                            fallbackPhone = capturedPhone
                        ).getOrElse { event.user }
                        val profile = fetchOrEnsureUserProfile(
                            user = syncedUser,
                            fullName = capturedName,
                            district = capturedDistrict,
                            fallbackPhone = capturedPhone
                        )
                        _uiState.update {
                            it.copy(
                                currentUser = syncedUser,
                                userProfile = profile ?: it.userProfile,
                                isLoading = false,
                                isSyncingProfile = false,
                                otpCodeSent = false,
                                canResendOtp = false,
                                otpPhoneDisplay = "",
                                errorMessage = null,
                                infoMessage = null
                            )
                        }
                    }
                }

                is PhoneOtpEvent.VerificationFailed -> {
                    isPhoneOtpPending = false
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = event.message,
                            infoMessage = null
                        )
                    }
                }
            }
        }
    }

    fun verifyOtp(
        otpCode: String,
        fullName: String? = null,
        district: KashmirDistrict? = null
    ) {
        if (_uiState.value.isLoading || _uiState.value.isSyncingProfile) return

        val verificationId = activeVerificationId
        if (verificationId.isNullOrBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please request an OTP first.",
                    otpCodeSent = false
                )
            }
            return
        }

        val otpError = AuthValidation.validateOtpCode(otpCode)
        if (otpError != null) {
            _uiState.update { it.copy(errorMessage = otpError, infoMessage = null) }
            return
        }

        val resolvedName = fullName?.trim()?.takeIf { it.length >= 2 } ?: pendingOtpFullName
        val resolvedDistrict = district?.takeIf { it != KashmirDistrict.ALL } ?: pendingOtpDistrict
        val resolvedPhone = pendingOtpPhone ?: _uiState.value.otpPhoneDisplay.takeIf { it.isNotBlank() }
        isPhoneOtpPending = true

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    isSyncingProfile = true,
                    errorMessage = null,
                    infoMessage = null
                )
            }
            val result = authRepository.verifyPhoneOtp(
                verificationId = verificationId,
                smsCode = otpCode.trim(),
                fullName = resolvedName,
                district = resolvedDistrict
            )
            result.fold(
                onSuccess = { user ->
                    val profile = fetchOrEnsureUserProfile(
                        user = user,
                        fullName = resolvedName,
                        district = resolvedDistrict,
                        fallbackPhone = resolvedPhone
                    )
                    isPhoneOtpPending = false
                    clearOtpTokens()
                    _uiState.update {
                        it.copy(
                            currentUser = user,
                            userProfile = profile ?: it.userProfile,
                            isLoading = false,
                            isSyncingProfile = false,
                            otpCodeSent = false,
                            canResendOtp = false,
                            otpPhoneDisplay = "",
                            errorMessage = null,
                            infoMessage = null
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isSyncingProfile = false,
                            errorMessage = error.message ?: "OTP verification failed. Please try again."
                        )
                    }
                }
            )
        }
    }

    fun resetOtpFlow() {
        isPhoneOtpPending = false
        clearOtpTokens()
        _uiState.update {
            it.copy(
                isLoading = false,
                isSyncingProfile = false,
                otpCodeSent = false,
                canResendOtp = false,
                otpPhoneDisplay = "",
                errorMessage = null,
                infoMessage = null
            )
        }
    }

    fun clearMessages() {
        val current = _uiState.value
        if (current.errorMessage != null || current.infoMessage != null) {
            _uiState.update { it.copy(errorMessage = null, infoMessage = null) }
        }
    }

    fun updateUserProfile(
        displayName: String,
        mobileNumber: String,
        district: KashmirDistrict,
        locality: String,
        onSuccess: () -> Unit = {}
    ) {
        val currentUser = authRepository.currentUser()
        if (currentUser == null) {
            _uiState.update {
                it.copy(errorMessage = "Please sign in to update your profile.", infoMessage = null)
            }
            return
        }
        val repo = userProfileRepository
        if (repo == null) {
            _uiState.update {
                it.copy(errorMessage = "Profile storage is unavailable right now.", infoMessage = null)
            }
            return
        }

        val nameError = AuthValidation.validateFullName(displayName)
        if (nameError != null) {
            _uiState.update { it.copy(errorMessage = nameError, infoMessage = null) }
            return
        }
        val cleanName = displayName.trim().take(60)

        val normalizedPhone = AuthValidation.normalizePhoneToE164(mobileNumber)
        val cleanPhone = normalizedPhone ?: mobileNumber.trim()
        val phoneDigitCount = cleanPhone.count { it.isDigit() }
        if (cleanPhone.length !in 7..20 || phoneDigitCount < 7) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please enter a valid 10-digit Indian mobile number or phone number (7–20 characters).",
                    infoMessage = null
                )
            }
            return
        }

        if (district == KashmirDistrict.ALL) {
            _uiState.update {
                it.copy(
                    errorMessage = "Please select a Kashmir district (Srinagar, Budgam, Baramulla, or Anantnag).",
                    infoMessage = null
                )
            }
            return
        }

        val cleanLocality = locality.trim()
        if (cleanLocality.length > 80) {
            _uiState.update {
                it.copy(
                    errorMessage = "Locality must be 80 characters or fewer.",
                    infoMessage = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isUpdatingProfile = true,
                    errorMessage = null,
                    infoMessage = null
                )
            }
            val existing = _uiState.value.userProfile
            val updated = FirestoreUser(
                id = currentUser.uid,
                userId = currentUser.uid,
                displayName = cleanName,
                mobileNumber = cleanPhone,
                district = district.name,
                locality = cleanLocality,
                avatarUrl = existing?.avatarUrl,
                createdAt = existing?.createdAt
            )
            val result = repo.saveUserProfile(updated)
            result.fold(
                onSuccess = {
                    val refreshed = repo.getUserProfile(currentUser.uid).getOrNull() ?: updated
                    _uiState.update {
                        it.copy(
                            userProfile = refreshed,
                            isUpdatingProfile = false,
                            errorMessage = null,
                            infoMessage = "Profile details updated."
                        )
                    }
                    onSuccess()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isUpdatingProfile = false,
                            errorMessage = error.message ?: "Unable to update profile right now."
                        )
                    }
                }
            )
        }
    }

    fun signOut() {
        isPhoneOtpPending = false
        clearOtpTokens()
        authRepository.signOut()
        _uiState.update {
            AuthUiState(
                currentUser = null,
                userProfile = null,
                infoMessage = "You have been signed out."
            )
        }
    }

    private suspend fun fetchOrEnsureUserProfile(
        user: AuthUser,
        fullName: String? = null,
        district: KashmirDistrict? = null,
        fallbackPhone: String? = null
    ): FirestoreUser? {
        val repo = userProfileRepository ?: return null
        val existing = repo.getUserProfile(user.uid).getOrNull()
        val cleanName = fullName?.trim()?.takeIf { it.length >= 2 }
        val explicitDistrict = district?.takeIf { it != KashmirDistrict.ALL }
        val resolvedPhone = (user.phoneNumber ?: fallbackPhone)?.trim()?.takeIf { it.length >= 7 }

        if (existing == null) {
            if (resolvedPhone == null) return null
            val candidate = FirestoreUser(
                id = user.uid,
                userId = user.uid,
                displayName = (cleanName ?: user.displayName?.trim()?.takeIf { it.length >= 2 } ?: "eKashbuy Member").take(60),
                mobileNumber = resolvedPhone.take(20),
                district = (explicitDistrict ?: KashmirDistrict.SRINAGAR).name,
                locality = ""
            )
            return if (repo.saveUserProfile(candidate).isSuccess) {
                repo.getUserProfile(user.uid).getOrNull() ?: candidate
            } else {
                null
            }
        }

        val needsNameUpdate = cleanName != null && cleanName != existing.displayName
        val needsDistrictUpdate = explicitDistrict != null && explicitDistrict.name != existing.district
        if (needsNameUpdate || needsDistrictUpdate) {
            val updated = existing.copy(
                displayName = (cleanName ?: existing.displayName).take(60),
                district = explicitDistrict?.name ?: existing.district
            )
            if (repo.saveUserProfile(updated).isSuccess) {
                return repo.getUserProfile(user.uid).getOrNull() ?: updated
            }
        }
        return existing
    }

    private fun clearOtpTokens() {
        activeVerificationId = null
        resendToken = null
        pendingOtpFullName = null
        pendingOtpDistrict = null
        pendingOtpPhone = null
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val auth = Firebase.auth
                val firestore = FirestoreClientProvider.getInstance()
                val userProfileRepo = FirestoreUserRepository(db = firestore, auth = auth)
                val authRepo = FirebaseAuthRepository(auth = auth, userProfileRepository = userProfileRepo)
                return AuthViewModel(
                    authRepository = authRepo,
                    userProfileRepository = userProfileRepo
                ) as T
            }
        }
    }
}
