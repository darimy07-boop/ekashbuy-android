package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Established eKashbuy Design Identity
val RoyalBlue = Color(0xFF0047A1)
val RoyalBlueDark = Color(0xFF003173)
val RoyalBlueLight = Color(0xFF2B6FD6)
val RoyalBlueContainer = Color(0xFFE8F1FF)
val OnRoyalBlueContainer = Color(0xFF002559)

val VibrantOrange = Color(0xFFFF7A00)
val VibrantOrangeDark = Color(0xFFD96400)
val VibrantOrangeContainer = Color(0xFFFFF0E0)
val OnVibrantOrangeContainer = Color(0xFF5C2800)

val PureWhite = Color(0xFFFFFFFF)
val SoftCanvas = Color(0xFFF7F9FC)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceMuted = Color(0xFFF1F5F9)
val OutlineSubtle = Color(0xFFE2E8F0)
val OutlineStrong = Color(0xFFCBD5E1)

val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF64748B)

val EmeraldBadge = Color(0xFF047857)
val EmeraldContainer = Color(0xFFE6F7F1)
val ErrorRed = Color(0xFFBA1A1A)
val ErrorContainerLight = Color(0xFFFFDAD6)

// Dark mode fallbacks if explicitly enabled
val DarkBackground = Color(0xFF0B1220)
val DarkSurface = Color(0xFF121C2E)
val DarkSurfaceVariant = Color(0xFF1B2840)
