package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Chair
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.HomeWork
import androidx.compose.material.icons.outlined.LaptopMac
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class KashmirDistrict(val displayName: String, val regionHint: String) {
    ALL("All Kashmir", "Srinagar, Budgam, Baramulla & Anantnag"),
    SRINAGAR("Srinagar", "Lal Chowk, Rajbagh, Bemina, Hazratbal"),
    BUDGAM("Budgam", "Humhama, Chadoora, Beerwah, Magam"),
    BARAMULLA("Baramulla", "Sopore, Pattan, Ushkara, Gulmarg Rd"),
    ANANTNAG("Anantnag", "KP Road, Bijbehara, Mattan, Pahalgam Rd")
}

enum class AdCategory(
    val title: String,
    val shortTitle: String,
    val subtitle: String,
    val icon: ImageVector,
    val tintColor: Color,
    val containerColor: Color
) {
    VEHICLES(
        title = "Vehicles & Bikes",
        shortTitle = "Vehicles",
        subtitle = "Cars, Scooters & Royal Enfield",
        icon = Icons.Outlined.DirectionsCar,
        tintColor = Color(0xFF0047A1),
        containerColor = Color(0xFFE8F1FF)
    ),
    MOBILES(
        title = "Mobiles & Tablets",
        shortTitle = "Mobiles",
        subtitle = "Smartphones & Accessories",
        icon = Icons.Outlined.Smartphone,
        tintColor = Color(0xFFD96400),
        containerColor = Color(0xFFFFF0E0)
    ),
    ELECTRONICS(
        title = "Electronics & Laptops",
        shortTitle = "Electronics",
        subtitle = "Laptops, Cameras & Appliances",
        icon = Icons.Outlined.LaptopMac,
        tintColor = Color(0xFF0E7490),
        containerColor = Color(0xFFE6F7FA)
    ),
    HANDICRAFTS(
        title = "Kashmiri Crafts",
        shortTitle = "Crafts",
        subtitle = "Silk Carpets, Pashmina & Copper",
        icon = Icons.Outlined.Palette,
        tintColor = Color(0xFF9A3412),
        containerColor = Color(0xFFFFEDD5)
    ),
    HOME_FURNITURE(
        title = "Home & Walnut Wood",
        shortTitle = "Furniture",
        subtitle = "Walnut Furniture & Home Decor",
        icon = Icons.Outlined.Chair,
        tintColor = Color(0xFF047857),
        containerColor = Color(0xFFE6F7F1)
    ),
    PROPERTIES(
        title = "Homes & Land",
        shortTitle = "Property",
        subtitle = "Rentals, Houses & Plots",
        icon = Icons.Outlined.HomeWork,
        tintColor = Color(0xFF4338CA),
        containerColor = Color(0xFFEEF2FF)
    ),
    FASHION(
        title = "Winter Wear & Apparel",
        shortTitle = "Apparel",
        subtitle = "Pherans, Jackets & Footwear",
        icon = Icons.Outlined.Checkroom,
        tintColor = Color(0xFFBE185D),
        containerColor = Color(0xFFFCE7F3)
    ),
    SERVICES(
        title = "Local Services",
        shortTitle = "Services",
        subtitle = "Tutors, Repair & Home Help",
        icon = Icons.Outlined.Build,
        tintColor = Color(0xFF334155),
        containerColor = Color(0xFFF1F5F9)
    )
}

enum class AdCondition(val label: String) {
    BRAND_NEW("Brand New"),
    LIKE_NEW("Like New"),
    GOOD("Good"),
    FAIR("Used - Fair")
}

enum class SortOption(val label: String) {
    NEWEST("Newest First"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low")
}

enum class AdTier(val label: String) {
    ORDINARY_FREE("Ordinary Ad (Free)"),
    FEATURED_FUTURE("Featured Ad (Coming Soon)")
}

enum class MyAdStatus(val label: String) {
    ACTIVE("Active • Free"),
    DRAFT("Draft Preview"),
    EXPIRED("Archived")
}

data class ProductListing(
    val id: String,
    val title: String,
    val priceInr: Int,
    val isMonthlyRent: Boolean = false,
    val negotiable: Boolean = true,
    val category: AdCategory,
    val district: KashmirDistrict,
    val locality: String,
    val description: String,
    val condition: AdCondition,
    val postedAgo: String,
    val sellerName: String,
    val sellerPhone: String,
    val sellerId: String = "",
    val status: String = "ACTIVE",
    val createdAtMillis: Long = 0L,
    val imageUrls: List<String> = emptyList(),
    @DrawableRes val imageResId: Int? = null,
    val specs: Map<String, String> = emptyMap(),
    val adTier: AdTier = AdTier.ORDINARY_FREE
)

data class MyAdItem(
    val listing: ProductListing,
    val status: MyAdStatus,
    val viewCount: Int,
    val inquiryCount: Int
)

data class ChatMessagePreview(
    val id: String,
    val senderName: String,
    val text: String,
    val timeLabel: String,
    val isFromBuyer: Boolean,
    val isFromCurrentUser: Boolean = false
)

data class ConversationPreview(
    val id: String,
    val participantName: String,
    val district: KashmirDistrict,
    val productId: String,
    val productTitle: String,
    val productPriceInr: Int,
    val lastMessage: String,
    val timestamp: String,
    val isBuyingInquiry: Boolean,
    val unreadCount: Int = 0,
    val messages: List<ChatMessagePreview> = emptyList(),
    val lastSenderId: String = "",
    val lastMessageAtMillis: Long = 0L
)

data class MarketplaceFilters(
    val query: String = "",
    val district: KashmirDistrict = KashmirDistrict.ALL,
    val category: AdCategory? = null,
    val condition: AdCondition? = null,
    val minPriceInr: Int? = null,
    val maxPriceInr: Int? = null,
    val sortOption: SortOption = SortOption.NEWEST
)

data class SelectedAdPhoto(
    val id: String,
    val uriString: String,
    val displayName: String = ""
)

data class PostAdDraft(
    val editingListingId: String? = null,
    val title: String = "",
    val priceText: String = "",
    val isMonthlyRent: Boolean = false,
    val negotiable: Boolean = true,
    val category: AdCategory = AdCategory.MOBILES,
    val district: KashmirDistrict = KashmirDistrict.SRINAGAR,
    val locality: String = "",
    val condition: AdCondition = AdCondition.GOOD,
    val description: String = "",
    val sellerName: String = "",
    val sellerPhone: String = "",
    val selectedPhotos: List<SelectedAdPhoto> = emptyList(),
    val photoError: String? = null,
    val draftVersion: Int = 0
) {
    val selectedPhotoCount: Int
        get() = selectedPhotos.size

    val mainPhoto: SelectedAdPhoto?
        get() = selectedPhotos.firstOrNull()
}
